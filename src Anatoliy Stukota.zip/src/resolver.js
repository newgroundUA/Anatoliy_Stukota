import Resolver from 'react-router-resolver'
import { fetcher } from 'data-fetcher'
import check from './utils/check'

let resolver

const getResolver = ({ history, store, routes }) => {
    if (resolver) return resolver

    resolver = new Resolver({
        routes,
        store,
        history,
        actions: store.router,
        helpers: {
            fetcher,
            store,
            history,
            check
        },
        resolved: window.__resolvedRoutes
    })

    return resolver
}

export { getResolver }
