import { types, flow } from 'mobx-state-tree'
import { getApiKeys } from '../api/profile'
import ApiKeyItem from '../models/ApiKeyItem'

export default types
    .model('ApiKeysStore', {
        keys: types.optional(types.array(ApiKeyItem), []),
        isLoading: false
    })
    .actions(self => ({
        fetchApiKeys: flow(function* fetchApiKeys() {
            self.isLoading = true
            try {
                const { apiKeys } = yield getApiKeys()
                self.keys = apiKeys
            } catch (e) {
                console.log(e)
            }
            self.isLoading = false
        }),
        removeApiKey: id => {
            self.keys = self.keys.filter(item => item.id !== id)
        }
    }))
