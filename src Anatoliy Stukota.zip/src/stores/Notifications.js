import { types } from 'mobx-state-tree'
import Notification from '../models/Notification'

export default types
    .model('NotificationsStore', {
        items: types.optional(types.array(Notification), [])
    })
    .actions(self => {
        let id = 1
        return {
            notify: ({ title, message, type = 'success', time = 4000, data }) => {
                const itemId = ++id
                self.items.push({
                    title,
                    message,
                    type,
                    time,
                    id,
                    data
                })
                setTimeout(() => {
                    self.hide(itemId)
                }, time)
            },
            remove: id => {
                self.items = self.items.filter(item => item.id !== id)
            },
            hide: id => {
                self.items.find(item => item.id === id).hided = true
                setTimeout(() => {
                    self.remove(id)
                }, 300)
            }
        }
    })
