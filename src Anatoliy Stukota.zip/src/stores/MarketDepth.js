import { types, getRoot, getEnv } from 'mobx-state-tree'
import { emitter } from '@utils'
import { ws, APP_CURRENCY_PAIR_CHANGED } from '../constants'

import MarketDepthItem from '../models/MarketDepthItem'

export default types
    .model('MarketDepthStore', {
        isLoaded: false,
        isLoading: false,
        buy: types.optional(types.array(MarketDepthItem), []),
        sell: types.optional(types.array(MarketDepthItem), [])
    })
    .actions(self => {
        const { socket } = getEnv(self)
        let subscriptionId = null
        return {
            handleMarketDepthReceived: ({ data: { buyColumns, sellColumns } }) => {
                self.buy = buyColumns.reverse()
                self.sell = sellColumns.reverse()

                self.isLoading = false
                self.isLoaded = true
            },
            subscribe: () => {
                self.isLoading = true

                const { id, type, args } = socket.send(ws.request.subscribe.MarketDepth, {
                    currencyPair: getRoot(self).app.currencyPair.name
                })

                socket.subscriptions.set(id, { type, args })
                subscriptionId = id
            },
            unsubscribe: (clear = true) => {
                if (clear) {
                    self.buy = []
                    self.sell = []
                    self.isLoaded = false
                }

                const { args } = socket.subscriptions.get(subscriptionId)
                socket.send(ws.request.unsubscribe.MarketDepth, args)
                socket.subscriptions.delete(subscriptionId)
                subscriptionId = null
            },
            afterCreate: () => {
                emitter.on(ws.response.MarketDepth, self.handleMarketDepthReceived)
                emitter.on(APP_CURRENCY_PAIR_CHANGED, () => {
                    if (subscriptionId) {
                        self.unsubscribe(false)
                        self.subscribe()
                    }
                })
            }
        }
    })
