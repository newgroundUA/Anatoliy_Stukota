import { types, flow, getRoot, getEnv } from 'mobx-state-tree'
import cookie from 'flexible-cookie'
import fetcher from 'data-fetcher'
import { emitter } from '@utils'
import { ws, APP_CURRENCY_PAIR_CHANGED } from '../constants'
import {
    getWithdrawalFees,
    getCurrencies,
    getFeatures,
    getLimits,
    getFees,
    getSiteKey,
    getSiteVersion
} from '../api/data'

import User from '../models/User'
import Fees from '../models/Fees'
import Features from '../models/Features'
import Currency from '../models/Currency'
import CurrencyPair from '../models/CurrencyPair'

export default types
    .model('AppStore', {
        user: types.maybe(User),
        serverTime: types.optional(types.Date, new Date()),
        currencyPair: types.maybe(types.reference(CurrencyPair)),
        siteKey: '',
        twoFaSecret: '',
        fees: types.maybe(Fees),
        sockets: false,
        features: types.maybe(Features),
        currencies: types.optional(types.array(Currency), []),
        currencyPairs: types.optional(types.array(CurrencyPair), []),
        version: ''
    })
    .actions(self => {
        const { socket } = getEnv(self)
        return {
            logout: () => {
                cookie.remove('Auth')
                window.location.reload()
            },

            set: (key, data) => {
                self[key] = data
            },

            setUser: user => {
                self.user = User.normalize(user)
            },

            handleServerTimeReceived: payload => {
                self.serverTime = payload.ms
            },

            handleTickersReceived: ({ tickers }) => {
                tickers.forEach(({ currencyPair, ...rest }) => {
                    const item = self.currencyPairs.find(item => item.name === currencyPair)
                    if (item) {
                        item.close = rest.close
                        item.highest = rest.highest
                        item.lowest = rest.lowest
                        item.open = rest.open
                        item.ts = rest.ts
                        item.volume = rest.volume
                    }
                })
            },

            setCurrencyPair: currencyPair => {
                self.currencyPair = currencyPair
                emitter.emit(APP_CURRENCY_PAIR_CHANGED, currencyPair)
            },

            fetchSiteVersion: flow(function* fetch() {
                const { version } = yield getSiteVersion()
                self.version = version
            }),

            init: flow(function* init({ redirect }) {
                try {
                    const [
                        { limits },
                        currencies,
                        { data: withdrawalFees },
                        fees,
                        { siteKey },
                        features,
                        { version }
                    ] = yield Promise.all([
                        getLimits(),
                        getCurrencies(),
                        getWithdrawalFees(),
                        getFees(),
                        getSiteKey(),
                        getFeatures(),
                        getSiteVersion()
                    ])

                    self.features = features
                    self.fees = fees
                    self.siteKey = siteKey
                    self.currencyPairs = limits.map(({ currencyPair, ...item }) => {
                        const [baseCurrency, quoteCurrency] = currencyPair.split('_')
                        return { ...item, baseCurrency, quoteCurrency, name: currencyPair }
                    })

                    self.version = version

                    const withdrawalFeesEntries = withdrawalFees.reduce((acc, curr) => {
                        acc[curr.currency] = {
                            withdrawalTrxFee: curr.withdrawalTrxFee,
                            withdrawalMaxAmount: curr.withdrawalMaxAmount,
                            withdrawalMinAmount: curr.withdrawalMinAmount,
                            depositMaxAmount: curr.depositMaxAmount,
                            isDepositEnabled: curr.isDepositEnabled,
                            isWithdrawalEnabled: curr.isWithdrawalEnabled
                        }
                        return acc
                    }, {})

                    self.currencies = currencies.map(({ currency, currencyName, ...item }) => ({
                        ...item,
                        code: currency,
                        name: currencyName,
                        account: currency,
                        ...withdrawalFeesEntries[currency]
                    }))

                    if (cookie.get('Auth')) {
                        const user = yield fetcher('/profile/currentUser')
                        self.setUser(user)
                    }

                    socket.connect()

                    const summary24h = socket.send(ws.request.subscribe.Summary24h)
                    socket.subscriptions.set(summary24h.id, { type: summary24h.type })
                    const serverTime = socket.send(ws.request.subscribe.ServerTime)
                    socket.subscriptions.set(serverTime.id, { type: serverTime.type })
                } catch (e) {
                    if (e.error && e.error.errorCode === 'error.login.required') {
                        cookie.remove('Auth')
                        redirect('/')
                    }

                    console.error(e)
                    redirect('/maintenance')
                }
            }),

            handleFail: e => {
                if (e && e.error && e.error.errorCode === 'error.login.required') {
                    const root = getRoot(self)
                    root.notifications.notify({
                        message: 'Your session has expired'
                    })
                    const from = root.router.location.pathname + root.router.location.search
                    root.router.push(`/login?from=${from}`)
                }

                throw e
            },

            afterCreate: () => {
                emitter.on(ws.response.subscribe.ServerTime, self.handleServerTimeReceived)
                emitter.on(ws.response.ServerTime, self.handleServerTimeReceived)
                emitter.on(ws.response.Summary24h, self.handleTickersReceived)
                emitter.on(ws.response.subscribe.Summary24h, self.handleTickersReceived)
            }
        }
    })
    .views(self => ({
        get isAuthenticated() {
            return !!self.user
        }
    }))
