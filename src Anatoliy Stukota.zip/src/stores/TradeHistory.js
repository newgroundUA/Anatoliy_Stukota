import { types, getRoot, getEnv } from 'mobx-state-tree'
import { emitter } from '@utils'
import { ws, APP_CURRENCY_PAIR_CHANGED } from '../constants'
import TradeHistoryItem from '../models/TradeHistoryItem'

export default types
    .model('TradeHistoryStore', {
        isLoaded: false,
        isLoading: true,
        items: types.optional(types.map(TradeHistoryItem), {})
    })
    .actions(self => {
        const { socket } = getEnv(self)
        let subscriptionId = null
        return {
            handleTradesReceived: ({ trades, channel, currencyPair }) => {
                self.items = TradeHistoryItem.normalize(trades, channel ? channel.currencyPair : currencyPair)
                self.isLoading = false
                self.isLoaded = true
            },

            subscribe: () => {
                self.isLoading = true
                const { id, type, args } = socket.send(ws.request.subscribe.TradeHistoryTop, {
                    currencyPair: getRoot(self).app.currencyPair.name
                })

                socket.subscriptions.set(id, { type, args })
                subscriptionId = id
            },

            unsubscribe: (clear = true) => {
                if (clear) {
                    self.items = {}
                    self.isLoaded = false
                }

                const { args } = socket.subscriptions.get(subscriptionId)
                socket.send(ws.request.unsubscribe.TradeHistoryTop, args)
                socket.subscriptions.delete(subscriptionId)
                subscriptionId = null
            },

            afterCreate: () => {
                emitter.on(ws.response.TradeHistoryState, self.handleTradesReceived)
                emitter.on(ws.response.LatestTrades, self.handleTradesReceived)
                emitter.on(APP_CURRENCY_PAIR_CHANGED, () => {
                    if (subscriptionId) {
                        self.unsubscribe(false)
                        self.subscribe()
                    }
                })
            }
        }
    })
    .views(self => ({
        get keys() {
            const keys = self.items.keys()
            keys.sort((a, b) => {
                const timeA = self.items.get(a).time
                const timeB = self.items.get(b).time

                return timeB - timeA
            })
            return keys
        }
    }))
