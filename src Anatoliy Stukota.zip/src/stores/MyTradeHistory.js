import { types, flow, getRoot, getEnv } from 'mobx-state-tree'
import { emitter } from '@utils'
import { getOrders } from '../api/orders'
import Order from '../models/Order'
import { ws } from '../constants'

const MyTradeHistory = types
    .model('MyTradeHistoryStore', {
        items: types.optional(types.array(Order), []),
        countPages: types.maybe(types.number),
        pageSize: types.maybe(types.number),
        page: types.maybe(types.number),
        isLoading: false,
        isLoaded: false,
        lastQuery: types.optional(types.frozen, null)
    })
    .actions(self => {
        const { socket } = getEnv(self)
        let subscriptionId = null
        return {
            fetch: flow(function* fetch(query = self.lastQuery) {
                self.isLoading = true
                try {
                    const { content, totalPages, size, number } = yield getOrders(query)
                    self.lastQuery = query
                    self.items = content
                    self.pageSize = size
                    self.page = number
                    self.countPages = totalPages
                } catch (e) {
                    getRoot(self).notifications.notify({
                        title: 'errorWhileFetchingOrders',
                        message: JSON.stringify(e)
                    })
                }
                self.isLoading = false
            }),

            changePage: ({ selected }) => {
                self.fetch({ ...self.lastQuery, page: selected })
            },

            changeFilters: filters => {
                self.fetch({ ...self.lastQuery, ...filters, page: 0 })
            },

            subscribe: () => {
                const { id, type } = socket.send(ws.request.subscribe.MyTradeHistoryChanges)
                socket.subscriptions.set(id, { type })
                subscriptionId = id
            },

            unsubscribe: (clear = true) => {
                if (clear) {
                    self.items = []
                    self.isLoaded = false
                    self.lastQuery = null
                }
                socket.send(ws.request.unsubscribe.MyTradeHistoryChanges)
                socket.subscriptions.delete(subscriptionId)
                subscriptionId = null
            },

            afterCreate: () => {
                emitter.on(ws.response.MyTradeHistoryChanged, () => self.fetch())
            }
        }
    })

export default MyTradeHistory
