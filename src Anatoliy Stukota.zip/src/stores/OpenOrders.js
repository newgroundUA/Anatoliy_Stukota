import { types, getRoot, flow, getEnv } from 'mobx-state-tree'
import { emitter } from '@utils'
import { getActiveOrders } from '../api/orders'
import { ws, APP_CURRENCY_PAIR_CHANGED } from '../constants'

import OpenOrder from '../models/OpenOrder'

const OpenOrders = types
    .model('OpenOrdersStore', {
        isLoaded: false,
        isLoading: false,
        items: types.optional(types.array(OpenOrder), []),
        all: false
    })
    .views(self => ({
        get byCurrentPair() {
            const root = getRoot(self)
            const { currencyPair } = root.app
            return self.items.filter(item => item.currencyPair.name === currencyPair.name)
        }
    }))
    .actions(self => {
        const { socket } = getEnv(self)
        let subscriptionId = null
        return {
            fetch: flow(function* fetch(customQuery) {
                try {
                    const { app } = getRoot(self)
                    const query = {
                        pair: !self.all ? app.currencyPair.name : undefined
                    }

                    self.isLoading = true
                    const { content } = yield getActiveOrders(customQuery || query)
                    self.items = content
                    self.isLoaded = true
                    self.isLoading = false
                } catch (e) {
                    self.isLoading = false
                }
            }),

            subscribe: () => {
                const { id, type } = socket.send(ws.request.subscribe.MyActiveOrdersChanges)
                socket.subscriptions.set(id, { type })
                subscriptionId = id
            },

            unsubscribe: (clear = true) => {
                if (clear) {
                    self.items = []
                    self.isLoaded = false
                }
                socket.send(ws.request.unsubscribe.MyActiveOrdersChanges)
                socket.subscriptions.delete(subscriptionId)
                subscriptionId = null
            },

            pushOrder: order => {
                self.items.unshift(order)
            },

            removeOrder: orderId => {
                self.items = self.items.filter(item => item.id !== orderId)
            },

            afterCreate: () => {
                emitter.on(ws.response.MyActiveOrdersChanges, () => self.fetch())
                emitter.on(APP_CURRENCY_PAIR_CHANGED, pair => {
                    if (subscriptionId && !self.all) {
                        self.fetch({ pair })
                    }
                })
            },

            showAll: () => {
                self.all = true
                self.fetch()
            },

            showByCurrencyPair: () => {
                self.all = false
                self.fetch()
            }
        }
    })

export default OpenOrders
