import { types, getEnv } from 'mobx-state-tree'
import { ROUTER_INIT, ROUTER_LOCATION_CHANGE } from '../constants'
import Location from '../models/Location'

export default types
    .model('RouterStore', {
        location: types.optional(Location, {
            pathname: window.location.pathname,
            search: window.location.search
        }),
        state: types.maybe(types.enumeration('State', ['loading', 'loaded', 'fail']))
    })
    .actions(self => ({
        onStart: () => {
            self.state = 'loading'
        },
        onSuccess: () => {
            self.state = 'loaded'
        },
        onFail: () => {
            self.state = 'fail'
        },
        [ROUTER_INIT]: location => {
            self.location = location
        },
        push: to => {
            const { history } = getEnv(self)
            history.push(to)
        },
        replace: to => {
            const { history } = getEnv(self)
            history.replace(to)
        },
        [ROUTER_LOCATION_CHANGE]: location => {
            self.location = location
        }
    }))
