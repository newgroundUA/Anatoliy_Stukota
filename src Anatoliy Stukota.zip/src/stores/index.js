import { types, getEnv } from 'mobx-state-tree'
import App from './App'
import OrderBook from './OrderBook'
import TradeHistory from './TradeHistory'
import MarketDepth from './MarketDepth'
import Router from './Router'
import Notifications from './Notifications'
import Modal from '../models/Modal'

const Store = types
    .model('Store', {
        app: types.optional(App, {}),
        orderBook: types.optional(OrderBook, {}),
        tradeHistory: types.optional(TradeHistory, {}),
        marketDepth: types.optional(MarketDepth, {}),
        router: types.optional(Router, {}),
        notifications: types.optional(Notifications, {}),
        modals: types.optional(types.map(Modal), {
            passwordSuccess: {
                opened: false
            },
            '2faEnableConfirm': {
                opened: false
            },
            '2faDisableConfirm': {
                opened: false
            },
            withdrawConfirm: {
                opened: false
            }
        })
    })
    .actions(self => {
        const { socket } = getEnv(self)
        return {
            afterCreate: () => {
                socket.store = self
            }
        }
    })

export { Store }
