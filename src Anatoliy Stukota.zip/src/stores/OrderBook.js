import { types, getRoot, getEnv } from 'mobx-state-tree'
import { emitter } from '@utils'
import { ws, APP_CURRENCY_PAIR_CHANGED } from '../constants'
import OrderBookItem from '../models/OrderBookItem'

export default types
    .model('OrderBookStore', {
        isLoaded: false,
        isLoading: true,
        items: types.optional(types.map(OrderBookItem), {}),
        type: types.optional(types.enumeration(['orderBook', 'marketDepth']), 'orderBook')
    })
    .actions(self => {
        const { socket } = getEnv(self)
        let subscriptionId = null
        return {
            handleToggleType: () => {
                self.type = self.type === 'marketDepth' ? 'orderBook' : 'marketDepth'
            },
            setOrders: ({ orders }) => {
                self.items.replace(
                    orders.reduce((acc, curr) => {
                        acc[curr.price] = curr
                        return acc
                    }, {})
                )

                if (!self.isLoaded || self.isLoading) {
                    emitter.emit('@trade/initializePrice')
                }

                self.isLoading = false
                self.isLoaded = true
            },

            subscribe: () => {
                self.isLoading = true
                const { id, type, args } = socket.send(ws.request.subscribe.OrderBookTop, {
                    currencyPair: getRoot(self).app.currencyPair.name
                })

                socket.subscriptions.set(id, { type, args })
                subscriptionId = id
            },

            unsubscribe: (clear = true) => {
                if (clear) {
                    self.items = {}
                    self.isLoaded = false
                }

                const { args } = socket.subscriptions.get(subscriptionId)
                socket.send(ws.request.unsubscribe.OrderBookTop, args)
                socket.subscriptions.delete(subscriptionId)
                subscriptionId = null
            },

            afterCreate: () => {
                emitter.on(ws.response.OrderBookState, self.setOrders)
                emitter.on(ws.response.OrderBookTop, self.setOrders)
                emitter.on(APP_CURRENCY_PAIR_CHANGED, () => {
                    if (subscriptionId) {
                        self.unsubscribe(false)
                        self.subscribe()
                    }
                })
            }
        }
    })
    .views(self => ({
        get buy() {
            const keys = self.items.keys().filter(key => self.items.get(key).side === 'BUY')
            keys.sort((a, b) => self.items.get(b).price - self.items.get(a).price)
            return keys
        },
        get sell() {
            const keys = self.items.keys().filter(key => self.items.get(key).side === 'SELL')
            keys.sort((a, b) => self.items.get(b).price - self.items.get(a).price)
            return keys
        },
        get spreadValue() {
            const { buy, sell, items } = self
            return sell.length && buy.length ? items.get(sell[sell.length - 1]).price - items.get(buy[0]).price : 0
        }
    }))
