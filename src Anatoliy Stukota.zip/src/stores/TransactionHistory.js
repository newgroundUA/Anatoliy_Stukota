import { types, flow, getRoot } from 'mobx-state-tree'
import { getTransactions } from '../api/funds'
import Transaction from '../models/Transaction'

const TransactionHistory = types
    .model('TransactionHistoryStore', {
        items: types.maybe(types.array(Transaction)),
        countPages: types.maybe(types.number),
        pageSize: types.maybe(types.number),
        page: types.maybe(types.number),
        isLoading: false,
        isLoaded: false,
        rawRequest: ''
    })
    .views(self => ({
        get request() {
            return JSON.parse(self.rawRequest)
        }
    }))
    .actions(self => ({
        fetch: flow(function* fetch(query) {
            self.isLoading = true
            try {
                const { content, totalPages, size, number } = yield getTransactions(query)
                self.items = content
                self.countPages = totalPages
                self.pageSize = size
                self.page = number

                self.rawRequest = JSON.stringify(query)
                self.isLoading = false
                self.isLoaded = true
            } catch (e) {
                console.log(e)
                getRoot(self).notifications.notify({
                    title: 'errorWhileFetchingTransactions',
                    message: JSON.stringify(e)
                })
                self.isLoading = false
            }
        }),
        changePage: ({ selected }) => {
            self.fetch({ page: selected })
        }
    }))

export { TransactionHistory as default }
