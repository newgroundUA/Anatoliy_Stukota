import { types } from 'mobx-state-tree'
import CurrencyPair from './CurrencyPair'

export default types.model('Order', {
    id: types.number,
    currencyPair: types.reference(CurrencyPair),
    price: types.number,
    effectivePrice: types.number,
    closed: types.boolean,
    type: types.string,
    side: types.string,
    trades: types.maybe(
        types.array(
            types.model({
                amount: types.number,
                createdAtMs: types.number,
                currencyPair: types.reference(CurrencyPair),
                id: types.number,
                makerFee: types.number,
                makerOrderId: types.number,
                price: types.number,
                priceDifference: types.number,
                side: types.string,
                takerFee: types.number,
                takerOrderId: types.number,
                totalPrice: types.maybe(types.number),
                userId: types.number
            })
        )
    ),
    status: types.string,
    feeAmount: types.number,
    userId: types.number,
    baseCurrencyAmount: types.number,
    quoteCurrencyAmount: types.number,
    baseCurrencyRemainingAmount: types.number,
    quoteCurrencyRemainingAmount: types.number,
    quoteCurrencyFulfilledAmount: types.number,
    baseCurrencyFulfilledAmount: types.number,
    createdAt: types.number,
    updatedAt: types.number,
    closedAt: types.number
})
