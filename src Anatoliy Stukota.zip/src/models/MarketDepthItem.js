import { types } from 'mobx-state-tree'

const MarketDepthItem = types.model('MarketDepth', {
    amount: types.number,
    price: types.number
})

export default MarketDepthItem
