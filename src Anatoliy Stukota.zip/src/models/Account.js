import { types } from 'mobx-state-tree'
import Currency from './Currency'
import Wallet from './Wallet'

const Account = types.model('Account', {
    balance: types.number,
    currencyId: types.identifier(),
    currency: types.reference(Currency),
    ordersBalance: types.number,
    wallet: types.reference(Wallet)
})

Account.normalize = accounts => {
    const $map = accounts.reduce((acc, curr) => {
        if (!acc[curr.currency]) {
            acc[curr.currency] = {
                currency: curr.currency,
                currencyId: curr.currency,
                wallet: curr.currency
            }
        }

        if (curr.type === 'ACTIVE_ORDERS_BALANCE') {
            acc[curr.currency].ordersBalance = curr.balance
        } else {
            acc[curr.currency].balance = curr.balance
        }

        return acc
    }, {})

    return Object.keys($map).map(item => $map[item])
}

export default Account
