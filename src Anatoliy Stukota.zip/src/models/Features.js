import { types } from 'mobx-state-tree'

export default types.model('Features', {
    isDepositsEnabled: types.boolean,
    isWithdrawalsEnabled: types.boolean,
    isSignUpActivationEnabled: types.boolean,
    isOrderPlacingEnabled: types.boolean
})
