import { types, getParent } from 'mobx-state-tree'
import { emitter } from '../utils'
import CurrencyPair from './CurrencyPair'

export default types
    .model('OrderBookItem', {
        amount: types.number,
        currencyPair: types.reference(CurrencyPair),
        price: types.number,
        side: types.string
    })
    .actions(self => ({
        handleRowClick: () => {
            emitter.emit('@trade/setPrice', self.price)
            const orderBook = getParent(self, 2)
            const keys = self.side === 'SELL' ? orderBook.sell.slice().reverse() : orderBook.buy

            let amount = 0

            keys.some(key => {
                const item = orderBook.items.get(key)
                if (self.side === 'SELL' ? item.price > self.price : item.price < self.price) return true

                amount += item.amount
                return false
            })
            emitter.emit('@trade/setAmount', amount)
        }
    }))
