import { types } from 'mobx-state-tree'
import Account from './Account'

const Currency = types.model('Currency', {
    code: types.identifier(),
    name: types.string,
    order: types.number,
    withdrawalTrxFee: types.number,
    withdrawalMaxAmount: types.number,
    withdrawalMinAmount: types.number,
    depositMaxAmount: types.number,
    isDepositEnabled: types.boolean,
    isWithdrawalEnabled: types.boolean,
    account: types.late(() => types.maybe(types.reference(Account)))
})

export default Currency
