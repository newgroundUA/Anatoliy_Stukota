import { types } from 'mobx-state-tree'
import Currency from './Currency'

const CurrencyPair = types
    .model('CurrencyPair', {
        name: types.identifier(),
        baseCurrency: types.reference(Currency),
        quoteCurrency: types.reference(Currency),
        maxPrice: types.number,
        minPrice: types.number,
        minTotalBaseCurrency: types.number,
        minTotalQuoteCurrency: types.number,
        maxTotalQuoteCurrency: types.number,
        amountScale: types.number,
        priceScale: types.number,
        close: 0,
        highest: 0,
        lowest: 0,
        open: 0,
        ts: 0,
        volume: 0
    })
    .views(self => ({
        get dailyChange() {
            return self.close - self.open
        },
        get dailyChangePercent() {
            return (100 * self.close) / self.open - 100 || 0
        }
    }))

export default CurrencyPair
