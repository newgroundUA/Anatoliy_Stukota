import { types, flow, getRoot } from 'mobx-state-tree'
import Currency from './Currency'
import { createWallet } from '../api/profile'

const Wallet = types
    .model('Wallet', {
        currencyId: types.identifier(),
        walletAddress: types.maybe(types.string),
        currency: types.reference(Currency),
        isLoading: false
    })
    .actions(self => ({
        refresh: flow(function* fetch() {
            self.isLoading = true
            try {
                const { address } = yield createWallet(self.currency.code)
                self.walletAddress = address
            } catch (e) {
                getRoot(self).notifications.notify({
                    message: e.error.errorCode
                })
            }
            self.isLoading = false
        })
    }))

Wallet.fill = (wallets, currencies) =>
    currencies.map(({ code }) => {
        const wallet = wallets.find(item => item.currency === code)
        if (!wallet) {
            return {
                walletAddress: '',
                currency: code,
                currencyId: code
            }
        }

        return { ...wallet, currencyId: code }
    })

export default Wallet
