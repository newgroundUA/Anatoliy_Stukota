import { getParent } from 'mobx-state-tree'
import Order from './Order'
import { cancelOrder } from '../api/orders'

export default Order.volatile(self => ({
    cancel: () =>
        cancelOrder(self.id).then(({ order }) => {
            getParent(self, 2).removeOrder(order.id)
        })
}))
