import { types, getParent, flow } from 'mobx-state-tree'
import { deactivateApiKey, changeApiKeyPermissions } from '../api/profile'

const ApiKeyItem = types
    .model('ApiKeyItem', {
        expiresAt: types.maybe(types.string),
        externalId: types.string,
        id: types.number,
        ipAddresses: types.maybe(types.string),
        key: types.string,
        name: types.string,
        restrictToIps: types.boolean,
        secret: types.string,
        tradingEnabled: types.boolean,
        withdrawalEnabled: types.boolean
    })
    .actions(self => ({
        deactivate: authCode =>
            deactivateApiKey(self.id, authCode).then(() => {
                getParent(self, 2).removeApiKey(self.id)
            }),
        changePermissions: flow(function* fetch(item) {
            yield changeApiKeyPermissions(item)
            self.ipAddresses = item.ipAddresses
            self.restrictToIps = item.restrictToIps
            self.tradingEnabled = item.tradingEnabled
            self.withdrawalEnabled = item.withdrawalEnabled
        })
    }))

export default ApiKeyItem
