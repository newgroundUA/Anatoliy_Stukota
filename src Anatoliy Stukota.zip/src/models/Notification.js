import { types } from 'mobx-state-tree'

export default types.model('Notification', {
    id: types.number,
    title: types.maybe(types.string),
    message: types.maybe(types.string),
    type: types.maybe(types.string),
    time: types.maybe(types.number),
    hided: false,
    data: types.optional(types.frozen, null)
})
