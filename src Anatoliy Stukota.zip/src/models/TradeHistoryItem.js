import { types } from 'mobx-state-tree'
import CurrencyPair from './CurrencyPair'

const TradeHistoryItem = types.model('TradeHistoryItem', {
    amount: types.number,
    time: types.number,
    side: types.string,
    price: types.number,
    total: types.number,
    currencyPair: types.reference(CurrencyPair)
})

TradeHistoryItem.normalize = (items, currencyPair) =>
    items.reduce((acc, curr) => {
        acc[`${curr.a}${curr.d}${curr.s}${curr.p}${curr.t}`] = {
            amount: curr.a,
            time: curr.d,
            side: curr.s,
            price: curr.p,
            total: curr.t,
            currencyPair
        }
        return acc
    }, {})

export default TradeHistoryItem
