import { types, getParent } from 'mobx-state-tree'
import { cancelWithdrawal } from '../api/funds'

export default types
    .model('Transaction', {
        id: types.number,
        type: types.string,
        status: types.string,
        currency: types.string,
        amount: types.number,
        fee: types.number,
        trxHash: types.maybe(types.string),
        createdAt: types.number,
        updatedAt: types.number,
        completedAt: types.number
    })
    .views(self => ({
        get $id() {
            return self.id + self.type.slice(0, 1)
        }
    }))
    .actions(self => ({
        handleCancel: () =>
            cancelWithdrawal(self.id).then(() => {
                getParent(self, 2).fetch()
            })
    }))
