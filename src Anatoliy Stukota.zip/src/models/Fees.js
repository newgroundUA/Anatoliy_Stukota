import { types } from 'mobx-state-tree'

export default types
    .model('Fees', {
        taker: types.number,
        maker: types.number
    })
    .views(self => ({
        get multiplier() {
            return Math.abs(Object.values(self).sort((a, b) => (a < b ? -1 : 1))[0])
        },
        getFee: (amount, price) => amount * price * self.multiplier
    }))
