import { types } from 'mobx-state-tree'

export default types
    .model('ModalStore', {
        opened: false
    })
    .actions(self => ({
        open: () => {
            self.opened = true
        },
        close: () => {
            self.opened = false
        }
    }))
