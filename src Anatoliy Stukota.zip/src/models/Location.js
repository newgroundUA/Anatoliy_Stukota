import { types } from 'mobx-state-tree'
import { parseQuery } from 'data-fetcher'

export default types
    .model('Location', {
        pathname: types.string,
        search: types.maybe(types.string),
        key: types.maybe(types.string),
        hash: types.maybe(types.string)
    })
    .views(self => ({
        get query() {
            return parseQuery(self.search)
        }
    }))
