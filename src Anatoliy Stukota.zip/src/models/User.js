import { types, getEnv, getParent, flow } from 'mobx-state-tree'
import { emitter } from '@utils'
import { ws } from '../constants'
import { getWallets } from '../api/profile'

import Account from './Account'
import Wallet from './Wallet'

import ApiKeys from '../stores/ApiKeys'
import OpenOrders from '../stores/OpenOrders'
import MyTradeHistory from '../stores/MyTradeHistory'
import TransactionHistory from '../stores/TransactionHistory'

const User = types
    .model('User', {
        id: types.number,
        login: types.string,
        twoFaEnabled: types.boolean,
        isActive: types.boolean,
        accounts: types.optional(types.array(Account), []),
        apiKeys: types.optional(ApiKeys, {}),
        wallets: types.optional(types.array(Wallet), []),
        openOrders: types.optional(OpenOrders, {}),
        myTradeHistory: types.optional(MyTradeHistory, {}),
        transactionHistory: types.optional(TransactionHistory, {})
    })
    .actions(self => {
        const { socket } = getEnv(self)
        return {
            handleUserBalances: ({ accounts }) => {
                self.accounts = Account.normalize(accounts)
            },

            subscribe: () => {
                socket.send(ws.request.subscribe.UserBalance)
            },

            unsubscribe: () => {
                socket.send(ws.request.unsubscribe.UserBalance)
            },

            fetchWallets: flow(function* fetch() {
                const { addresses } = yield getWallets()
                self.wallets = Wallet.fill(addresses, getParent(self).currencies)
            }),

            afterCreate: () => {
                emitter.on(ws.response.UserBalances, self.handleUserBalances)
            },

            set: (property, value) => {
                self[property] = value
            }
        }
    })

User.normalize = ({ accounts, ...rest }) => ({
    ...rest,
    accounts: Account.normalize(accounts)
})

export default User
