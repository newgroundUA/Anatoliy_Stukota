import { types } from 'mobx-state-tree'

export default types.model('WithdrawalFee', {
    currency: types.string,
    withdrawalTrxFee: types.number,
    withdrawalMaxAmount: types.number,
    withdrawalMinAmount: types.number,
    depositMaxAmount: types.number,
    isDepositEnabled: types.boolean,
    isWithdrawalEnabled: types.boolean
})
