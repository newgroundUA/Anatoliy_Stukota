import { types } from 'mobx-state-tree'

const Limit = types.model('Limit', {
    currencyPair: types.identifier(),
    maxPrice: types.number,
    minPrice: types.number,
    minTotalBaseCurrency: types.number,
    minTotalQuoteCurrency: types.number,
    maxTotalQuoteCurrency: types.number,
    amountScale: types.number,
    priceScale: types.number
})

Limit.normalize = limits =>
    limits.reduce((acc, curr) => {
        acc[curr.currencyPair] = curr
        return acc
    }, {})

export default Limit
