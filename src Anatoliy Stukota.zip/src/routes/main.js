import Layout from '../components/App/Layout'

export default {
    path: ['/trade', '/user', '/legal'],
    component: Layout,
    routes: [
        {
            path: ['/trade', '/user'],
            getComponent: () => import('./WithSidebar')
        },
        {
            path: '/legal',
            getComponent: () => import('./legal')
        }
    ],
    preload: ({ store }) => {
        if (!store.app.currencyPair) {
            const $currencyPair = window.localStorage.getItem('currencyPair')
            store.app.setCurrencyPair($currencyPair || store.app.currencyPairs[0].name)
            window.localStorage.setItem('currencyPair', $currencyPair || store.app.currencyPairs[0].name)
        }
    }
}
