export default {
    path: '*',
    onEnter: ({ redirect }) => redirect('/404')
}
