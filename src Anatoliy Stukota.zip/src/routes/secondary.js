import SecondaryLayout from '../components/App/Layout/Secondary'
import FrozenAccount from '../components/App/User/FrozenAccount'
import WithdrawSuccessful from '../components/App/User/WithdrawOld/WithdrawalSuccess'
import TokenExpired from '../components/App/TokenExpired'
import notFound from './notFound'
import Maintenance from '../components/App/Maintenance/Maintenance'
import NotFound from '../components/App/NotFound'
import ErrorPage from '../components/App/ErrorPage'

export default {
    component: SecondaryLayout,
    routes: [
        {
            path: '/login',
            getComponent: () => import('./Login')
        },
        {
            path: '/register',
            getComponent: () => import('./Register')
        },
        {
            path: '/frozen-account',
            component: FrozenAccount
        },
        {
            path: '/withdraw-successful',
            component: WithdrawSuccessful
        },
        {
            path: '/token-expired',
            component: TokenExpired
        },
        {
            path: '/maintenance',
            component: Maintenance
        },
        {
            path: '/404',
            component: NotFound
        },
        {
            path: '/error',
            component: ErrorPage
        },
        notFound
    ]
}
