import { renderRoutes } from 'react-router-config'
import Register from '../components/App/Register'
import RegisterConfirm from '../components/App/Register/Confirm'
import RegisterSuccess from '../components/App/Register/Success'
import RegisterTwoFactorAuthentication from '../components/App/Register/TwoFactorAuthentication'
import RegisterTwoFactorAuthenticationSuccess from '../components/App/Register/TwoFactorAuthentication/Success'
import notFound from './notFound'

const RegisterPage = ({ route }) => renderRoutes(route.routes)

RegisterPage.routes = [
    {
        path: '/register',
        exact: true,
        strict: true,
        component: Register,
        onEnter: ({ check }) =>
            check({
                logged: false,
                to: '/trade'
            })
    },
    {
        path: '/register/confirm',
        component: RegisterConfirm
    },
    {
        path: '/register/success',
        exact: true,
        strict: true,
        component: RegisterSuccess
    },
    {
        path: '/register/2fa',
        exact: true,
        strict: true,
        component: RegisterTwoFactorAuthentication
    },
    {
        path: '/register/2fa/success',
        component: RegisterTwoFactorAuthenticationSuccess,
        onEnter: ({ check }) =>
            check({
                anonymous: false,
                to: '/register'
            })
    },
    notFound
]

export default RegisterPage
