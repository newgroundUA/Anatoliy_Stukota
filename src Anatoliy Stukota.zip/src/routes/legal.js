import { renderRoutes } from 'react-router-config'
import PrivacyPolicy from '../components/App/Legal/PrivacyPolicy'
import TermsAndConditions from '../components/App/Legal/TermsAndConditions'
import AntiSpamPolicy from '../components/App/Legal/AntiSpamPolicy'
import CTKTokenTerms from '../components/App/Legal/CTKTokenTerms'
import RiskDisclosureStatement from '../components/App/Legal/RiskDisclosureStatement'
import TrademarkNotices from '../components/App/Legal/TrademarkNotices'

const LegalPage = ({ route }) => renderRoutes(route.routes)

LegalPage.routes = [
    {
        path: '/legal',
        exact: true,
        strict: true,
        onEnter: ({ redirect }) => redirect('/legal/privacy-policy')
    },
    {
        path: '/legal/privacy-policy',
        component: PrivacyPolicy
    },
    {
        path: '/legal/terms-of-service',
        component: TermsAndConditions
    },
    {
        path: '/legal/anti-spam-policy',
        component: AntiSpamPolicy
    },
    {
        path: '/legal/ctk-token-terms',
        component: CTKTokenTerms
    },
    {
        path: '/legal/risk-disclosure-statement',
        component: RiskDisclosureStatement
    },
    {
        path: '/legal/trademark-notices',
        component: TrademarkNotices
    }
]

export default LegalPage
