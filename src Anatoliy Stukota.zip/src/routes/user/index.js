import { renderRoutes } from 'react-router-config'
import notFound from '../notFound'
import funds from './funds'
import settings from './settings'

const UserPage = ({ route }) => renderRoutes(route.routes)

UserPage.routes = [settings, funds, notFound]

UserPage.onEnter = ({ check }) =>
    check({
        anonymous: false
    })

export default UserPage
