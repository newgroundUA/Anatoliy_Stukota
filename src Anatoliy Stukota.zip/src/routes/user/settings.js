import Settings from '../../components/App/User/Settings'
import General from '../../components/App/User/Settings/General'
import Api from '../../components/App/User/Settings/Api'
import Profile from '../../components/App/User/Settings/Profile'
import ActivityLog from '../../components/App/User/Settings/ActivityLog'
import { getSharedSecret } from '../../api/profile'

export default {
    path: '/user/settings',
    component: Settings,
    routes: [
        {
            path: '/user/settings/general',
            component: General
        },
        {
            path: '/user/settings/api',
            component: Api,
            preload: ({ store: { app } }) => app.user.apiKeys.fetchApiKeys(),
            preloadOptions: {
                alwaysReload: true
            }
        },
        {
            path: '/user/settings/profile',
            component: Profile,
            preload: async ({ store: { app } }) =>
                !app.user.twoFaEnabled && app.set('twoFaSecret', await getSharedSecret())
        },
        {
            path: '/user/settings/activity-log',
            component: ActivityLog
        }
    ]
}
