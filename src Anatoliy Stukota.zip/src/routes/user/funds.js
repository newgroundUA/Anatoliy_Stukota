import { emitter } from '@utils'
import Funds from '../../components/App/User/Funds'
import Balances from '../../components/App/User/Funds/Balances'
import TradingHistory from '../../components/App/User/Funds/TradingHistory'
import FeesLimits from '../../components/App/User/Funds/FeesLimits'
import OpenOrders from '../../components/App/User/Funds/OpenOrders'
import TransactionHistory from '../../components/App/User/Funds/TransactionHistory'

export default {
    path: '/user/funds',
    component: Funds,
    routes: [
        {
            path: '/user/funds/balances',
            component: Balances,
            preload: ({ store }) => store.app.user.fetchWallets(),
            preloadOptions: {
                alwaysReload: true
            }
        },
        {
            path: '/user/funds/order-history',
            component: TradingHistory,
            preload: ({ store }) => {
                emitter.emit('@ordersHistory/clearFilters')
                return store.app.user.myTradeHistory.fetch({ showTrades: true })
            },
            preloadOptions: {
                alwaysReload: true
            }
        },
        {
            path: '/user/funds/transaction-history',
            component: TransactionHistory,
            preload: ({ store }) => {
                emitter.emit('@transactionHistory/clearFilters')
                return store.app.user.transactionHistory.fetch()
            },
            preloadOptions: {
                alwaysReload: true
            }
        },
        {
            path: '/user/funds/fees-limits',
            component: FeesLimits
        },
        {
            path: '/user/funds/open-orders',
            component: OpenOrders
        }
    ]
}
