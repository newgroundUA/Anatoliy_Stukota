import App from '../components/App'
import main from './main'
import secondary from './secondary'
import Maintenance from '../components/App/Maintenance/Maintenance'
import SecondaryLayout from '../components/App/Layout/Secondary'

const routes = [
    {
        path: '/maintenance',
        exact: true,
        component: SecondaryLayout,
        routes: [
            {
                path: '/maintenance',
                component: Maintenance
            }
        ]
    },
    {
        path: '/',
        component: App,
        routes: [
            {
                path: '/',
                exact: true,
                strict: true,
                onEnter: ({ redirect }) => redirect('/trade')
            },
            {
                path: '/uikit',
                exact: true,
                strict: true,
                getComponent: () => import('common/UIKit')
            },
            {
                path: '/version',
                exact: true,
                strict: true,
                getComponent: () => import('../components/App/Version')
            },
            main,
            secondary
        ],
        preload: async ({ store, ...rest }) => store.app.init(rest),
        preloadOptions: {
            reloadOnParamsChange: false,
            reloadOnQueryChange: false
        }
    }
]

export { routes as default }
