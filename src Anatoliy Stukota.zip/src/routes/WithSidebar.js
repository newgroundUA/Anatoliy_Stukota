import notFound from './notFound'
import WithSidebar from '../components/App/Layout/WithSidebar'

WithSidebar.routes = [
    {
        path: '/trade',
        exact: true,
        onEnter: ({
            redirect,
            store: {
                app: { currencyPair, currencyPairs }
            }
        }) => redirect(`/trade/${currencyPair ? currencyPair.name : currencyPairs[0].name}`)
    },
    {
        path: '/trade/:currencyPair',
        exact: true,
        strict: true,
        getComponent: () => import('../components/App/Trade'),
        onEnter: ({
            store: {
                app: { currencyPairs }
            },
            redirect,
            params: { currencyPair }
        }) => !currencyPairs.find(item => item.name === currencyPair) && redirect('/trade'),
        preload: ({ store, params: { currencyPair } }) => {
            store.app.setCurrencyPair(currencyPair)
            window.localStorage.setItem('currencyPair', currencyPair)
        }
    },
    {
        path: '/user',
        getComponent: () => import('./user')
    },
    notFound
]

export default WithSidebar
