import { renderRoutes } from 'react-router-config'
import Login from '../components/App/Login'
import LoginTwoFactorAuthentication from '../components/App/Login/TwoFactorAuthentication'
import LoginForgot from '../components/App/Login/Forgot'
import LoginForgotCheckEmail from '../components/App/Login/Forgot/CheckEmail'
import LoginForgotCreateNewPassword from '../components/App/Login/Forgot/CreateNewPassword'
import LoginForgotCongrats from '../components/App/Login/Forgot/Congrats'
import notFound from './notFound'

const LoginPage = ({ route }) => renderRoutes(route.routes)

LoginPage.routes = [
    {
        path: '/login',
        exact: true,
        strict: true,
        component: Login,
        onEnter: ({ store, redirect, location }) => {
            if (!store.app.isAuthenticated) return true
            if (location.query.from) return true

            return redirect('/trade')
        }
    },
    {
        path: '/login/2fa',
        component: LoginTwoFactorAuthentication,
        onEnter: ({ store, redirect }) => !store.app.user && redirect('/login')
    },
    {
        path: '/login/forgot',
        component: LoginForgot,
        exact: true,
        strict: true
    },
    {
        path: '/login/forgot/check-email',
        component: LoginForgotCheckEmail
    },
    {
        path: '/login/forgot/create-new-password',
        component: LoginForgotCreateNewPassword
    },
    {
        path: '/login/forgot/congrats',
        component: LoginForgotCongrats
    },
    notFound
]

export default LoginPage
