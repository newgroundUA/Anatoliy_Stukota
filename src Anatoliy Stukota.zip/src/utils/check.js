export default ({ anonymous = true, logged = true, activated = false, to = '/login' } = {}) => ({
    store,
    redirect
}) => {
    const location = {
        pathname: to,
        search: `?from=${store.router.location.pathname}${store.router.location.search}`
    }
    if (!anonymous && !store.app.user) {
        return redirect(location)
    }
    if (!logged && store.app.user) {
        return redirect(location)
    }
    if (!activated && store.app.isAuthenticated && !store.app.user.isActive) {
        return redirect(location)
    }

    return true
}
