import Emitter from './Emitter'

const emitter = new Emitter()

const round = (value, scale = 4) => {
    const pow = 10 ** scale
    return (Math.round(Number(value) * pow) / pow).toFixed(scale)
}

const format = (number, scale = 8) => {
    const result = {
        int: '',
        decimal: '',
        rest: '',
        value: ''
    }

    const [int, decimal = ''] = number.toFixed(scale).split('.')

    result.int = int
    decimal.split('').forEach(item => {
        if (Number(item)) {
            if (result.rest.length > 0) {
                result.decimal = result.decimal + result.rest + item
                result.rest = ''
            } else {
                result.decimal += item
            }
        } else {
            result.rest += item
        }
    })
    result.value = `${int}${result.decimal.length > 0 ? `.${result.decimal}` : ''}`
    return result
}

export { round, emitter, format }
