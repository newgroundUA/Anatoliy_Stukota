const get = (path = '') => ({ theme }) => {
    if (path === '') return theme
    const $path = path.split('.')
    let result
    $path.forEach((item, index) => {
        if (index === 0 || result[item]) {
            result = !index ? theme[item] : result[item]
        } else {
            result = ''
        }
    })

    return result
}

//
//     theme: {
//         header: {
//             color: 'red'
//         }
//     }
// }))

export { get }
