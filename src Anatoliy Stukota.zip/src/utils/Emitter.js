export default class Emitter {
    events = {}

    on = (event, cb) => {
        if (!this.events[event]) {
            this.events[event] = []
        }

        this.events[event].push(cb)

        return () => {
            this.events[event] = this.events[event].filter(item => item !== cb)
        }
    }

    emit = (event, ...args) => {
        // console.log(`%c Event: ${event}`, 'color: green', ...args)

        if (this.events[event]) {
            this.events[event].forEach(cb => {
                cb(...args)
            })
        }
    }
}
