const number = (nextValue, { value }) => (/^\d*\.?\d*$/.test(nextValue) || !nextValue ? nextValue : value)
const integer = (nextValue, { value }) => (/^\d*$/.test(nextValue) || !nextValue ? nextValue : value)

export { number, integer }
