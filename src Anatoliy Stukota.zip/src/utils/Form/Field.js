import { observable, action, computed } from 'mobx'

export default class Field {
    constructor(field, form, defaultValue) {
        Object.keys(field).forEach(key => {
            this[key] = field[key]
        })
        if (defaultValue !== undefined) {
            this.value = defaultValue
        }
        this.form = form
    }

    @observable active = false

    @observable blur = false

    @observable touched = false

    @observable visited = false

    @observable value

    @computed
    get error() {
        return this.form.errors[this.name]
    }

    @computed
    get submitFailed() {
        return this.form.submitFailed
    }

    @action
    onChange = e => {
        let $value

        if (e && e.target && e.target instanceof HTMLInputElement) {
            if (this.type === 'checkbox') {
                $value = !this.value
                this.touched = true
            } else {
                $value = e.target.value
            }
        } else {
            $value = e
        }

        this.value = this.normalize
            ? Array.isArray(this.normalize)
                ? this.normalize.reduce((acc, normalizer) => {
                      acc = normalizer(acc, this)
                      return acc
                  }, $value)
                : this.normalize($value, this)
            : $value

        if (this.form.validate) {
            this.form.set('errors', this.form.validate(this.form, this))
        }

        if (this.form.onChange) {
            this.form.onChange(e)
        }

        if (this.afterChange) {
            this.afterChange(e, this.form)
        }
    }

    @action
    onBlur = () => {
        this.touched = true
        this.active = false
    }

    @action
    onFocus = () => {
        this.active = true

        if (this.form.validate) {
            this.form.set('errors', this.form.validate(this.form, this))
        }
    }

    @action
    set = (property, value) => {
        this[property] = value
    }

    @action
    clear = () => {
        this.value = ''
    }

    bind = () => {
        const { onChange, onFocus, onBlur, value, error, name, type, placeholder, label, interceptor } = this
        const bindings = {
            onChange,
            onFocus,
            onBlur,
            value,
            error,
            name,
            placeholder,
            label
        }

        if (type === 'checkbox') {
            bindings.checked = value
        }

        return interceptor ? interceptor(bindings) : bindings
    }
}
