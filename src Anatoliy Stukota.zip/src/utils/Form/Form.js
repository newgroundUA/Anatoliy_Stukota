import { observable, action, computed, toJS } from 'mobx'
import Field from './Field'
import { getStore } from '../..'

export default class MobxForm {
    constructor(props = {}) {
        this.fields = this.getFields(props.initValues)
        this.errors = this.getErrors()
        this.store = getStore()
    }

    @observable fields = {}

    @observable submitting = false

    @observable submitted = false

    @observable submitFailed = false

    @observable errors

    @observable valid = true

    @observable error

    @computed
    get invalid() {
        return !this.valid
    }

    @action
    handleSubmit = async e => {
        e.preventDefault()
        this.submitting = true
        try {
            if (this.validate) {
                const errors = this.validate(this)
                if (this.invalid) {
                    this.submitFailed = true
                    throw toJS(errors)
                }
            }
            const result = await this.onSubmit(this)
            this.handleSubmitSuccess(result)
        } catch (e) {
            this.handleSubmitFail(e)
        }
    }

    @action
    handleSubmitSuccess = result => {
        this.submitted = true
        this.submitting = false
        this.submitFailed = false
        this.error = ''
        if (typeof this.onSubmitSuccess === 'function') {
            this.onSubmitSuccess(result, this)
        }
    }

    @action
    handleSubmitFail = e => {
        this.submitted = true
        this.submitting = false
        if (typeof this.onSubmitFail === 'function') {
            this.onSubmitFail(e, this)
        }
    }

    @action
    set = (property, value) => {
        this[property] = value
    }

    bind = path => {
        const { onChange, onFocus, onBlur, value, error, name } = this.fields[path]
        return {
            onChange,
            onFocus,
            onBlur,
            value,
            error,
            name
        }
    }

    @action
    clear = () => {
        Object.keys(this.fields).forEach(field => {
            this.fields[field].clear()
        })

        this.errors = this.getErrors()
    }

    getFields = (initValues = {}) => {
        const fields = {}
        this.initFields().forEach(item => {
            fields[item.name] = new Field(item, this, initValues[item.name])
        })

        return fields
    }

    getErrors = () => {
        const errors = {}
        this.initFields().forEach(item => {
            errors[item.name] = ''
        })

        return errors
    }

    getValues = () =>
        Object.keys(this.fields).reduce((acc, cur) => {
            acc[cur] = this.fields[cur].value
            return acc
        }, {})

    $ = path => this.fields[path]
}
