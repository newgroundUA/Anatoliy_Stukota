const errorCodes = {
    empty: 'This field should not be empty',
    notEnoughLength: 'Minimum length should be at least -',
    tooManySymbols: 'Maximum length should be no more than -'
}

const validator = fields => form => {
    const { errors } = form
    let valid = true

    fields.forEach(item => {
        // check required
        const field = form.fields[item.name]

        if (item.isRequired && !field.value && field.value !== 0) {
            errors[item.name] = errorCodes.empty
            valid = false
            return
        }

        if (item.minLength && field.value && field.value.length < item.minLength) {
            errors[item.name] = `${errorCodes.notEnoughLength} ${item.minLength}`
            valid = false
            return
        }

        if (item.maxLength && field.value && field.value.length > item.maxLength) {
            errors[item.name] = `${errorCodes.tooManySymbols} ${item.maxLength}`
            valid = false
            return
        }

        // make test
        if (item.test) {
            const result = item.test(field.value, form)
            if (result) {
                errors[item.name] = result
                valid = false
                return
            }
        }

        errors[item.name] = ''
    })

    form.valid = valid
    return errors
}

const passwordStrength = value =>
    value.match(/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])([0-9a-zA-Z !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]{9,})$/)
        ? ''
        : 'passwordStrength'

const emailStrength = value =>
    value.match(
        /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/
    )
        ? ''
        : 'emailIsNotWalid'

export { validator, passwordStrength, emailStrength }
