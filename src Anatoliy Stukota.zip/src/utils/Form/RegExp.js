const isDottedIPv4 = s => {
    const match = s.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/)
    return match != null && match[1] <= 255 && match[2] <= 255 && match[3] <= 255 && match[4] <= 255
}

export { isDottedIPv4 }
