import styled from 'styled-components'
import PropTypes from 'prop-types'
import { get } from '@utils/themeHelpers'
import is from 'styled-is'

const Table = styled.table`
    width: 100%;
    border-spacing: 0;
    max-width: 100%;
    background-color: transparent;
    
    h3, caption{
        font-weight: 400;
        text-align: left;
        padding-right: 1.375rem;
        font-size: 1.125rem;
        color: #FFFFFF;
    }

    table{
        width: 100%;
        table-layout: fixed;
        border-spacing: 0;
    }

    .SELL{
        color: ${get('red')};
    }
    .BUY{
        color: ${get('green')};
    }
    th{
        height: 2.25rem;
        font-weight: 600;
        font-size: .75rem;
        color: #808F92;
        text-align: center;
        padding: 0 0.125rem;
    }
    td{
        color: #CDD2D6;
        font-size: 0.75rem;
        text-align: center;
        padding: 0 0.125rem;
    }

    td:last-child, th:last-child {
        text-align: right;
    }
    td:first-child, th:first-child {
        text-align: left;
    }
    th:last-child{
        ${({ openOrders }) => openOrders && 'padding-right: .625rem;'}
    }
    ${is('main')`
        th, td{
            border-bottom: 1px solid #2F3847;
            height: 1.875rem;
            padding: 0 0.125rem;    
        }
        th{
            font-weight: 600;
            font-size: 0.75rem;
            color: #808F92;
        }
        td:last-child, th:last-child {
            text-align: right;
            padding-right: 0.3125rem;
        }
        
        td:first-child, th:first-child {
            text-align: left;
            padding-left: 0.3125rem;
        }
    `} 
    ${is('biggest')`
        th, td{
            height: 2.375rem;
        }
        th{
            border-bottom: none;
        }
    `}
    
    ${is('openOrders')`
        .amount{
            display: flex;
            justify-content: space-between;
            position: relative;
            height: 1.6875rem;
            color: #6A7380;
            line-height: 1.8125rem;
            margin-top: -0.3125rem;
        }
        .progress{
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 0.125rem;
            display: block;
            content: '';
            background-color: #6A7380;
            border-radius: 0.125rem;
            &>span{
            position: absolute;
            height: 0.125rem;
            content: '';
            display: block;
            border-radius: 0.125rem;
        }
        &.big{
            height: 0.375rem;
            border-radius: 0.375rem;
            bottom: 0.625rem;
            &>span{
                height: 0.375rem;
                border-radius: 0.375rem 0 0 0.375rem;
            }  
        }
        &.BUY>span{
            background-color: #02E866; 
        }
        &.SELL>span{
            background-color: #FF4A68;
        }
        }
    `}
    ${is('clickable')`
        tbody{
            tr{
                cursor: pointer;
            }
            tr:hover{
                background: #1A2130;
            }
        }
    `}
     ${({ history }) =>
         history &&
         `
        td:last-child, th:last-child {
            padding-right: 1.25rem;
        }
        td:first-child, th:first-child {
            padding-left: 1.25rem;
        }
    `}
     
`
const Actions = styled.div`
    a {
        margin: 0 0.75rem;
        position: relative;
        cursor: pointer;
        font-size: 0.8125rem;
        font-weight: 600;
        color: #6a7380;
        &:hover {
            color: #000000;
        }
        &.active {
            color: #808f92;
            font-weight: 600;
            cursor: default;
            &:after {
                position: absolute;
                bottom: -0.4375rem;
                width: 96%;
                left: 2%;
                display: block;
                content: '';
                height: 0.125rem;
                background-color: #09c35f;
            }
        }
    }
`
Table.propTypes = {
    clickable: PropTypes.any
}
export { Table, Actions }
