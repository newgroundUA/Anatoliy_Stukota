import React from 'react'
import PropTypes from 'prop-types'
import { observer } from 'mobx-react'
import { Loading } from 'common'
import NoData from 'common/NoData'
import { TableWrap, Actions } from './styled'

const Items = observer(
    ({ rowKey = 'id', columns, data, entity, onRowClick }) =>
        data.length > 0 ? (
            <div>
                <table>
                    <tbody>
                        {data.map((item, index) => (
                            <tr
                                key={entity ? item : item[rowKey] || index}
                                onClick={onRowClick ? e => onRowClick(item, e) : null}
                            >
                                {columns.map(item => (
                                    <td key={item.data || item.key} style={item.style}>
                                        {item.render
                                            ? item.render(
                                                  item.data ? data[index][item.data] : data[index],
                                                  data[index],
                                                  entity
                                              )
                                            : data[index][item.data]}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        ) : (
            <NoData>No Orders</NoData>
        )
)

const _Table = ({ columns, caption, actions, data, rowKey, loading, entity, onRowClick, ...rest }) => (
    <TableWrap {...rest}>
        {caption && <h3>{caption}</h3>}
        {actions && <Actions>{actions}</Actions>}
        <Loading loading={loading}>
            <div className="table__head">
                <table>
                    <thead>
                        <tr>
                            {columns.map(item => (
                                <th style={item.style} key={item.key || item.data}>
                                    {item.title}
                                </th>
                            ))}
                        </tr>
                    </thead>
                </table>
            </div>
            <div className="scrollbar">
                <Items data={data} columns={columns} rowKey={rowKey} entity={entity} onRowClick={onRowClick} />
            </div>
        </Loading>
    </TableWrap>
)

_Table.propTypes = {
    ...TableWrap.propTypes,
    rowKey: PropTypes.string,
    columns: PropTypes.array.isRequired,
    data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
    entity: PropTypes.object
}

export default _Table
