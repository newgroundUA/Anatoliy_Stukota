import PropTypes from 'prop-types'
import { get } from '@utils/themeHelpers'
import is, { isOr } from 'styled-is'
import { Table as _Table } from '../styled'

const TableWrap = _Table.withComponent('div').extend`
    h3, caption{
        padding-right: 1.375rem;
        float: left;
        padding-left: 1.25rem;
        padding-bottom: 0.5rem;
    }
   
    td{
        height: 1.4375rem;
    }
    .scrollbar tr{
        transition: all .3s;
    }

    .table__head{
        padding-right: 1px;
    }
    ${isOr('buy', 'sell')`
        caption{
            float: none;
        }
        .scrollbar{
            height: calc((100vh - 8.875rem - 3.0625rem - 2.5rem - 4.875rem) / 2);
            min-height: 10.9375rem;
        }
        td:last-child, th:last-child {
            padding-right: 1.25rem;
        }
        td:first-child, th:first-child {
            padding-left: 1.25rem;
        }
        .scrollbar tr:hover{
            transition: all .3s;
            cursor: pointer;
        }
    `}
    
    ${is('sell')`
        .scrollbar tr:hover{
            background-color: #2E293C;
        }
        td:first-child{
            color: ${get('red')};
        }
    `}
    
    ${is('buy')`
        .scrollbar tr:hover{
            background-color: #194341;
        }
        td:first-child{
            color: ${get('green')};
        }
    `}
    
   
    ${is('tradeBottom')`
        .scrollbar{
            padding-right: 1.1875rem; 
            height: 10.3125rem;
        }
        .table__head{
            padding-right: 1.25rem;
        }
        th,td{
            padding: 0 0.125rem;
        }
    `}
    ${is('openOrders')`
        .table__head{
            padding-right: 0.3125rem;
        }
    `}

     ${({ history }) =>
         history &&
         `
        .scrollbar{
            padding-right: 1px;
            height: calc(100vh - 8.875rem);
            min-height: 435px;   
        }
        .table__head{
            padding-right: 1px;
        }
    `}

`

TableWrap.propTypes = {
    buy: PropTypes.any,
    sell: PropTypes.any,
    history: PropTypes.any,
    openOrders: PropTypes.any
}
export { Actions } from '../styled'
export { TableWrap }
