import { Table as _Table } from '../styled'

const Table = _Table.extend`
    caption{
        padding-bottom: 0.9375rem;
     }
    th{
        height: 1.75rem;
    }
`

export { Table }
