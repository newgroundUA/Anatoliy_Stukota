import React from 'react'
import PropTypes from 'prop-types'
import { observer } from 'mobx-react'
import NoData from 'common/NoData'
import { Loading } from 'common'
import { Table } from './styled'

const Items = observer(
    ({ rowKey = 'id', columns, data }) =>
        data.length > 0 ? (
            <tbody>
                {data.map((item, index) => (
                    <tr key={item[rowKey] || index}>
                        {columns.map(item => (
                            <td key={item.data || item.key} style={item.style}>
                                {item.render
                                    ? item.render(item.data ? data[index][item.data] : data[index], data[index])
                                    : data[index][item.data]}
                            </td>
                        ))}
                    </tr>
                ))}
            </tbody>
        ) : (
            <tbody>
                <tr>
                    <td colSpan="10">
                        <NoData>No Orders</NoData>
                    </td>
                </tr>
            </tbody>
        )
)

const _Table = ({ columns, caption, data, rowKey, loading, ...rest }) => (
    <Loading loading={loading}>
        <Table {...rest}>
            {caption && <caption>{caption}</caption>}
            <thead>
                <tr>
                    {columns.map(
                        item =>
                            item.title ? (
                                <th style={item.style} key={item.key || item.data}>
                                    {item.title}
                                </th>
                            ) : null
                    )}
                </tr>
            </thead>
            <Items data={data} columns={columns} rowKey={rowKey} />
        </Table>
    </Loading>
)

_Table.propTypes = {
    ...Table.propTypes,
    rowKey: PropTypes.string,
    columns: PropTypes.array.isRequired,
    data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired
}

export default _Table
