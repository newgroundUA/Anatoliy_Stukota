import React from 'react'
import { autorun } from 'mobx'
import { inject } from 'mobx-react'

const support = Component =>
    class Support extends React.Component {
        componentDidMount() {
            autorun(() => {
                const { app } = this.props
                if (app && app.user && window.$zopim) {
                    window.$zopim.livechat.setName(app.user.login)
                    window.$zopim.livechat.setEmail(app.user.login)
                }
            })
            if (window.zE) {
                window.zE.show()
            } else {
                this.script = document.createElement('script')
                this.script.onload = () => {
                    window.zE(() => {
                        window.$zopim(() => {
                            const live = window.$zopim.livechat
                            live.theme.setColor('#0fe866')
                            live.theme.reload()
                            live.window.setTitle('Live Chat')
                            live.concierge.setName('Customer Service')
                            live.concierge.setTitle('How Can We Help?')
                            const { app } = this.props
                            if (app.user) {
                                live.setName(app.user.login)
                                live.setEmail(app.user.login)
                            }
                            window.zE.show()
                        })
                    })
                }
                this.script.src = '/static/zenDesk.js'
                this.script.async = true
                document.head.appendChild(this.script)
            }
        }

        render() {
            return <Component {...this.props} />
        }
    }

const withSupport = (withUser = true) => Component =>
    withUser ? inject('app')(support(Component)) : support(Component)

export default withSupport
