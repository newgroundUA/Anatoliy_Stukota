import React from 'react'
import styled from 'styled-components'
import { Button, Tabs, Tab, MaterialInput } from 'common'
import { Link } from 'react-router-dom'

const Wrap = styled.section`
    background-color: #21242f;
    padding: 3.125rem;
    height: 100vh;
`

export default () => (
    <Wrap>
        <Link to="/" style={{ paddingBottom: '1.25rem', display: 'block' }}>
            Go home
        </Link>
        <p>
            <Button>Button</Button>
            <Button loading>Button</Button>
            <Button disabled>Button</Button>
        </p>
        <p>
            <Button red>Button</Button>
            <Button red loading>
                Button
            </Button>
            <Button red disabled>
                Button
            </Button>
        </p>
        <div>
            <p>secondary</p>
            <Button secondary>Button</Button>
            <Button secondary loading>
                loading
            </Button>
            <Button secondary disabled>
                Button
            </Button>
        </div>

        <br />
        <br />
        <div>
            <Tabs active="0">
                <Tab label="Limit" value="0">
                    I am tab 1
                </Tab>
                <Tab label="Market" value="1">
                    I am tab 2
                </Tab>
                <Tab label="Stop" value="2">
                    I am tab 3
                </Tab>
            </Tabs>
        </div>
        <div>
            <MaterialInput label="Test" error="asdasd" placeholder="Test" />
        </div>
    </Wrap>
)
