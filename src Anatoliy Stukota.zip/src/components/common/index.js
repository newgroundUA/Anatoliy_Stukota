import styled from 'styled-components'
import PropTypes from 'prop-types'
import { renderRoutes } from 'react-router-config'
import ReactPaginate from 'react-paginate'
import React from 'react'
import is from 'styled-is'
import { Icon } from 'common'

const renderNestedRoutes = ({ route }) => renderRoutes(route.routes)

const TextBig = styled.p`
    font-size: 1.5rem;
    text-transform: uppercase;
    font-weight: 400;
    color: #000;
`

const Flex = styled.div`
    display: flex;
    ${is('button')`align-items: flex-end;`}
    ${is('center')`align-items: center;`}
    ${is('between')`justify-content: space-between;`}
`

const ButtonWrap = styled.div`
    text-align: center;
    margin-top: 0.625rem;
    ${is('left')`text-align: left;`};
`

const RecaptchaWrap = styled.div``

const ColTitle = styled.h3`
    font-weight: 400;
    text-align: left;
    padding-right: 1.375rem;
    font-size: 1.125rem;
`

const Paginate = styled(({ className, ...rest }) => (
    <ReactPaginate
        {...rest}
        containerClassName={className}
        nextLabel={<Icon name="pagination" />}
        previousLabel={<Icon name="pagination" />}
    />
))`
    text-align: left;
    list-style: none;
    margin-top: 2.5rem;
    li {
        display: inline-block;
        margin-left: -1px;
    }
    a {
        font-size: 0.75rem;
        color: #6a7380;
        padding: 0 0.3125rem;
        width: 1.75rem;
        height: 1.75rem;
        line-height: 1.75rem;
        box-sizing: border-box;
        display: inline-block;
        text-align: center;
        cursor: pointer;
        border: 1px solid #2f3847;
    }

    .next {
        transform: rotate(180deg);
    }
    li:not(.disabled):not(.selected):hover {
        a {
            background-color: #28344f;
            color: #fff;
            cursor: pointer;
        }
    }
    .disabled a {
        cursor: not-allowed;
    }
    .selected {
        a {
            cursor: default;
            color: #fff;
            background-color: #00bd52;
        }
    }
`

Flex.propTypes = {
    between: PropTypes.any,
    button: PropTypes.any
}

export { default as FormattedNumber } from './FormattedNumber'
export * from './Tabs'
export * from './FormElements'
export { default as NoData } from './NoData'
export { default as DateTime } from './DateTime'
export { default as Icon } from './Icons'
export { default as Loading } from './Loading'
export { Table, ScrollableTable } from './Table'
export { default as inScope } from './inScope'
export { default as Progress } from './Progress'
export { TextBig, ColTitle, Flex, ButtonWrap, RecaptchaWrap, renderNestedRoutes, Paginate }
export { default as Particles } from './Particles'
export { default as Warning } from './FeaturesWarning'
export { default as withSupport } from './WithSupport'
export { default as Tooltip } from './Tooltip'
