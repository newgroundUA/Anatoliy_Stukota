import React from 'react'
import PropTypes from 'prop-types'
import { Wrapper, Content, Toolbar } from './styled'

export default class Collapsible extends React.Component {
    static propTypes = {
        children: PropTypes.element.isRequired,
        name: PropTypes.string.isRequired,
        delay: PropTypes.number,
        toolbar: PropTypes.oneOf(['left', 'right', 'top', 'bottom']),
        maxSize: PropTypes.string.isRequired,
        title: PropTypes.string
    }

    static defaultProps = {
        delay: 200,
        toolbar: 'top'
    }

    constructor(props) {
        super(props)
        const state = JSON.parse(window.localStorage.getItem(this.props.name))

        this.state = {
            opened: typeof state === 'boolean' ? state : true,
            isOpening: false,
            isClosing: false
        }
    }

    open = () => {
        this.setState(
            {
                isOpening: true
            },
            () => {
                this.setState({ opened: true })
            }
        )

        setTimeout(() => {
            this.setState({
                isOpening: false
            })
        }, this.props.delay)
        window.localStorage.setItem(this.props.name, true)
    }

    close = () => {
        this.setState({
            isClosing: true
        })

        setTimeout(() => {
            this.setState({
                opened: false,
                isClosing: false
            })
        }, this.props.delay)
        window.localStorage.setItem(this.props.name, false)
    }

    render() {
        const { opened, isOpening, isClosing } = this.state
        const { title } = this.props
        return (
            <Wrapper toolbar={this.props.toolbar}>
                <Toolbar
                    onClick={opened ? this.close : this.open}
                    opened={opened}
                    toolbar={this.props.toolbar}
                    delay={this.props.delay}
                >
                    <span>{title}</span>
                </Toolbar>
                <Content
                    isOpen={opened && !isClosing}
                    maxSize={this.props.maxSize}
                    toolbar={this.props.toolbar}
                    delay={this.props.delay}
                >
                    {opened || isOpening ? this.props.children : null}
                </Content>
            </Wrapper>
        )
    }
}
