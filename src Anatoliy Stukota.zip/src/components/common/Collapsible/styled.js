import styled from 'styled-components'

const actionWidth = '0.9375rem'
const actionSmallWidth = '1.5rem'

const Content = styled.div`
    max-width: 100%;
    max-height: 100%;
    transition: ${({ delay }) => delay / 1000}s ease-out;
    overflow: hidden;
    opacity: 0;
    min-height: 0;
    ${({ isOpen, toolbar, maxSize }) => `
    
        ${
            toolbar === 'left' || toolbar === 'right'
                ? `width: ${isOpen ? `${maxSize}` : 0};`
                : `
            height: ${isOpen ? `${maxSize}` : 0};
            max-height: ${isOpen ? `${maxSize}` : 0};
            min-height: ${isOpen ? `${maxSize}` : 0};
        `
        }; 
        ${toolbar === 'top' && isOpen && 'padding: 0 0.1875rem 0.625rem 1.3125rem;box-sizing: border-box;'}; 
    
    `};
    ${({ isOpen }) => isOpen && 'opacity: 1;'};
`

const Wrapper = styled.div`
    display: flex;
    flex-direction: ${({ toolbar }) =>
        toolbar === 'right'
            ? 'row-reverse'
            : toolbar === 'top'
                ? 'column'
                : toolbar === 'bottom'
                    ? 'column-reverse'
                    : 'row'};
`

const Toolbar = styled.a`
    text-align: center;
    display: block;
    cursor: pointer;
    position: relative;
    box-sizing: border-box;
    transition: all ${({ delay }) => delay / 1000}s;
    span {
        font-size: 0.625rem;
        color: #6a7380;
        display: inline-block;
        position: absolute;
        white-space: nowrap;
    }
    &:hover {
        transition: all ${({ delay }) => delay / 1000}s;
        background-color: rgba(249, 249, 249, 0.03);
        filter: brightness(1.5);
        &:before {
            width: 0.375rem;
            height: 0.375rem;
        }
    }
    &:before {
        width: 0.3125rem;
        height: 0.3125rem;
        display: block;
        content: '';
        border-top: 1px solid #6a7380;
        border-right: 1px solid #6a7380;
        position: absolute;
        transition: all ${({ delay }) => delay / 1000}s;
    }
    @media (max-width: 1455px) {
        &:before {
            width: 0.6rem;
            height: 0.6rem;
        }
        &:hover {
            &:before {
                width: 0.7rem;
                height: 0.7rem;
            }
        }
    }
    ${({ toolbar }) =>
        (toolbar === 'left' || toolbar === 'right') &&
        `
        border-right: 1px solid #444;
        border-left: 1px solid #444;
        width: ${actionWidth};
        min-width: ${actionWidth};
        span{
            transform: rotate(-180deg);
            writing-mode: tb-rl;
            bottom: 51%;
            left: -1px;
        } 
        &:before{
            top: 50%;
        }
        @media(max-width: 1455px){
            width: ${actionSmallWidth};
            min-width: ${actionSmallWidth};  
            span{
                font-size: 1rem;
            }  
        }
    `} ${({ toolbar, opened }) =>
        toolbar === 'left'
            ? `
            &:before{
                ${opened ? 'transform: rotate(45deg);left: 0.125rem;' : 'transform: rotate(225deg);left: 0.3125rem;'}
            }
        `
            : toolbar === 'right'
                ? `
         &:before{
                ${opened ? 'transform: rotate(225deg);left: 0.3125rem;' : 'transform: rotate(45deg);left: 0.125rem;'}
            }
        `
                : toolbar === 'top'
                    ? `
                border-top: 1px solid #444;
                border-bottom: 1px solid #444;
                width: 100%;
                height: ${actionWidth};
                min-height: ${actionWidth};
                &:before{
                    left: 50%;
                    ${opened ? 'transform: rotate(135deg);top: 0.125rem;' : 'transform: rotate(315deg);top: 0.3125rem;'}
                }
                @media(max-width: 1455px){
                    height: ${actionSmallWidth};
                    min-height: ${actionSmallWidth};  
                }
  `
                    : ''};
`

export { Wrapper, Content, Toolbar }
