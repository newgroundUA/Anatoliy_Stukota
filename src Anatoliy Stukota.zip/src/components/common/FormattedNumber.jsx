import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { format } from '@utils'

const Rest = styled.span`
    opacity: 0.5;
`

const FormattedNumber = ({ value, scale = 8 }) => {
    const { int, decimal, rest } = format(value, scale)
    return (
        <React.Fragment>
            {int}
            {decimal.length > 0 && (
                <React.Fragment>
                    .{decimal}
                    <Rest>{rest}</Rest>
                </React.Fragment>
            )}
        </React.Fragment>
    )
}

FormattedNumber.propTypes = {
    value: PropTypes.number.isRequired,
    scale: PropTypes.number
}

export default FormattedNumber
