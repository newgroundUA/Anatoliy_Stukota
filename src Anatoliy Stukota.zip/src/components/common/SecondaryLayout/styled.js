import styled from 'styled-components'
import is from 'styled-is'
import { ButtonWrap as _ButtonWrap } from 'common'

const Wrap = styled.section`
    width: ${({ width }) => width || '46.25rem'};
    max-width: ${({ width }) => width || '46.25rem'};
    padding: 3.75rem 1.5625rem 4.375rem;
    text-align: center;
    background: #1f273b;
    box-shadow: 0 0.125rem 0.375rem 0 rgba(35, 47, 75, 0.2);
    //todo: check all svg
    & > svg {
        padding-bottom: 1.5rem;
    }
`
const Content = styled.div`
    width: ${({ width }) => width || '46.25rem'};
    ${is('center')`text-align: center;`};
    max-width: 100%;
`

const Title = styled.div`
    font-weight: 600;
    font-size: 1.5rem;
    color: #ffffff;
    padding-bottom: 0.5625rem;
`

const Text = styled.p`
    font-weight: 600;
    font-size: 0.875rem;
    color: #cdd2d6;
    line-height: 1.4375rem;
    & + & {
        padding-top: 1rem;
    }
`

const ButtonWrap = styled(_ButtonWrap)`
    margin-top: 3.125rem;
`
const MainTitle = styled.h1`
    font-size: 2.5rem;
    color: #ffffff;
    padding-bottom: 2rem;
    font-weight: 500;
    ${is('noPadding')`
        padding-bottom: 0.625rem;       
    `};
`
const FormWrap = styled.div`
    padding-top: 3.75rem;
`

export { Wrap, Content, Title, Text, ButtonWrap, MainTitle, FormWrap }
