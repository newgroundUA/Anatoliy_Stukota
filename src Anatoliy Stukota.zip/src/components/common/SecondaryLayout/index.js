import styled from 'styled-components'
import { Icon as _Icon } from 'common/index'

const Icon = styled(_Icon)`
    font-size: 7.3125rem;
    color: #02e866;
    padding-bottom: 1.5rem;
    display: inline-block;
`

export * from './styled'
export { Icon }
