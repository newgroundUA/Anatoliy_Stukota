import React from 'react'
import debounce from 'debounce'

const dotsCount = 30
const colors = {
    1: 'rgba(2, 232, 102, 0.1)',
    2: 'rgba(2, 232, 102, 0.3)',
    3: 'rgba(2, 232, 102, 0.8)',
    4: 'rgba(2, 232, 102, 1)'
}
const minRadius = 2
const maxRadius = 6
const dots = []

export default class Particles extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            width: window.innerWidth,
            height: window.innerHeight
        }
    }

    componentDidMount = () => {
        this.ctx = this.canvas.getContext('2d')
        if (!dots.length) {
            this.start()
        }
        this.interval = setInterval(this.animate, 16)

        window.addEventListener('resize', this.handleResize)
    }

    componentWillUnmount = () => {
        window.removeEventListener('resize', this.handleResize)
        clearInterval(this.interval)
    }

    handleResize = debounce(() => {
        this.setState({
            width: window.innerWidth,
            height: window.innerHeight
        })
    }, 100)

    start = () => {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)
        for (let i = 0; i < dotsCount; i++) {
            dots.push(this.makeDot())
        }
    }

    animate = () => {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)
        for (let i = 0; i < dotsCount; i++) {
            const dot = dots[i]
            const { x, y, dx, dy } = dot

            if (y < 0 || y > this.canvas.height) {
                dot.dx = dx
                dot.dy = -dy
            } else if (x < 0 || x > this.canvas.width) {
                dot.dx = -dx
                dot.dy = dy
            }
            dot.x += dot.dx
            dot.y += dot.dy
            this.makeDot(dots[i])
        }
    }

    makeDot = (props = {}) => {
        const {
            x = this.makeCoordiante('x'),
            y = this.makeCoordiante('y'),
            color = colors[this.randomInteger(1, 4)],
            radius = this.randomInteger(minRadius, maxRadius)
        } = props

        this.ctx.beginPath()
        this.ctx.arc(x, y, radius, 0, 2 * Math.PI)
        this.ctx.fillStyle = color
        this.ctx.fill()

        const dx = (-0.5 + Math.random()) / 3
        const dy = (-0.5 + Math.random()) / 3
        return {
            x,
            y,
            color,
            dx,
            dy,
            radius
        }
    }

    makeCoordiante = prop => this.randomInteger(0, prop === 'x' ? this.canvas.width : this.canvas.height)

    randomInteger = (min, max) => {
        let rand = min + Math.random() * (max + 1 - min)
        rand = Math.floor(rand)
        return rand
    }

    render() {
        const { className } = this.props
        return (
            <canvas
                className={className}
                width={this.state.width}
                height={this.state.height}
                ref={node => {
                    this.canvas = node
                }}
            />
        )
    }
}
