import styled from 'styled-components'
import { Button as _Button } from 'common'

const Wrap = styled.div`
    min-width: 47.5rem;
    max-width: 97%;
    text-align: center;
    padding: 4.0625rem 2.5rem 4.375rem 2.5rem;
    box-sizing: border-box;
    background: #1f273b;
    box-shadow: 0 1.25rem 4.125rem 0 rgba(35, 47, 75, 0.2);
    h2 {
        font-weight: 600;
        font-size: 1.5rem;
        color: #ffffff;
        padding-bottom: 0.5625rem;
        padding-top: 1.5rem;
    }
    p {
        font-weight: normal;
        font-size: 0.875rem;
        color: #cdd2d6;
        line-height: 1.4375rem;
        padding-bottom: 2.5rem;
    }
`
const Button = styled(_Button)`
    min-width: 16.875rem;
`

export { Wrap, Button }
