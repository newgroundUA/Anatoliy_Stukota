import React from 'react'
import PropTypes from 'prop-types'
import shallowEqual from 'shallowequal'
import { Elements, Wrapper, Actions, Header } from './styled'

export default class Tabs extends React.Component {
    static propTypes = {
        active: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        children: PropTypes.arrayOf(PropTypes.node),
        actions: PropTypes.node
    }

    static defaultProps = {
        active: 0
    }

    constructor(props) {
        super(props)
        this.state = {
            active: props.active,
            width: '0',
            left: '0'
        }
        this.tabs = {}
    }

    componentDidMount = () => {
        setTimeout(() => this.updateIndicator(), 50)

        window.addEventListener('resize', this.handleResize)
    }

    componentWillReceiveProps = nextProps => {
        if (!shallowEqual(nextProps.active !== this.props.active)) {
            this.setState({
                active: nextProps.active
            })
            this.updateIndicator(nextProps.active)
        }
    }

    componentWillUnmount = () => {
        window.removeEventListener('resize', this.handleResize)
    }

    setActiveElement = item => {
        this.setState({
            active: item
        })
        this.updateIndicator(item)
    }

    getSelectedElement = elements => {
        const { active } = this.state
        const element = elements.find(item => item.props.value === active)
        if (element) return element

        return null
    }

    handleResize = () => {
        clearTimeout(this.timer)
        this.timer = setTimeout(() => {
            this.updateIndicator()
        }, 100)
    }

    valueToIndex = {}

    updateIndicator = (active = this.state.active) => {
        if (active !== undefined && active !== null) {
            const index = this.valueToIndex[active]
            const { offsetLeft, clientWidth } = this.tabs.children[index]

            this.setState({
                left: `${offsetLeft}px`,
                width: `${clientWidth}px`
            })
        }
    }

    check = item => this.state.active === item

    render() {
        const { children, actions, headStyle, border } = this.props
        const elements = React.Children.toArray(children)
            .filter(child => React.isValidElement(child))
            .map((element, index) => {
                const key = element.props.value || index
                this.valueToIndex[key] = index

                return React.cloneElement(element, {
                    active: this.check(key),
                    setActiveElement: this.setActiveElement,
                    value: key
                })
            })

        const selectedElement = this.getSelectedElement(elements)

        return (
            <Wrapper>
                <Header style={headStyle} border={border}>
                    <Elements
                        indicatorPosition={{ left: this.state.left, width: this.state.width }}
                        isSelected={this.state.active !== undefined && this.state.active !== null}
                        innerRef={node => {
                            this.tabs = node
                        }}
                    >
                        {elements}
                    </Elements>
                    {actions && <Actions>{actions}</Actions>}
                </Header>

                <div>{selectedElement && selectedElement.props.children}</div>
            </Wrapper>
        )
    }
}
