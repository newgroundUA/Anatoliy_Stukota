import React from 'react'
import PropTypes from 'prop-types'
import { Element } from './styled'

export default class Tab extends React.PureComponent {
    static propTypes = {
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]).isRequired,
        onClick: PropTypes.func
    }

    handleClick = e => {
        const { setActiveElement, onClick } = this.props
        if (onClick) {
            onClick(this.props.value, e)
        } else {
            setActiveElement(this.props.value, e)
        }
    }

    render() {
        const { className } = this.props
        return (
            <li ref={this.props.innerRef} className={className}>
                <Element isActive={this.props.active} onClick={this.handleClick}>
                    {this.props.label}
                </Element>
            </li>
        )
    }
}
