import styled from 'styled-components'

const Wrapper = styled.div`
    position: relative;
`
const Header = styled.div`
    border-bottom: ${({ border = true }) => (border ? '1px solid #2f3847' : '0')};
    padding-top: 0.625rem;
    position: relative;
`

const Elements = styled.ul`
    position: relative;
    display: inline-block;
    li {
        margin: 0 0.625rem;
        display: inline-block;
        &:first-child {
            margin-left: 0;
        }
        &:last-child {
            margin-right: 0;
        }
    }
    ${({ indicatorPosition, isSelected }) =>
        isSelected &&
        ` 
    &::before{
      transition: .3s;
      content: '';
      position: absolute;
      bottom: -1px;
      left: ${indicatorPosition.left};
      height: 0.125rem;
      width: ${indicatorPosition.width};
      background-color: #02E866;
    }
  `};
`

const Element = styled.a`
    display: block;
    padding-bottom: 0.625rem;
    color: #808f92;
    transition: 0.3s;
    cursor: pointer;
    font-size: 0.875rem;
    &:hover {
        color: #02e866;
    }
    ${({ isActive }) =>
        isActive &&
        `
        &:hover, &{
            cursor: default;
            color: white;
        }
  `};
`

const Actions = styled.div`
    float: right;
`

export { Elements, Element, Wrapper, Actions, Header }
