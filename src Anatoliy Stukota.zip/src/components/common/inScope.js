import React from 'react'

export default ({ offset = 100 }) => Component =>
    class InScope extends React.Component {
        state = {
            inScope: false
        }

        componentDidMount = () => {
            window.addEventListener('scroll', this.check)
        }

        componentWillUnmount = () => {
            window.removeEventListener('scroll', this.check)
        }

        check = () => {
            if (!this.state.inScope && this.item.getBoundingClientRect().top - window.innerHeight + offset < 0) {
                this.setState({
                    inScope: true
                })
                window.removeEventListener('scroll', this.check)
            }
        }

        render() {
            return (
                <Component
                    {...this.props}
                    innerRef={item => {
                        this.item = item
                    }}
                    inScope={this.state.inScope}
                />
            )
        }
    }
