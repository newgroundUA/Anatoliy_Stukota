import React from 'react'
import { PropgressBar } from './styled'

export default class index extends React.Component {
    render() {
        const { maxSize, currentSize } = this.props
        return <PropgressBar maxSize={maxSize} currentSize={currentSize} />
    }
}
