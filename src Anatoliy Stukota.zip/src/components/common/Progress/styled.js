import styled from 'styled-components'

const height = '0.375rem'

const PropgressBar = styled.div`
    height: ${height};
    max-width: ${({ maxSize }) => maxSize};
    background: #6a7380;
    border-radius: 0.3125rem;
    display: block;
    position: relative;
    &:before {
        content: '';
        height: ${height};
        width: ${({ currentSize }) => currentSize}%;
        background: #0d9954;
        border-radius: 0.3125rem 0 0 0.3125rem;
        display: inline-block;
        position: absolute;
    }
`

export { PropgressBar }
