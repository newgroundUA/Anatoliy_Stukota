import React from 'react'
import { inject, observer } from 'mobx-react'
import Message from 'i18n/Message'
import { Warning } from './styled'

@inject('app')
@observer
export default class WarningComponent extends React.Component {
    render() {
        const {
            app: { features }
        } = this.props
        if (!features || !Object.keys(features).some(i => !features[i])) {
            return null
        }
        const allServices = {
            isDepositsEnabled: <Message id="deposit" />,
            isWithdrawalsEnabled: <Message id="withdrawal" />,
            isSignUpActivationEnabled: <Message id="signUp" />,
            isOrderPlacingEnabled: <Message id="orderPlacing" />
        }
        const disabledServices = Object.keys(features).filter(i => features[i] === false)
        const unavailableServices = disabledServices.map(
            (service, i) =>
                i ? <span key={i}>, {allServices[service]}</span> : <span key={i}>{allServices[service]}</span>
        )

        return (
            <Warning>
                <Message id="currentlyTheseServicesAreUnavailable" /> {unavailableServices}
            </Warning>
        )
    }
}
