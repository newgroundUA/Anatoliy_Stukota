import styled from 'styled-components'

const Warning = styled.div`
    padding: 10px 10px;
    background: #dec304;
    border-radius: 2px;
    color: black;
    font-size: 0.825rem;
    margin-bottom: 10px;
`

export { Warning }
