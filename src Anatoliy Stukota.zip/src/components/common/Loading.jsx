import React from 'react'
import styled from 'styled-components'
import is from 'styled-is'
import Icon from './FormElements/icons/bg/bg_spinner.svg'

const Wrap = styled.div`
    position: relative;
    clear: both;
    &:before {
        transition: all 0.25s;
        width: 100%;
        min-height: 100%;
        position: absolute;
        left: 0;
        top: 0;
        background-color: #1f273b;
        display: block;
        content: '';
        opacity: 0;
        z-index: -1;
    }
    &:after {
        position: absolute;
        top: 0;
        bottom: 0;
        right: 0;
        left: 0;
        width: 5rem;
        height: 5rem;
        content: '';
        margin: auto;
        transition: 0.25s;
        background-image: url(${Icon});
        background-repeat: no-repeat;
        background-position: center;
        opacity: 0;
        z-index: -1;
        display: none;
    }

    ${is('loading')`
        &:before{
            transition: all .25s;
            opacity: 0.86;
            z-index: 0;
        }
        &:after{
            transition: all .25s;
            opacity: 1;
            z-index: 8;
            display: block;
        }
    `};
`

export default ({ loading, children }) => <Wrap loading={loading}>{children}</Wrap>
