import React from 'react'
import styled from 'styled-components'

const Inline = styled.span`
    white-space: nowrap;
`

export default ({ time, timeOnly }) => {
    const date = new Date(time)
    return (
        <React.Fragment>
            {!timeOnly ? (
                <span>
                    {date.toLocaleString('en-US', { month: 'short', day: 'numeric' })}{' '}
                    {date.toLocaleString('en-US', { year: 'numeric' })},
                    <Inline> {date.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric' })}</Inline>
                </span>
            ) : (
                <Inline>
                    {date.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', second: 'numeric' })}
                </Inline>
            )}
        </React.Fragment>
    )
}
