import React from 'react'
import { Wrap, Tooltip } from './styled'

export default ({ children, text, side, inline, width }) => (
    <Wrap inline={inline} side={side}>
        <Tooltip side={side} width={width}>
            {text}
        </Tooltip>
        {children}
    </Wrap>
)
