import styled from 'styled-components'

const Tooltip = styled.div`
    position: absolute;
    visibility: hidden;
    opacity: 0;
    ${({ side }) => {
        switch (side) {
            case 'left':
                return 'top: 50%; transform: translate(-10%, -50%); right: calc(100% + 10px);'
            case 'right':
                return 'top: 50%; transform: translate(10%, -50%); left: calc(100% + 10px);'
            case 'bottom':
                return 'left: 50%; transform: translate(-50%, 30%); top: calc(100% + 10px);'
            default:
                return 'left: 50%; transform: translate(-50%, -30%); bottom: calc(100% + 10px);'
        }
    }};
    transition: all 0.5s ease-out;
    width: ${({ width }) => width || 'auto'};
    white-space: ${({ width }) => (width ? 'auto' : 'nowrap')};
    background-color: #0D9954;
    padding: 6px 10px;
    border-radius: 6px;
    border: 1px solid #02e866;
    z-index: 99;
    &::after {
        content: " ";
        position: absolute;
        ${({ side }) => {
            switch (side) {
                case 'left':
                    return 'left: 100%; top: 50%; margin-top: -5px; border: 5px solid transparent; border-left-color: #02E866;'
                case 'right':
                    return 'right: 100%; top: 50%; margin-top: -5px; border: 5px solid transparent; border-right-color: #02E866;'
                case 'bottom':
                    return 'bottom: 100%; left: 50%; margin-left: -5px; border: 5px solid transparent; border-bottom-color: #02E866;'
                default:
                    return 'top: 100%; left: 50%; margin-left: -5px; border: 5px solid transparent; border-top-color: #02E866;'
            }
        }};
    }
}
`

const Wrap = styled.div`
    position: relative;
    display: ${({ inline }) => (inline ? 'inline' : 'block')};
    &:hover {
        ${Tooltip} {
            opacity: 1;
            visibility: visible;
            transform: ${({ side }) =>
                side === 'left' || side === 'right' ? 'translate(0, -50%);' : 'translate(-50%, 0);'};
        }
    }
`

export { Wrap, Tooltip }
