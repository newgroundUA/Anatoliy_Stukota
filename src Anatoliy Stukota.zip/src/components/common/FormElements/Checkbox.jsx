import React from 'react'
import { observer } from 'mobx-react'
import { Icon } from 'common'
import Message from 'i18n/Message'
import { Wrapper, Label, Error, Text } from './styled'

export default observer(({ field = {}, label, primary, className, inline, ...props } = {}) => {
    const bindings = field.bind && field.bind()

    return (
        <Wrapper checkbox primary={primary} className={className}>
            <Label>
                <input type="checkbox" {...bindings} {...props} />
                <Icon name="check" />
                <Text inline={inline}>{label || field.label}</Text>
            </Label>
            {(field.submitFailed || field.touched) &&
                field.error && (
                    <Error>
                        <Message id={field.error} />
                    </Error>
                )}
        </Wrapper>
    )
})
