import React from 'react'
import { Button } from './styled'
import Icon from '../icons/spinner.svg'

export default ({ children, loading, ...rest }) => (
    <Button {...rest} loading={loading}>
        {children}{' '}
        {loading && (
            <span>
                <Icon />
            </span>
        )}
    </Button>
)
