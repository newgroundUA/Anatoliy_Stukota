import styled from 'styled-components'
import PropTypes from 'prop-types'
import is, { isNot } from 'styled-is'

const Button = styled.button`
    font-family: inherit;
    text-align: center;
    border: none;
    padding: 0 .625rem;
    height: 2.625rem;
    line-height: 2.625rem;
    background-color: #00BD52;
    border-radius: 0;
    font-weight: 600;
    font-size: .8125rem;
    color: #fff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    position: relative;
    transition: all 0.3s;
    user-select: none;
    ${isNot('loading')`
        &:hover:not([disabled]){
            filter: brightness(1.2);   
            transition: all 0.3s;
            cursor: pointer; 
        }
        &:active:not([disabled]){
            filter: brightness(0.8);
            transition: all 0.3s;
        }
    `}

    ${is('loading')`
        background-color: #0D9954;
        border-color: transparent;
        color: #BBBEC0;
        span{    
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            min-height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            svg{
                width: 2.5rem!important;
                height: 2.5rem!important;
                circle{
                    stroke: #808F92;
                    fill: #808F92;
                }
            }
        }
    `}
         
    ${is('secondary')`
        background-color: transparent;
    `}  
    ${is('red')`
        background-color: #E84352;
    `}
    
    
    ${is('fullWidth')`
        width: 100%;
    `}
    
    ${is('single')`
        width: auto;
        margin: .625rem auto;
        min-width: 12.5rem;
        padding: 0 1.25rem;
    `}
    &:disabled{
      background-color: #1A2130;
      cursor: not-allowed;
      color: #6A7380;
    }
    &:disabled:active{
      background-color: #1A2130;
    }
    
`

Button.propTypes = {
    secondary: PropTypes.any,
    single: PropTypes.any,
    loading: PropTypes.any,
    fullWidth: PropTypes.any
}

export { Button }
