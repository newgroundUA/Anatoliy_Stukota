import styled from 'styled-components'
import PropTypes from 'prop-types'
import is, { isNot } from 'styled-is'
import Icon from '../Icons'

const EyeOpen = styled(Icon)`
    color: #4a90e2;
`
const Wrapper = styled.div`
    flex: auto;
    position: relative;
    padding-bottom: 0.625rem;
    input{
        width: 100%;
        background-color: #232D45;
        border: none;
        border-radius: 0;
        text-indent: .75rem;
        height: 2.625rem;
        box-sizing: border-box;
        transition: 0.3s;
        font-weight: 600;
        font-size: 0.875rem;
        color: #FFFFFF;
        &:focus{
            background-color: #273351;
            outline: none;
        }
    }
    select{
        width: 100%;
        height: 2.25rem;
        background-color: transparent;
        color: #9BA0AC;
        border: 1px solid #1C1F2D;
        &:focus{
            border-color: #89BCF8;
            outline: none;
        }
    }
    ${props =>
        props.primary &&
        `
        padding-bottom: 0.9375rem;
        input{
            border-color: ${props.error ? '#DB5C5C' : '#E2E5E7'};
        }
        
    `}
    ${props =>
        props.leftIcon &&
        `
        input{
            background-image: url(${props.leftIcon});
            background-position: 0.5rem center;
            background-repeat: no-repeat;
            text-indent: 2.5rem;
            
        }
    `}
    ${is('disabled')`
        label, input, input+span{
            cursor: not-allowed;
            opacity: .4;   
            user-select: none;    
        }
    `}
    
    ${is('checkbox')`
        flex: none;
        ${isNot('primary')`padding-bottom: 0;`}
        align-items: center;
        label{
            cursor: pointer;
        }    
        input{
            opacity: 0;
            width: 0;
            height: 0;
            position: absolute;
            z-index: -2;
            overflow: hidden;
        } 
        input+span{
            display: block;
            width: 1rem;
            height: 1rem;
            content: '';
            flex: none;
            margin-right: .625rem;
            border: 1px solid #6A7380;
            float: left;
            font-size: 0;
            text-align: center;
            line-height: 1rem;
            transition:  font-size .3s;
        }
        input:checked+span{
            border-color: #00BD52;
            background-color: #00BD52;
            position: relative;
            color: #fff;
            font-size: 0.75rem;
            transition:  font-size .3s;
        }      
    `}
    
    ${is('noPadding')`
        padding: 0;
    `}
    
`

const InputAddon = styled.div`
    position: relative;
    input {
        padding-right: 2.8125rem;
    }
    span {
        position: absolute;
        right: 0;
        bottom: 0;
        background-color: #232d45;
        line-height: 2.625rem;
        padding: 0 0.9375rem 0 0.3125rem;
        font-weight: 600;
        font-size: 0.875rem;
        color: #808f92;
        transition: 0.3s;
    }
    input:focus + span {
        background-color: #273351;
        transition: 0.3s;
    }
    ${({ disabled }) => disabled && 'opacity: .7'};
`
const InputPassword = styled.div`
    position: relative;
    span {
        position: absolute;
        right: 0.625rem;
        bottom: 0.75rem;
        user-select: none;
        cursor: pointer;
    }
    ${EyeOpen} {
        bottom: 0.8125rem;
    }
`
const Label = styled.label`
    padding-bottom: 0.1875rem;
    display: block;
    font-size: 0.75rem;
    color: #808f92;
`
const Error = styled.p`
    padding-top: 0.25rem;
    font-size: 0.6875rem;
    color: #db5c5c;
    text-align: left;
    font-weight: 600;
    animation: OpenBlock 0.6s forwards;
    ${props =>
        props.stickyError &&
        `
        position: absolute;
        top: 100%;
        left: 0;
    `};
`
const Extra = styled.div`
    text-align: right;
`
const ExtraTop = styled.span`
    float: right;
`

const Text = styled.div`
    display: block;
    padding-left: 1.5625rem;
    ${is('inline')`white-space: nowrap;`};
`
Wrapper.propTypes = {
    leftIcon: PropTypes.any,
    primary: PropTypes.any,
    checkbox: PropTypes.any
}

const ErrorMessage = Error.extend`
    font-size: 0.875rem;
`

export { Wrapper, Label, Error, InputAddon, InputPassword, Extra, ErrorMessage, EyeOpen, ExtraTop, Text }
