import _MaterialInput from './MaterialInput'
import formItem from './formItem'

export { default as Input } from './Input'
export { default as Switch } from './Switch'
export { default as Select } from './Select'
export { default as Checkbox } from './Checkbox'
export { default as Toggle } from './Toggle'
export { default as Button } from './Button'
export { default as DayPickerRange } from './DayPickerRange'
export { ErrorMessage } from './styled'

export const MaterialInput = formItem(_MaterialInput)
