import React from 'react'
import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import DayPickerInput from 'react-day-picker/DayPickerInput'
import 'react-day-picker/lib/style.css'

const Inputs = styled.div`
    display: flex;
    justify-items: flex-end;
    input {
        width: 100%;
        background-color: ${get('datePicker.bg')};
        font-size: 0.8125rem;
        color: ${get('datePicker.inputColor')};
        text-indent: 0.75rem;
        height: 2.25rem;
        box-sizing: border-box;
        transition: 0.3s;
        border: none;
        &:focus {
            outline: none;
        }
    }
    .DayPickerInput-Overlay {
        background-color: ${get('datePicker.bg')};
    }
    input::placeholder {
        color: ${get('datePicker.dayColor')};
    }
    .DayPicker-Weekday {
        opacity: 0.7;
        font-size: 0.75rem;
        color: ${get('datePicker.weekdayColor')};
    }
    .DayPicker:not(.DayPicker--interactionDisabled)
        .DayPicker-Day:not(.DayPicker-Day--disabled):not(.DayPicker-Day--selected):not(.DayPicker-Day--outside):hover {
        background: #28344f;
        border-radius: 0;
        color: ${get('datePicker.dayColor')};
    }

    .DayPicker-Day--today {
        color: ${get('datePicker.todayColor')};
    }
    .DayPicker-Body .DayPicker-Week .DayPicker-Day--selected {
        border-radius: 0;
        background-color: ${get('datePicker.hoverBg')};
    }
    .DayPicker-Body .DayPicker-Week .DayPicker-Day--selected:hover {
        background-color: ${get('datePicker.hoverBg')};
        opacity: 0.7;
    }
    .DayPicker-Day.DayPicker-Day--start.DayPicker-Day--selected {
        border-radius: 0.625rem 0 0 0.625rem;
    }
    .DayPicker-Day.DayPicker-Day--end.DayPicker-Day--selected {
        border-radius: 0 0.625rem 0.625rem 0;
    }
`
const Space = styled.span`
    padding: 0.5rem;
`
export default class Example extends React.Component {
    constructor(props) {
        super(props)
        this.handleFromChange = this.handleFromChange.bind(this)
        this.handleToChange = this.handleToChange.bind(this)

        this.state = {
            from: undefined,
            to: undefined
        }

        if (this.props.dateFrom && this.props.dateFrom.value) {
            const date = new Date()
            date.setTime(this.props.dateFrom.value)
            this.state.from = date
        }

        if (this.props.dateTo && this.props.dateTo.value) {
            const date = new Date()
            date.setTime(this.props.dateTo.value)
            this.state.to = date
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timeout)
    }

    focusTo() {
        // Focus to `to` field. A timeout is required here because the overlays
        // already set timeouts to work well with input fields
        this.timeout = setTimeout(() => this.to.getInput().focus(), 0)
    }

    showFromMonth() {
        const { from, to } = this.state
        if (!from) {
            return
        }
        if (new Date(to).getMonth() - new Date(from).getMonth() < 2) {
            this.to.getDayPicker().showMonth(from)
        }
    }

    handleFromChange(from) {
        // Change the from date and focus the 'to' input field
        const time = from.setHours(0, 0, 0, 0)
        this.setState({ from }, () => {
            if (!this.state.to) {
                this.focusTo()
            }
        })
        if (this.props.dateFrom) {
            this.props.dateFrom.onChange(time)
        }
    }

    handleToChange(to) {
        const time = to.setHours(23, 59, 59, 999)
        this.setState({ to }, this.showFromMonth)

        if (this.props.dateTo) {
            this.props.dateTo.onChange(time)
        }
    }

    render() {
        const { from, to } = this.state
        const modifiers = { start: from, end: to }

        return (
            <Inputs className="InputFromTo">
                <DayPickerInput
                    value={from}
                    placeholder="From"
                    format="LL"
                    dayPickerProps={{
                        selectedDays: [from, { from, to }],
                        disabledDays: { after: to },
                        locale: 'us',
                        toMonth: to,
                        modifiers,
                        numberOfMonths: 1
                    }}
                    onDayChange={this.handleFromChange}
                />
                <Space>~</Space>
                <span className="InputFromTo-to">
                    <DayPickerInput
                        ref={el => {
                            this.to = el
                        }}
                        value={to}
                        placeholder="To"
                        dayPickerProps={{
                            selectedDays: [from, { from, to }],
                            disabledDays: { before: from },
                            locale: 'en-US',
                            format: 'LL',
                            modifiers,
                            month: from,
                            fromMonth: from,
                            numberOfMonths: 1
                        }}
                        onDayChange={this.handleToChange}
                    />
                </span>
            </Inputs>
        )
    }
}
