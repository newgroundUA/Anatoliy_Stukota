import React from 'react'
import { Icon } from 'common'
import { Wrapper, Label, Select, Button } from './styled'

export default class index extends React.Component {
    state = {
        listVisible: false
    }

    getValue = () => {
        if (!this.props.field.value) {
            return null
        }

        const item = this.props.data.find(item => item.value === this.props.field.value)

        return item ? item.children : this.props.field.value
    }

    show = () => {
        this.setState({ listVisible: true })
        document.addEventListener('click', this.hide)
    }

    select = ({ value }) => {
        if (this.props.field) {
            this.props.field.onChange(value)
        } else if (this.props.onChange) {
            this.props.onChange(value)
        }
    }

    hide = () => {
        this.setState({ listVisible: false })
        document.removeEventListener('click', this.hide)
    }

    renderListItems = () =>
        this.props.data.map(
            (item, index) => (
                <Button
                    {...item}
                    onClick={() => this.select(item)}
                    type="button"
                    key={index}
                    active={item.value === this.props.field.value}
                />
            ) // todo move to class
        )

    render() {
        const { label, placeholder } = this.props
        return (
            <Wrapper>
                {label && <Label>{label}</Label>}
                <Select visible={this.state.listVisible}>
                    <Button onClick={this.show} type="button">
                        <span>{this.getValue() || placeholder}</span>
                        <Icon name="down" />
                    </Button>
                    <div className="list">{this.renderListItems()}</div>
                </Select>
            </Wrapper>
        )
    }
}
