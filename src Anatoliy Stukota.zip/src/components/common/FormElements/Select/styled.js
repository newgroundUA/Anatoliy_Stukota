import styled from 'styled-components'
import PropTypes from 'prop-types'
import is from 'styled-is'

const Select = styled.div`
    position: relative;
    cursor: pointer;
    color: #fff;
    [class^='icon-'] {
        position: absolute;
        top: 50%;
        right: 0.625rem;
        margin-top: -0.1875rem;
        font-size: 0.625rem;
        transition: all 0.3s ease;
        color: #6a7380;
    }
    & > button {
        background-color: #232d45;
    }
    button {
        border: none;
    }
    span {
        color: #fff;
        font-weight: 600;
    }
    .list {
        position: absolute;
        top: 2.25rem;
        left: 0;
        display: none;
        width: 100%;
        z-index: 10;
        button {
            &:hover {
                color: #fff;
                background-color: #28344f;
            }
        }
    }
    ${is('visible')`
        [class^='icon-'] {
            transition: all 0.35s ease-out;
            transform: rotate(180deg);
            color: #06B758;
            transform-origin: 50% 40%;
        }
        .list{
            background-color: #232D45;
            display: block;
        }
    `};
`
const Button = styled.button`
    padding: 0 0.9375rem;
    width: 100%;
    height: 2.25rem;
    background-color: transparent;
    color: #9ba0ac;
    font-size: 0.8125rem;
    text-align: left;
    font-weight: 600;
    cursor: pointer;
    ${is('active')`
        color: #02E866;
        font-weight: bold;
    `};
`

Select.propTypes = {
    visible: PropTypes.any
}
Button.propTypes = {
    active: PropTypes.any
}

export { Wrapper, Label, Message } from '../styled'

export { Select, Button }
