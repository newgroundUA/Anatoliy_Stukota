import styled from 'styled-components'

const Wrap = styled.label`
    display: flex;
    align-items: center;
    cursor: pointer;
    input {
        opacity: 0;
        width: 0;
        height: 0;
        position: absolute;
        z-index: -2;
        overflow: hidden;
    }
    input + span {
        display: block;
        width: 1.375rem;
        height: 0.5rem;
        content: '';
        background-color: #2f3e61;
        position: relative;
        border-radius: 0.25rem;
        margin-right: 0.5rem;
    }
    input + span:after {
        width: 0.75rem;
        height: 0.75rem;
        position: absolute;
        content: '';
        display: block;
        background-color: #6a7380;
        border-radius: 100%;
        top: -0.125rem;
        left: 0;
        transition: 0.3s;
    }
    input:checked + span:after {
        background-color: #00bd52;
        left: 50%;
        transition: 0.3s;
    }
`

const Label = styled.span`
    user-select: none;
    font-size: 0.75rem;
    color: #808f92;
`

export { Wrap, Label }
