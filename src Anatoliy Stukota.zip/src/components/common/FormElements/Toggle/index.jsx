import React from 'react'
import { Wrap, Label } from './styled'

export default ({ label, isChecked, onChange }) => (
    <Wrap>
        <input type="checkbox" onClick={() => onChange()} checked={isChecked} />
        <span />
        <Label>{label}</Label>
    </Wrap>
)
