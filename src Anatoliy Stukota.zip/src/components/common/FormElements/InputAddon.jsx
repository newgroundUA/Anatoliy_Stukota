import React from 'react'
import { InputAddon } from './styled'

export default ({ addon, innerRef, ...rest }) => (
    <InputAddon>
        <input {...rest} ref={innerRef} />
        <span>{addon}</span>
    </InputAddon>
)
