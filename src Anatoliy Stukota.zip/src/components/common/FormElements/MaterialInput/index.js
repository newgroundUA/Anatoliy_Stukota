export { StyledInput as default } from './styled'
