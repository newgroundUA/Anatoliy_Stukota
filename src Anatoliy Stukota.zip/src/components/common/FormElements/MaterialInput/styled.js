import styled from 'styled-components'
import Input from './Input'

const Label = styled.label`
    height: 0.875rem;
    color: ${({ error, theme }) => (error ? theme.materialInput.errorColor : theme.materialInput.labelColor)};
    font-size: 0.875rem;
    display: block;
    transform: translateY(24px);
    transition: all 0.3s;
    padding-bottom: 3px;
    ${({ active }) =>
        active &&
        `
        transform: translateY(0);
        transition: all 0.3s;
        font-size: 0.75rem;
    `};
`

const StyledInput = styled(Input)`
    position: relative;
    input {
        width: 100%;
        background: transparent;
        color: ${({ theme }) => theme.materialInput.textColor};
        border: none;
        border-bottom: 1px solid
            ${({ error, theme }) => (error ? theme.materialInput.errorColor : theme.materialInput.borderColor)};
        font-size: 0.875rem;
        transition: 0.3s;
        height: 2.5rem;
        line-height: 2.5rem;
        position: relative;
        &:focus {
            outline: none;
        }
        &::placeholder {
            opacity: 0;
            transition: 0.3s;
        }
        &:focus {
            &::placeholder {
                opacity: 1;
            }
        }
        ${({ error, theme }) =>
            !error &&
            `
            &:hover, &:focus {
                border-bottom: 1px solid ${theme.materialInput.borderColorActive};
            }
        `};
    }
    transition: 0.3s;
    margin-bottom: ${({ extra }) => (extra ? '3.25rem' : '1.875rem')};
`

const Error = styled.div`
    max-height: 0;
    overflow: hidden;
    transition: 0.3s;
    ${({ show }) =>
        show &&
        `
        max-height: 6rem;
        padding-top: 0.3125rem;
    `};
    bottom: -1.375rem;
    left: 0;
    ${({ extra }) => extra && 'position: absolute;'};
    color: ${({ theme }) => theme.materialInput.errorColor};
    font-size: 0.75rem;
`

const Extra = styled.div`
    position: absolute;
    right: 0;
    padding-top: 1.3rem;
    color: ${({ theme }) => theme.materialInput.textColor};
    font-size: 0.75rem;
`

export { StyledInput, Label, Error, Extra }
