import React from 'react'
import PropTypes from 'prop-types'
import Message from 'i18n/Message'
import { Label, Error, Extra } from './styled'

export default class Input extends React.Component {
    static propTypes = {
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.node, PropTypes.number]),
        innerRef: PropTypes.func,
        error: PropTypes.oneOfType([PropTypes.node, PropTypes.string]),
        className: PropTypes.string,
        placeholder: PropTypes.string
    }

    constructor(props) {
        super(props)
        this.state = {
            active: !!props.value
        }
    }

    handleFocus = e => {
        const { onFocus } = this.props
        if (onFocus) {
            onFocus(e)
        }
        if (!this.state.active) {
            this.setState({
                active: true
            })
        }
    }

    handleBlur = e => {
        const { onBlur } = this.props
        if (onBlur) {
            onBlur(e)
        }
        if (!this.input.value) {
            this.setState({
                active: false
            })
        }
    }

    render() {
        const { className, label, placeholder, innerRef, error, extra, ...rest } = this.props
        return (
            <div className={className}>
                <Label active={this.state.active} error={error}>
                    {label}
                </Label>
                <input
                    type="text"
                    {...rest}
                    placeholder={placeholder}
                    onFocus={this.handleFocus}
                    onBlur={this.handleBlur}
                    ref={node => {
                        this.input = node
                        if (innerRef) {
                            innerRef(node)
                        }
                    }}
                />
                {extra && <Extra>{extra}</Extra>}
                <Error extra={extra} show={!!error}>
                    {error && <Message id={error} />}
                </Error>
            </div>
        )
    }
}
