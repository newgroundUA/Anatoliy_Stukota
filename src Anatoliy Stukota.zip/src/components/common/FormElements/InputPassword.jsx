import React from 'react'
import { Icon } from 'common'
import { InputPassword, EyeOpen } from './styled'

export default class index extends React.Component {
    state = {
        type: 'password'
    }
    changeType = () => {
        const nextState = this.state.type === 'password' ? 'text' : 'password'
        this.setState({
            type: nextState
        })
    }

    render() {
        const { innerRef, ...rest } = this.props
        return (
            <InputPassword>
                <input {...rest} ref={innerRef} type={this.state.type} />
                {this.state.type === 'password' ? (
                    <Icon name="eye" onClick={this.changeType} />
                ) : (
                    <EyeOpen name="eye_open" onClick={this.changeType} />
                )}
            </InputPassword>
        )
    }
}
