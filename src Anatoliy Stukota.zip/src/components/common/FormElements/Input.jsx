import React from 'react'
import { observer } from 'mobx-react'
import Message from 'i18n/Message'
import InputPassword from './InputPassword'
import InputAddon from './InputAddon'
import { Wrapper, Label, ErrorMessage, Extra, ExtraTop } from './styled'

export default observer(
    ({
        field = {},
        type = 'text',
        disabled,
        leftIcon,
        stickyError,
        extra,
        extraTop,
        addon,
        label,
        primary,
        innerRef,
        noPadding,
        className,
        style,
        ...rest
    } = {}) => {
        const bindings = field.bind && field.bind()

        return (
            <Wrapper
                primary={primary}
                error={field.error && (field.touched || field.submitFailed)}
                leftIcon={leftIcon}
                disabled={disabled}
                noPadding={noPadding}
                className={className}
                style={style}
            >
                {extraTop && <ExtraTop>{extraTop}</ExtraTop>}
                {label && <Label>{label}</Label>}
                {(field.type || type) === 'password' ? (
                    <InputPassword disabled={disabled} {...bindings} {...rest} innerRef={innerRef} />
                ) : addon ? (
                    <InputAddon {...bindings} {...rest} addon={addon} innerRef={innerRef} disabled={disabled} />
                ) : (
                    <input {...bindings} {...rest} ref={innerRef} disabled={disabled} type={type} />
                )}
                {(field.submitFailed || field.touched) &&
                    field.error && (
                        <ErrorMessage stickyError={stickyError}>
                            {typeof field.error === 'object' ? (
                                <Message id={field.error.value} data={field.error.data} />
                            ) : (
                                <Message id={field.error} />
                            )}
                        </ErrorMessage>
                    )}
                {extra && <Extra>{extra}</Extra>}
            </Wrapper>
        )
    }
)
