import styled from 'styled-components'
import is, { isNot } from 'styled-is'

const Wrap = styled.div``

const SwitchGroup = styled.div`
    display: flex;
`

const SwitchItem = styled.a`
    width: 50%;
    text-align: center;
    font-size: 0.8125rem;
    font-weight: 600;
    display: block;
    user-select: none;
    cursor: pointer;
    box-sizing: border-box;
    ${is('active')`
        font-weight: 600;
        cursor: default;
    `} &:first-child {
        ${is('active')`
            background: red;
            color: #fff;
        `} ${isNot('active')`
            &:hover{
                color: red;
            }
        `};
    }
    &:last-child {
        ${is('active')`
            background: red;
            color: #fff;
        `} ${isNot('active')`
            &:hover{
                color: red;
            }
        `};
    }
`

export { Label } from '../styled'
export { Wrap, SwitchGroup, SwitchItem }
