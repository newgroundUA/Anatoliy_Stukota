import React from 'react'
import { observer } from 'mobx-react'
import { Wrap, Label, SwitchGroup, SwitchItem } from './styled'

export default observer(({ first, second, field: { value, onChange } }) => (
    <Wrap>
        <Label>Select an Operation</Label>
        <SwitchGroup>
            <SwitchItem onClick={() => onChange(first)} active={value === first}>
                {first}
            </SwitchItem>
            <SwitchItem onClick={() => onChange(second)} active={value === second}>
                {second}
            </SwitchItem>
        </SwitchGroup>
    </Wrap>
))
