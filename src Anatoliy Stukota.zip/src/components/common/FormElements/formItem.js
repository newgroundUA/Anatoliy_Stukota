import React from 'react'
import { observer } from 'mobx-react'

export default Component =>
    observer(({ field, ...rest }) => {
        const bindings = field ? field.bind() : null
        const error = field ? (field.touched || field.submitFailed) && field.error : null

        return <Component {...bindings} {...rest} error={error} />
    })
