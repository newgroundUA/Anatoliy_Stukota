import React from 'react'
import PropTypes from 'prop-types'

const Icon = ({ name, style, className = '', ...rest }) => (
    <span {...rest} style={style} className={`icon-${name} ${className}`} />
)

Icon.propTypes = { name: PropTypes.string.isRequired }

export default Icon
