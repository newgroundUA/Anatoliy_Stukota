import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import is from 'styled-is'
import { Flex as _Flex } from 'common'

const Col = styled.div`
    flex: 1;
    box-sizing: border-box;
    height: ${get('mainHeight')};
     ${is('rigthCol')`
        width: 17.0625rem;
        max-width: 17.0625rem;
        padding-top: 0.625rem;
    `}
       ${is('centerCol')`
        width: 17.875rem;
        max-width: 17.875rem;
        padding-top: 0.625rem;
        height: auto;
    `}
    ${is('graph')`
        display: flex;
        flex-direction: column;
        min-height: 28.3125rem;  
    `}
     
`

const Action = styled.span`
    cursor: pointer;
    padding: 0.1875rem;
`

const Flex = styled(_Flex)`
    height: 100%;
`

export { Col, Action, Flex }
