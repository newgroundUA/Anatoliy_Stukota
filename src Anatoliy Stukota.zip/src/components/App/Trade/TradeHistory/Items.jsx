import React from 'react'
import { ScrollableTable as Table, DateTime, FormattedNumber } from 'common'
import { observer } from 'mobx-react'
import { emitter } from '@utils'
import Message from 'i18n/Message'

const columns = [
    {
        title: <Message id="price" />,
        key: 'price',
        style: { width: '34%' },
        render: (item, index, entity) => {
            const { price, side, currencyPair } = entity.get(item)
            return (
                <span className={side}>
                    <FormattedNumber value={price} scale={currencyPair.priceScale} />
                </span>
            )
        }
    },
    {
        title: <Message id="amount" />,
        key: 'amount',
        style: { width: '34%' },
        render: (item, index, entity) => {
            const { amount, currencyPair } = entity.get(item)
            return <FormattedNumber value={amount} scale={currencyPair.amountScale} />
        }
    },
    {
        title: <Message id="time" />,
        key: 'time',
        style: { width: '32%' },
        render: (item, index, entity) => <DateTime timeOnly time={entity.get(item).time} />
    }
]

export default observer(({ tradeHistory }) => (
    <Table
        caption="Trade History"
        history
        data={tradeHistory.keys}
        entity={tradeHistory.items}
        loading={tradeHistory.isLoading}
        columns={columns}
        onRowClick={item => {
            emitter.emit('@trade/setPrice', tradeHistory.items.get(item).price)
        }}
    />
))
