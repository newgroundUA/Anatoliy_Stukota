import React from 'react'
import { inject } from 'mobx-react'
import Items from './Items'

@inject('tradeHistory')
export default class TradeHistory extends React.Component {
    componentDidMount = () => {
        this.props.tradeHistory.subscribe()
    }

    componentWillUnmount = () => {
        this.props.tradeHistory.unsubscribe()
    }

    render() {
        const { tradeHistory } = this.props

        return <Items tradeHistory={tradeHistory} />
    }
}
