import React from 'react'
import { Tabs, Tab } from 'common'
import OpenOrders from './OpenOrders'
import Balances from './Balances'
import MyTradeHistory from './MyTradeHistory'

export default class Funds extends React.Component {
    state = {
        active: 'openOrders'
    }

    handleChange = value => {
        this.setState({
            active: value
        })
    }

    render() {
        return (
            <Tabs active={this.state.active} headStyle={{ marginRight: '1.1875rem' }}>
                <Tab label="Open Orders" value="openOrders" onClick={this.handleChange}>
                    <OpenOrders />
                </Tab>
                <Tab label="My Trade History" value="tradeHistory" onClick={this.handleChange}>
                    <MyTradeHistory />
                </Tab>
                <Tab label="Balances" value="balances" onClick={this.handleChange}>
                    <Balances />
                </Tab>
            </Tabs>
        )
    }
}
