import React from 'react'
import { observer } from 'mobx-react'
import { ScrollableTable as Table, DateTime, FormattedNumber } from 'common'
import Message from 'i18n/Message'

const columns = [
    {
        title: <Message id="order" />,
        data: 'id',
        style: { width: '5%' }
    },
    {
        title: <Message id="pair" />,
        data: 'currencyPair',
        render: ({ baseCurrency, quoteCurrency }) => (
            <span>
                {baseCurrency.code}/{quoteCurrency.code}
            </span>
        )
    },
    {
        title: <Message id="type" />,
        key: 'type',
        render: ({ type, side }) => (
            <span className={side}>
                {type} {side}
            </span>
        )
    },
    {
        title: <Message id="amount" />,
        data: 'baseCurrencyAmount',
        style: { width: '12.6%' }
    },
    {
        title: <Message id="price" />,
        data: 'effectivePrice',
        style: { width: '9.6%' }
    },
    {
        title: <Message id="fee" />,
        key: 'fee',
        render: (data, item) => <FormattedNumber value={Math.abs(item.feeAmount)} />
    },
    {
        title: <Message id="amountMatched" />,
        data: 'baseCurrencyFulfilledAmount'
    },
    {
        title: <Message id="status" />,
        data: 'status'
    },
    {
        title: <Message id="time" />,
        data: 'updatedAt',
        style: { width: '16%' },
        render: value => <DateTime time={value} />
    }
]

export default observer(({ myTradeHistory }) => (
    <Table tradeBottom data={myTradeHistory.items} loading={myTradeHistory.isLoading} columns={columns} />
))
