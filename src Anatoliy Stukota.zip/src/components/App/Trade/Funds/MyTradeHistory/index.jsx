import React from 'react'
import { inject } from 'mobx-react'
import { emitter } from '@utils'
import { APP_CURRENCY_PAIR_CHANGED } from 'constants'
import Items from './Items'

@inject('app')
export default class MyTradeHistory extends React.Component {
    componentDidMount = () => {
        this.props.app.user.myTradeHistory.fetch({ pair: this.props.app.currencyPair.name })
        this.removeListener = emitter.on(APP_CURRENCY_PAIR_CHANGED, pair => {
            this.props.app.user.myTradeHistory.fetch({ pair })
        })
        this.props.app.user.myTradeHistory.subscribe()
    }

    componentWillUnmount = () => {
        this.props.app.user.myTradeHistory.unsubscribe(false)
        this.removeListener()
    }

    render() {
        const { myTradeHistory } = this.props.app.user
        return <Items myTradeHistory={myTradeHistory} />
    }
}
