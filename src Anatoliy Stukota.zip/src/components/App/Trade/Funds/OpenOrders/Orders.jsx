import React from 'react'
import { observer } from 'mobx-react'
import { ScrollableTable as Table, DateTime, Icon, FormattedNumber } from 'common'
import styled from 'styled-components'
import Message from 'i18n/Message'
import { Action } from '../../styled'

const Close = styled(Icon)`
    color: #808f92;
    cursor: pointer;
    transition: all 0.3s;
    &:hover {
        color: #fff;
        transition: all 0.3s;
    }
`

const columns = [
    {
        title: <Message id="order" />,
        key: 'order',
        data: 'id',
        style: { width: '7.5%' }
    },
    {
        title: <Message id="dateTime" />,
        key: 'dateTime',
        data: 'createdAt',
        style: { width: '18%', textAlign: 'left' },
        render: value => <DateTime time={value} />
    },
    {
        title: <Message id="pair" />,
        key: 'pair',
        data: 'currencyPair',
        style: { width: '9%', textAlign: 'left' },
        render: ({ baseCurrency, quoteCurrency }) => (
            <span>
                {baseCurrency.code}/{quoteCurrency.code}
            </span>
        )
    },
    {
        title: <Message id="type" />,
        key: 'type',
        data: 'side',
        style: { width: '4.5%', textAlign: 'left' },
        render: value => <span className={value}>{value}</span>
    },
    {
        title: <Message id="amount" />,
        key: 'amount',
        style: { width: '10.5%', textAlign: 'right' },
        render: (value, data) => (
            <React.Fragment>
                <FormattedNumber value={data.baseCurrencyAmount} scale={data.currencyPair.amountScale} />{' '}
                {data.currencyPair.baseCurrency.code}
            </React.Fragment>
        )
    },
    {
        title: <Message id="price" />,
        key: 'price',
        data: 'price',
        render: (value, { currencyPair }) => <FormattedNumber value={value} scale={currencyPair.priceScale} />,
        style: { width: '10.5%', textAlign: 'right' }
    },
    {
        title: <Message id="total" />,
        key: 'quoteCurrencyAmount',
        style: { width: '10.5%' },
        render: (value, item) => <FormattedNumber value={item.baseCurrencyAmount * item.price} />
    },
    {
        title: (
            <div className="flex between">
                <span>
                    <Message id="amountLeft" />
                </span>{' '}
                <span>
                    <Message id="status" />
                </span>
            </div>
        ),
        key: 'status',
        style: { width: '22%' },
        render: ({ side, baseCurrencyRemainingAmount, baseCurrencyAmount, baseCurrencyFulfilledAmount }) => {
            const remaining = Math.round((baseCurrencyFulfilledAmount * 100) / baseCurrencyAmount)
            return (
                <span className="amount">
                    <span>{baseCurrencyRemainingAmount}</span>
                    <span>{remaining} %</span>
                    <span className={`progress ${side}`}>
                        <span style={{ width: `${remaining}%` }} />
                    </span>
                </span>
            )
        }
    },
    {
        title: '',
        key: 'cancel',
        data: 'cancel',
        style: { width: '1rem' },
        render: cancel => (
            <Action>
                <Close name="close" onClick={cancel} />
            </Action>
        )
    }
]

export default observer(({ openOrders }) => (
    <Table tradeBottom openOrders data={openOrders.items} loading={openOrders.isLoading} columns={columns} />
))
