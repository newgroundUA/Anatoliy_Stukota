import React from 'react'
import { inject } from 'mobx-react'
import Items from './Items'

@inject('app')
export default class Balances extends React.Component {
    componentDidMount = () => {
        this.props.app.user.subscribe()
    }

    componentWillUnmount = () => {
        if (this.props.app.isAuthenticated) {
            this.props.app.user.unsubscribe()
        }
    }

    render() {
        return <Items app={this.props.app} />
    }
}
