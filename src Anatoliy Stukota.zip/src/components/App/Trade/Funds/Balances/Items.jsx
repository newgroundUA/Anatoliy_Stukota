import React from 'react'
import { observer } from 'mobx-react'
import { ScrollableTable as Table } from 'common'
import { round } from '@utils'

const columns = [
    {
        title: 'Coin',
        key: 'currency',
        style: { width: '9.6%' },
        render: item => item.currency.code
    },
    {
        title: 'Name',
        key: 'currencyName',
        style: { width: '9.6%' },
        render: item => item.currency.name
    },
    {
        title: 'In orders',
        key: 'ordersBalance',
        style: { width: '12.6%' },
        render: item => round(item.ordersBalance, 4)
    },
    {
        title: 'Available',
        key: 'balance',
        style: { width: '16%' },
        render: item => round(item.balance, 4)
    },
    {
        title: 'Total balance',
        key: 'totalBalance',
        style: { width: '16%' },
        render: item => round(item.balance + item.ordersBalance, 4)
    }
]

export default observer(({ app: { currencyPair: { quoteCurrency, baseCurrency } } }) => (
    <Table tradeBottom data={[quoteCurrency.account, baseCurrency.account]} columns={columns} />
))
