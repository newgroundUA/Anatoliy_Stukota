import styled from 'styled-components'
import PropTypes from 'prop-types'
import { Flex as _Flex } from 'common'

const Col = styled.div`
    overflow: hidden;
`

const Flex = _Flex.extend`
  flex-direction: column;
`

const Spread = _Flex.extend`
  height: 2.9375rem;
  display: flex;
  border-top: 1px solid #2F3847;
  border-bottom: 1px solid #2F3847;
  justify-content: space-between;
  align-items: center;
  padding: 0 1.25rem;
`
const Aggregation = styled.div`
    border-top: 1px solid #2f3847;
    height: 2.5rem;
    overflow: hidden;
    box-sizing: border-box;
    padding-left: 21px;
    padding-top: 9px;
    font-size: 12px;
    color: #808f92;
`

Col.propTypes = {
    sell: PropTypes.any,
    buy: PropTypes.any
}

export { TableWrap } from 'common/Table/ScrollableTable/styled'
export { Col, Flex, Spread, Aggregation }
