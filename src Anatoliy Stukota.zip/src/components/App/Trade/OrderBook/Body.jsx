import React from 'react'
import { inject, observer } from 'mobx-react'
import { TableWrap, Col } from './styled'
import Items from './Items'
import Spread from './Spread'
import MarketDepth from '../MarketDepth'

export default inject('app')(
    observer(
        ({ orderBook, app }) =>
            orderBook.type === 'orderBook' ? (
                <React.Fragment>
                    <Col>
                        <TableWrap sell clickable>
                            <table>
                                <thead>
                                    <tr>
                                        <th style={{ width: '33%' }}>Price ({app.currencyPair.quoteCurrency.code})</th>
                                        <th style={{ width: '33%' }}>Amount ({app.currencyPair.baseCurrency.code})</th>
                                        <th style={{ width: '33%' }}>Total ({app.currencyPair.quoteCurrency.code})</th>
                                    </tr>
                                </thead>
                            </table>
                            <div className="scrollbar">
                                <div>
                                    <table>
                                        <tbody>
                                            <Items data={orderBook} sell />
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </TableWrap>
                    </Col>
                    <Spread app={app} />
                    <Col>
                        <TableWrap buy clickable>
                            <div className="scrollbar">
                                <div>
                                    <table>
                                        <tbody>
                                            <Items data={orderBook} buy />
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </TableWrap>
                    </Col>
                </React.Fragment>
            ) : (
                <MarketDepth />
            )
    )
)
