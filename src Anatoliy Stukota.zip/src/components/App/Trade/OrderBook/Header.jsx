import React from 'react'
import { ColTitle, Toggle, Flex as _Flex } from 'common'
import { inject, observer } from 'mobx-react/index'

const Flex = _Flex.extend`
  padding: 0 1.25rem 0.5rem;
`

export default inject('orderBook')(
    observer(({ orderBook }) => (
        <Flex between center>
            <ColTitle>Order Book</ColTitle>
            <Toggle
                onChange={orderBook.handleToggleType}
                isChecked={orderBook.type === 'marketDepth'}
                label="Market Depth"
            />
        </Flex>
    ))
)
