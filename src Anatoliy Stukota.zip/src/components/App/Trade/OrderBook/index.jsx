import React from 'react'
import { inject } from 'mobx-react'
import { Flex, Aggregation } from './styled'
import Header from './Header'
import Body from './Body'

@inject('orderBook')
export default class OpenOrders extends React.Component {
    componentDidMount = () => {
        this.props.orderBook.subscribe()
    }

    componentWillUnmount = () => {
        this.props.orderBook.unsubscribe()
    }

    render() {
        const { orderBook } = this.props
        return (
            <Flex>
                <Header orderBook={orderBook} />
                <Body orderBook={orderBook} />
                <Aggregation>Future Aggregation</Aggregation>
            </Flex>
        )
    }
}
