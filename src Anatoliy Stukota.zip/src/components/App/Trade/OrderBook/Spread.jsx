import React from 'react'
import { observer } from 'mobx-react'
import { Spread } from './styled'

export default observer(({ app: { currencyPair } }) => (
    <Spread>
        <span>{currencyPair.close}</span>
        {/* <span>$3.22</span> */}
    </Spread>
))
