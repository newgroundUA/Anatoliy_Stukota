import React from 'react'
import { observer } from 'mobx-react'
import Row from './Row'

export default observer(({ data, sell }) => {
    const _items = sell ? data.sell : data.buy
    return _items.map(key => <Row key={key.toString()} item={data.items.get(key)} />)
})
