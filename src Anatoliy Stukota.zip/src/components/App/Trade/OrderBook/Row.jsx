import React from 'react'
import { observer } from 'mobx-react'
import { FormattedNumber } from 'common'

export default observer(({ item: { price, amount, handleRowClick, currencyPair } }) => (
    <tr onClick={handleRowClick}>
        <td style={{ width: '33%' }}>
            <FormattedNumber value={price} scale={currencyPair.priceScale} />
        </td>
        <td style={{ width: '33%' }}>
            <FormattedNumber value={amount} scale={currencyPair.amountScale} />
        </td>
        <td style={{ width: '33%' }}>
            <FormattedNumber value={price * amount} />
        </td>
    </tr>
))
