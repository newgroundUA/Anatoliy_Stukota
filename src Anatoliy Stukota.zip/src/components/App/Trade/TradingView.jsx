import React from 'react'
import { inject } from 'mobx-react'
import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import { emitter } from '@utils'
import { APP_CURRENCY_PAIR_CHANGED } from '../../../constants'
import theme from '../../../themes'

const TradingViewWrapper = styled.div`
    width: 100%;
    flex: 1;
    border: none;
    background-color: ${get('tradeView.bg')};
    iframe {
        height: 100% !important;
    }
`

@inject('app')
export default class TradingView extends React.Component {
    constructor(props) {
        super(props)
        this.widget = null
        this.scripts = [
            '//code.jquery.com/jquery-1.11.2.min.js',
            '/tv/charting_library/charting_library.min.js',
            '/tv/charting_library/datafeed/udf/datafeed.js'
        ]
        this.symbol = ''
    }

    componentDidMount = () => {
        this.unsubscribe = emitter.on(APP_CURRENCY_PAIR_CHANGED, this.handleCurrencyPairChanged)
        const { baseCurrency, quoteCurrency } = this.props.app.currencyPair
        this.symbol = baseCurrency.code + quoteCurrency.code
        if (!window.document.querySelector('#trading-view-0')) {
            let i = 0
            this.scripts.forEach((src, index) => {
                const script = document.createElement('script')
                script.src = src
                script.id = `trading-view-${index}`
                script.onload = () => {
                    if (++i === this.scripts.length) {
                        this.createWidget()
                    }
                }
                window.document.body.appendChild(script)
            })
        } else {
            this.createWidget()
        }
    }

    componentWillUnmount = () => {
        this.widget = null
        this.unsubscribe()
    }

    setSymbol = () => {
        if (this.ready) {
            this.widget.activeChart().setSymbol(this.symbol)
        }
    }

    // componentWillReact = () => {
    //     if (this.currencyPair !== this.props.app.currencyPair) {
    //         this.symbol = this.props.app.currencyPair.split('_').join('')
    //         this.setSymbol()
    //     }
    //     if (this.theme !== this.props.app.theme) {
    //         this.theme = this.props.app.theme
    //         this.createWidget()
    //     }
    // }

    timezone = () => {
        const timezones = {
            600: 'Pacific/Honolulu',
            420: 'America/Vancouver',
            360: 'America/El_Salvador',
            300: 'America/Chicago',
            240: 'America/Toronto',
            180: 'America/Argentina/Buenos_Aires',
            60: 'Europe/London',
            '-120': 'Europe/Madrid',
            '-180': 'Europe/Moscow',
            '-240': 'Asia/Dubai',
            '-258': 'Asia/Tehran',
            '-300': 'Asia/Ashkhabad',
            '-318': 'Asia/Kolkata',
            '-360': 'Asia/Almaty',
            '-420': 'Asia/Bangkok',
            '-480': 'Asia/Taipei',
            '-540': 'Asia/Tokyo',
            '-600': 'Australia/Brisbane',
            '-558': 'Australia/Adelaide',
            '-720': 'Pacific/Auckland',
            '-747': 'Pacific/Chatham',
            '-780': 'New_Zealand/Tokelau'
        }
        return timezones[new Date().getTimezoneOffset()]
    }

    createWidget = () => {
        this.widget = new window.TradingView.widget({
            fullscreen: true,
            symbol: this.symbol,
            // symbol: 'MSFT',
            // withdateranges: true,
            interval: '1',
            container_id: 'trading-view-container',
            // BEWARE: no trailing slash is expected in feed URL
            datafeed: new window.Datafeeds.UDFCompatibleDatafeed('/charts/tv'),
            // datafeed: new Datafeeds.UDFCompatibleDatafeed("https://demo_feed.tradingview.com"),
            library_path: '/tv/charting_library/',
            locale: 'en',
            drawings_access: { type: 'black', tools: [{ name: 'Regression Trend' }] },
            disabled_features: [
                'use_localstorage_for_settings',
                'left_toolbar',
                'header_symbol_search',
                'header_interval_dialog_button',
                'header_settings',
                'header_compare',
                'header_undo_redo',
                'header_saveload',
                'header_screenshot',
                'use_localstorage_for_settings'
            ],
            enabled_features: ['study_templates'],
            charts_storage_url: 'http://saveload.tradingview.com',
            charts_storage_api_version: '1.1',
            client_id: 'tradingview.com',
            left_toolbar: false,
            user_id: 'public_user_id',
            toolbar_bg: theme.tradeView.toolbarBg,
            timezone_menu: false,
            timezone: this.timezone(),
            loading_screen: {
                backgroundColor: theme.tradeView.bg
            },
            custom_css_url: '/static/tradingview-custom.css',
            overrides: {
                'paneProperties.background': theme.tradeView.bg,
                'paneProperties.vertGridProperties.color': theme.tradeView.gridColor,
                'paneProperties.vertGridProperties.style': 3,
                'paneProperties.horzGridProperties.color': theme.tradeView.gridColor,
                'paneProperties.horzGridProperties.style': 3,
                'symbolWatermarkProperties.transparency': 10,
                'scalesProperties.textColor': theme.tradeView.textColor,
                'mainSeriesProperties.showPriceLine': false,
                'mainSeriesProperties.candleStyle.upColor': theme.tradeView.green,
                'mainSeriesProperties.candleStyle.downColor': theme.tradeView.red,
                'mainSeriesProperties.candleStyle.drawWick': true,
                'mainSeriesProperties.candleStyle.drawBorder': true,
                'mainSeriesProperties.candleStyle.borderColor': theme.tradeView.greenMain,
                'mainSeriesProperties.candleStyle.borderUpColor': theme.tradeView.green,
                'mainSeriesProperties.candleStyle.borderDownColor': theme.tradeView.red,
                'mainSeriesProperties.candleStyle.wickUpColor': theme.tradeView.green,
                'mainSeriesProperties.candleStyle.wickDownColor': theme.tradeView.red
            },
            studies_overrides: {
                'volume.volume.color.0': theme.tradeView.volumeColor,
                'volume.volume.color.1': theme.tradeView.volumeColor,
                'volume.volume.transparency': 70
            },
            debug: false
        })

        this.widget.onChartReady(() => {
            this.ready = true
            this.setSymbol()
        })
    }

    handleCurrencyPairChanged = () => {
        const { baseCurrency, quoteCurrency } = this.props.app.currencyPair
        this.symbol = `${baseCurrency.code}${quoteCurrency.code}`
        this.setSymbol()
    }

    render() {
        this.theme = this.props.app.theme

        return <TradingViewWrapper id="trading-view-container" />
    }
}
