import styled from 'styled-components'

const Title = styled.h3`
    font-weight: 600;
    font-size: 1.125rem;
    color: #000;
    text-align: left;
    padding: 0 1.25rem 1.875rem 1.25rem;
`

const Charts = styled.div`
    height: calc(100vh - 9.125rem);
`

export { Title, Charts }
