import React from 'react'
import { inject } from 'mobx-react'
import MarketDepth from './MarketDepth'

@inject('marketDepth', 'app')
export default class index extends React.Component {
    componentDidMount = () => {
        this.props.marketDepth.subscribe()
    }

    componentWillUnmount = () => {
        this.props.marketDepth.unsubscribe()
    }

    render() {
        const { marketDepth, app } = this.props

        return <MarketDepth marketDepth={marketDepth} app={app} />
    }
}
