import React from 'react'
import { observer } from 'mobx-react'
import { withTheme } from 'styled-components'
import Chart from '../../../Chart'

export default withTheme(
    observer(({ marketDepth: { sell }, theme }) => (
        <Chart
            height="50%"
            width="100%"
            data={sell.toJSON()}
            fillColor="rgba(255, 74, 104, 0.2)"
            strokeColor={theme.red}
            margin={{
                top: 0,
                left: 0
            }}
        />
    ))
)
