import React from 'react'
import { observer } from 'mobx-react'
import { withTheme } from 'styled-components'
import Chart from '../../../Chart'

export default withTheme(
    observer(({ theme, marketDepth: { buy } }) => (
        <Chart
            strokeColor={theme.green}
            fillColor="rgba(2, 232, 102, 0.2)"
            data={buy.toJSON()}
            width="100%"
            height="50%"
            margin={{ left: 0, top: 0 }}
            reverse
        />
    ))
)
