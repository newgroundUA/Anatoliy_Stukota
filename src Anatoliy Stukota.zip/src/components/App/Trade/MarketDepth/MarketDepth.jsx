import React from 'react'
import Sell from './Sell'
import Buy from './Buy'
import { Charts } from './styled'

export default class MarketDepth extends React.Component {
    render() {
        const { marketDepth } = this.props
        return (
            <Charts>
                <Sell marketDepth={marketDepth} />
                <Buy marketDepth={marketDepth} />
            </Charts>
        )
    }
}
