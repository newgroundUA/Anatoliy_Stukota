import React from 'react'
import { inject, observer } from 'mobx-react'
import Collapsible from 'common/Collapsible'
import TradeHistory from './TradeHistory'
import OrderBook from './OrderBook'
import { Col, Flex } from './styled'
import Iframe from './TradingView'
import Funds from './Funds'

export default inject('app')(
    observer(({ app }) => (
        <Flex>
            <Col graph>
                <Iframe />
                {app.isAuthenticated && (
                    <Collapsible name="funds" toolbar="top" maxSize="15.3125rem">
                        <Funds />
                    </Collapsible>
                )}
            </Col>
            <Collapsible name="order-book" title="Order Book" toolbar="left" maxSize="18rem">
                <Col centerCol>
                    <OrderBook />
                </Col>
            </Collapsible>
            <Collapsible name="trade-history" title="Trade History" toolbar="left" maxSize="17rem">
                <Col rigthCol>
                    <TradeHistory />
                </Col>
            </Collapsible>
        </Flex>
    ))
)
