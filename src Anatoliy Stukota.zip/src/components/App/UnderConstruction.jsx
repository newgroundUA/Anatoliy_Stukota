import React from 'react'
import styled from 'styled-components'
import Maintenance from './Maintenance/Maintenance'

const Container = styled.div`
    padding-top: 15%;
    margin: 0 auto;
`

export default () => (
    <Container>
        <Maintenance underConstruction />
    </Container>
)
