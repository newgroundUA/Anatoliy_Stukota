import styled from 'styled-components'

const Title = styled.h1`
    font-size: 13.75rem;
    font-weight: 500;
    line-height: 1em;
    padding-bottom: 3rem;
    text-align: center;
    background: linear-gradient(45deg, #02d962 48%, #065b40 50%, #065b40 53%, #02d962 55%);
    background-size: 200% auto;
    color: #000;
    background-clip: text;
    text-fill-color: transparent;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: shine 3s linear infinite;
    animation-direction: reverse;
    @keyframes shine {
        0% {
            background-position: 0% center;
        }
        100% {
            background-position: 200% center;
        }
    }
`
const Text = styled.p`
    font-size: 2.5rem;
    color: #065b40;
`
const Desc = styled.p`
    font-weight: 600;
    font-size: 1.125rem;
    color: #808f92;
    padding-bottom: 3rem;
`

export { Title, Text, Desc }
