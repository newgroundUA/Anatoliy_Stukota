import React from 'react'
import { Helmet } from 'react-helmet'
import { Warning, withSupport } from 'common'
import { renderRoutes } from 'react-router-config'
import Notifications from './Notifications'
import LoadingBar from './LoadingBar'

export default withSupport()(({ route }) => (
    <React.Fragment>
        <Helmet>
            <title>CoinSupply</title>
        </Helmet>
        <LoadingBar />

        <Warning />

        <Notifications />
        {renderRoutes(route.routes)}
    </React.Fragment>
))
