import React from 'react'
import { Content } from 'common/SecondaryLayout'
import { Link } from 'react-router-dom'
import { Button } from 'common'
import Message from 'i18n/Message'
import { Title, Text, Desc } from '../NotFound/styled'

export default () => (
    <Content center>
        <Title>Error</Title>
        <Text>
            <Message id="OhNoSomethingWentWrong" />
        </Text>
        <Desc>
            <Message id="thereIsAnErrorOccurred" />
        </Desc>
        <Link to="/">
            <Button single>
                <Message id="homePage" />
            </Button>
        </Link>
    </Content>
)
