import { Content as _Content } from 'common/SecondaryLayout'

const Content = _Content.extend`
    padding: ${({ padding }) => padding || '2rem 0'};
    margin: 0 auto;
    text-align: justify;
    h1,h2,h3,h4,h5,h6{
        text-align: center;
        margin-bottom: 1rem;
    }
    p, ol{
        margin-bottom: 1rem;
    }
    li ul, ol {
        padding-left: 2rem;
    }
    img{
        width: 70%;
        display: block;
        margin: 0 auto;
    }
`

export { Content }
