import React from 'react'
import { Content } from './styled'

export default () => (
    <Content width="60vw">
        <h1>Anti-Spam Policy</h1>
        <p>
            Anti-spam legislation and appropriate industry practices require a user’s request to receive promotional
            content in their email, as well as an unsubscribe button that removes you from the email database and the
            sender has to identify themselves. We comply with these regulations and put tremendous importance on user
            choice.
        </p>
        <p>
            CoinSupply needs your permission in order to send you emails and establish, as well as, maintain a
            responsible commercial relationship with you; to keep you updated on developments to the site, provide
            products and services to you, to take your feedback in consideration in the future of CoinSupply
            development, and to meet CoinSupply’s legal and regulatory requirements.
        </p>
    </Content>
)
