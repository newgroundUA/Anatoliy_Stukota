import React from 'react'
import coinsupplyTrademark from 'assets/images/coinsupply-trademark.jpg'
import { Content } from './styled'

export default () => (
    <Content>
        <h1>Trademark Notices of CoinSupply AG.</h1>
        <img src={coinsupplyTrademark} alt="coinsupply" />
    </Content>
)
