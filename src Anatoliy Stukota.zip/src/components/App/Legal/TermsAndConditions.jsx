import React from 'react'
import { Link } from 'react-router-dom'
import { Content } from './styled'

export default () => (
    <Content width="60vw">
        <h1>Terms and Conditions</h1>
        <p>
            CoinSupply.com. (further referred to as the <strong>‘‘Site‘‘</strong>). These terms and conditions of
            service (referred to as <strong>‘‘Terms of Service‘‘</strong>) apply to all users of the Site. You should
            read these Terms of Service carefully and determine if they apply to you. By using any of the features,
            services, or functions existing on the Site (together or separately referred as, the{' '}
            <strong>‘‘Services‘‘</strong>), the customer (further referred to as <strong>‘‘you‘‘</strong> or{' '}
            <strong>‘‘your‘‘</strong>) must agree to these Terms of Service.
        </p>
        <h2>Definitions</h2>
        <h3>
            <strong>‘‘Associates‘‘</strong> means CoinSupply and all of its respective directors, subsidiaries,
            employees, contractors, shareholders, agents, officers, attorneys, affiliates, insurers, and partners
        </h3>
        <ul>
            <li>
                <strong>‘‘CoinSupply‘‘</strong> means Coin Supply AG.
            </li>
            <li>
                <strong>‘‘Person‘‘</strong> includes an individual, trust, association, corporation, other body
                corporate, partnership, and any other form of legal organization or entity.
            </li>
            <li>
                <strong>‘‘Prohibited Use‘‘</strong> means what is set out in paragraph 18 of these Terms of Service.
            </li>
            <li>
                <strong>‘‘Service‘‘</strong> means any of the features, services, functions offered on the Site.
            </li>
            <li>
                <strong>‘‘Site‘‘</strong> means the Internet websitecom.
            </li>
            <li>
                <strong>‘‘Terms of Service‘‘</strong> means these terms and conditions of service, and they might be
                amended, changed or updated at any time.
            </li>
            <li>
                <strong>‘‘your‘‘</strong> or <strong>‘‘you‘‘</strong> means the customer.
            </li>
            <li>
                The headings and subheadings in these Terms of Service are for easier reference only and are not to be
                considered in the construction or interpretation of any provision or provisions to which they refer.
            </li>
            <li>
                Unless otherwise specified in these Terms of Service, words meaning the singular include the plural and
                vice versa and words meaning gender include all genders.
            </li>
            <br />
            <li>
                <strong>Scope of Terms of Service</strong>
                <ul>
                    <li>
                        These Terms of Service acts as an agreement and constitutes to the use of any or all of the
                        Services, and any manner of accessing them, between: you and Coin Supply AG. (referred to herein
                        as <strong>‘‘CoinSupply‘‘</strong>).
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Usage and changes of Terms and Conditions</strong>
                <ul>
                    <li>
                        Any and all terms, limitations, conditions, licenses, and obligations contained in and on the
                        Site are incorporated into these Terms of Service by reference, including, without limiting the
                        generality of the foregoing, the following Site policies and pages:{' '}
                        <Link to="/legal/privacy-policy">the Privacy Policy</Link>,{' '}
                        <Link to="/legal/risk-disclosure-statement">the Risk Disclosure Statement</Link>, and any other
                        documents that might be announced in the Site. In particular, please take note that all of the
                        transactions of Digital Currencies and other Digital Goods on or off the Site may be subject to
                        fees levied by CoinSupply from time to time. In the event of any inconsistency between these
                        Terms of Service and any other pages or policies on the Site, these Terms of Service shall be
                        considered correct.
                    </li>
                    <li>
                        By creating an account on the Site or by using any of the Services or any associated websites,
                        APIs, or mobile applications, you acknowledge that you have read, understood, and completely
                        agreed to these Terms of Service in effect. If you disagree with these Terms of Service or with
                        any subsequent amendments, changes, or updates, you may not use any of the Services; your only
                        recourse in the case of disagreement is to stop using all of the Services.
                    </li>
                    <li>
                        Some of the Services may not work properly from time to time. CoinSupply may not be held
                        responsible regarding any damages you may have because of any failures of the Site or Services.
                    </li>
                    <li>
                        These Terms of Service may be amended, changed, or updated by CoinSupply at any time and without
                        prior notice to you. You should check back regularly and confirm that your copy and
                        understanding of these Terms of Service is current and correct. Your non-termination or
                        continued use of any Services after the effective date of any amendments, changes, or updates
                        constitutes your acceptance of these Terms of Service, as modified by such amendments, changes,
                        or updates.
                    </li>
                    <li>
                        The use of the Site and any Services is void where prohibited by applicable law whether local or
                        international.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>General use</strong>
                <ul>
                    <li>
                        <strong>Basic Services</strong> - Coinsupply’s currency trading platform will allow CoinSupply’s
                        clients to safely buy and sell digital assets such as Digital Currencies and Digital Tokens. You
                        will be able to deposit and withdraw funds to and from your account using CryptoCurrencies. The
                        risk of loss in trading or holding Digital Currency can be substantial. You should therefore
                        carefully consider whether trading or holding Digital Currency is suitable for you considering
                        your financial condition.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Creating your Account</strong>
                <ul>
                    <li>
                        In order to use any of the Services, you must first register by doing the following actions:
                        <ul>
                            <li>
                                Click on the REGISTER icon and enter your email address as well as password then click
                                CREATE MY ACCOUNT icon.
                            </li>
                            <li>
                                You will receive a confirmation email stating device information every time you log in.
                            </li>
                        </ul>
                    </li>
                    <li>
                        CoinSupply may, in its sole discretion, refuse to allow you to establish an account, or limit
                        the number of accounts that a single user may establish and maintain at any time.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Depositing your funds</strong>
                <ul>
                    <li>
                        After you create your personal account, you will need to fund it by doing the following steps:
                        <ul>
                            <li>Click “Balances, Withdrawals & Deposits” on your main account menu.</li>
                            <li>
                                After you have deposited your funds into your CoinSupply account, you will be able to
                                begin trading in Crypto Currencies.
                            </li>
                        </ul>
                    </li>
                    <li>
                        Services are available only in connection with those Digital Currencies that CoinSupply, in its
                        sole discretion, decides to support. The Digital Currencies that CoinSupply supports may change
                        from time to time. CoinSupply may delist a Digital Currency at any time in its sole discretion
                        based on a number of factors, one of which may include changes in a given Digital Currencie’s
                        characteristics after CoinSupply has listed the Digital Currency. Under no circumstances should
                        you attempt to use Services to store, send, request, or receive Digital Currencies in any form
                        that are not supported by CoinSupply. CoinSupply assumes no responsibility or liability in
                        connection with any attempt to use Services for Digital Currencies that CoinSupply does not
                        support.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Trading activities</strong>
                <ul>
                    <li>
                        Select the Digital Currency you want to trade in. You can choose it on the left-hand sidebar.
                    </li>
                    <li>Place your offer to buy Digital Currency in the “Buy/Sell” section.</li>
                    <li>As soon as your order is matched against another order, your order will be fulfilled.</li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Withdrawals</strong>
                <ul>
                    <li>Click “Balances, Withdrawals & Deposits” on your main account menu.</li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Limited license to Use the Site</strong>
                <ul>
                    <li>
                        If you agree and follow these Terms of Service, CoinSupply grants you the limited right to use
                        the Site and the Services. The right to use the Site and the Services is a personal, restricted,
                        non-exclusive, non-transferable, revocable, limited license, and it is subject to the
                        limitations and obligations in these Terms of Service. Nothing in these Terms of Service gives
                        you any license (other than as set out in this paragraph), right, title, or ownership of, in, or
                        to the Site or any of the Services. You agree you will not copy, transmit, distribute, sell,
                        license, reverse engineer, modify, publish, or participate in the transfer or sale of, create
                        derivative works from, or in any other way exploit any of the content, in whole or in part.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>The Site and Services accuracy</strong>
                <ul>
                    <li>
                        Although CoinSupply intends to provide accurate and timely information on the Site and while
                        providing Services, the Site (including, without limitation, Services) may not always be
                        entirely accurate, complete or up to date and may also include technical inaccuracies or
                        typographical errors and inconsistencies. In order to keep to providing you with as complete and
                        accurate information as possible, information may be changed or updated from time to time
                        without notice, including without limitation information regarding CoinSupply‘s policies,
                        products and services. Accordingly, you should verify all information before relying on it, and
                        all decisions based on information contained on the Site are your sole responsibility and
                        CoinSupply shall take no liability for such decisions. Links to third-party materials (including
                        without limitation to websites) may be provided as a convenience but are not controlled by
                        CoinSupply. You acknowledge and agree that CoinSupply is not responsible for any part of the
                        information, content, or services contained in any third-party materials or on any third-party
                        sites accessible or linked to the Site.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Risks and Limitation of Liability</strong>
                <ul>
                    <li>
                        Trading and Digital Currencies markets are volatile and shift quickly in terms of liquidity,
                        market depth, and trading dynamics. You are solely responsible and liable:
                        <ul>
                            <li>
                                for any and all trading and non-trading activity on the Site and for your account on the
                                Site;
                            </li>
                            <li>
                                for knowing the true status of any position with any other party on the Site, even if
                                presented incorrectly by the Site at any time;
                            </li>
                        </ul>
                    </li>
                    <li>
                        You understand and agree:
                        <ul>
                            <li>
                                to be fully responsible and liable for your trading and non-trading actions and
                                inactions on the Site and all gains and losses sustained from your use of the Site and
                                any of the Services;
                            </li>
                            <li>to be responsible for any negative balance in your account(s) on the Site;</li>
                            <li>
                                to be fully responsible for safeguarding access to, and any information provided
                                through, the Site and any of the Services, including, but not limited to, private keys,
                                usernames, passwords. Any loss or compromise of the information and/or your personal
                                information may result in unauthorized access to your CoinSupply account by
                                third-parties and the loss or theft of any Digital Currency and/or funds held in your
                                CoinSupply account. You are accountable for keeping your email address and telephone
                                number current in your account profile in order to receive any announcements or alerts
                                that CoinSupply may send you. CoinSupply assumes no accountability for any loss that you
                                might bear due to compromise of account login credentials and/or failure to follow or
                                act on any announcements or alerts that CoinSupply may send to you. In the event you
                                believe your CoinSupply account information has been compromised, contact CoinSupply‘s
                                Support immediately at{' '}
                                <a href="mailto:support@coinsupply.com" target="_top">
                                    support@coinsupply.com;
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        There is no assurance against losses on the Site. CoinSupply cannot assure the stop of losses
                        even with the ability to force-liquidate any of your positions (due to, for instance, market
                        volatility and liquidity). CoinSupply will not be and is not accountable for any other party on
                        the Site.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Agency</strong>
                <ul>
                    <li>
                        CoinSupply does not act as principal, counterparty, or market-maker in the transactions effected
                        through trading on CoinSupply. However, you hereby grant CoinSupply agency, and you allow and
                        instruct CoinSupply: to implement, charge, monitor, and maintain a right to keep possession on
                        all Digital Currencies in your name or control on the Site; and, to liquidate any Digital
                        Currencies in your name or control on the Site if essential to ensure that any Services you have
                        obtained on the Site are paid for in full.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Abandoned Property</strong>
                <ul>
                    <li>
                        Where you have not logged into your account on the Site for an continuous period of two years,
                        CoinSupply afterward reserves the right to deem any and all Digital Currencies that you hold on
                        the Site, to be abandoned, with or without any notice to you. If your possessions are abandoned,
                        it will be dealt with in one of two ways. First, if you are an unverified customer, it will be
                        immediately forfeited to and held by CoinSupply. Second, if you are a verified customer, we will
                        engage in a procedure to determine the abandoned possessions’ owner (including
                        successors-in-interest and next-of-kin). This process will be subject to servicing and
                        administration fees to be imposed on and collected out of the property by CoinSupply. Any
                        amounts greater than our servicing and administration fees will be paid to the possessions’
                        owner, when and if found.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>No Class Proceedings</strong>
                <ul>
                    <li>
                        You and CoinSupply agree that any party hereto may bring claims against the others only on an
                        individual basis and not as an accuser or class member in any purported class or representative
                        action or proceeding. No adjudicator may consolidate or join more than one person’s or party’s
                        claims and may not otherwise preside over any form of a consolidated, representative, or class
                        proceeding. Any relief awarded to any one CoinSupply user cannot and may not affect any other
                        CoinSupply users.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Prohibited Uses</strong>
                <div>You cannot:</div>
                <ul>
                    <li>
                        use the Site or any Services to disguise the profits of, or to further, any breach of pertinent
                        laws or regulations, or to deal in any contraband Digital, funds, or proceeds;
                    </li>
                    <li>
                        trade or use any Services, with anything other than funds, keys, or Digital currency that has
                        been legally obtained by you and that belong to you;
                    </li>
                    <li>
                        use the Site or any Services to interfere with or subvert the rights or obligations of
                        CoinSupply or the rights or obligations of any other Site customer or any other third party;
                    </li>
                    <li>
                        trade using imprecise information presented by the Site or by CoinSupply or take advantage of
                        any technical glitch, malfunction, failure, delay, default, or security breach;
                    </li>
                    <li>
                        use the Site or any Services to engage in behavior that is harmful to CoinSupply or to any other
                        Site customer or any other third party;
                    </li>
                    <li>provide incorrect account registration details to CoinSupply;</li>
                    <li>
                        falsify or omit any information or provide deceptive, ambiguous or misleading information
                        requested by CoinSupply, including at registration;
                    </li>
                    <li>reverse-engineer, decompile, or disassemble any software running on the Site;</li>
                    <li>
                        attempt to harm CoinSupply or any third party through your access to the Site or any Services,
                        except that nothing in this subparagraph shall be construed as limiting your free speech rights
                        under applicable law;
                    </li>
                    <li>
                        where you are a resident or national of a Prohibited Jurisdiction access the Site or any
                        Services using any virtual private network, proxy service, or any other third party service,
                        network, or product with the effect of disguising your IP address or location;
                    </li>
                    <li>
                        distribute unsolicited or unauthorized advertising or promotional material, any junk mail, spam,
                        or chain letters;
                    </li>
                    <li>
                        use a web crawler or similar technique to access CoinSupply‘s Services or to extract
                        information;
                    </li>
                    <li>
                        take any action that imposes an unreasonable or disproportionately large load on CoinSupply‘s
                        infrastructure, or adversely interfere with, intercept, or expropriate any system, data, or
                        information;
                    </li>
                    <li>
                        transmit or upload any material to the Site that contains viruses, Trojan horses, worms, or any
                        other harmful programs;
                    </li>
                    <li>
                        otherwise attempt to gain unauthorized access to the Site, other CoinSupply‘s Accounts, computer
                        systems or networks connected to the Site, through password mining or any other resources;
                    </li>
                    <li>transfer any rights granted to you under these Terms;</li>
                    <li>violate these Terms of Service;</li>
                    <li>
                        any use as described in this paragraph shall constitute as ‘‘Prohibited Use‘‘.If CoinSupply
                        determines that you have engaged in any Prohibited Use, CoinSupply may address such Prohibited
                        Use through an appropriate sanction, in its sole and absolute discretion. Such sanction may
                        include, but is not limited to, making a report to law enforcement or other authorities;
                        confiscation of any Digital Currencies that you have on the Site; and, terminating your access
                        to any Services. CoinSupply might, at its sole and absolute discretion, seize and hand over your
                        property to law enforcement or other authorities where circumstances warrant.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Intellectual Property</strong>
                <ul>
                    <li>
                        CoinSupply and the CoinSupply logos, the URLs representing the Site, trade names, word marks,
                        and design marks (the ‘‘CoinSupply Marks‘‘) are trademarks of Coin Supply AG. In addition, all
                        page headings, custom graphics, designs, button icons, scripts, source code, content are
                        copyrighted by CoinSupply. You agree not to appropriate, copy, display, or use the CoinSupply
                        Marks or other content without express, prior, written consent to do so. Unless otherwise
                        indicated, all materials on CoinSupply are © CoinSupply.
                    </li>
                    <li>
                        You acknowledge and agree that any materials, including but not limited to questions, comments,
                        feedback, suggestions, ideas, plans, notes, drawings, original or creative materials or other
                        information or commentary you provide on Site or one of CoinSupply‘s social media accounts,
                        concerning CoinSupply or the Services (collectively, ‘‘Feedback‘‘) that are provided by you,
                        whether by email, posting to the Site or otherwise, are non-confidential and will become the
                        sole property of CoinSupply. CoinSupply will own exclusive rights, including all intellectual
                        property rights, and will be entitled to the unrestricted use and distribution of such Feedback
                        for any purpose, commercial or otherwise, without acknowledgment or compensation to you.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Your Representations & Warranties</strong>
                <ul>
                    <li>
                        You represent and warrant to CoinSupply as follows:
                        <ul>
                            <li>
                                that, if you are an individual customer, you are 18 years of age or older and that you
                                have the capacity to contract under applicable local and international law;
                            </li>
                            <li>
                                that, if you are not an individual customer, you have the necessary power and authority
                                to sign and enter into binding agreements for and on behalf of the customer;
                            </li>
                            <li>
                                that you understand the risks associated with using the Site and Services and you are
                                not otherwise prohibited by law from using the Site and Services;
                            </li>
                            <li>
                                that you will not use the Site or any Services to mask the proceeds of, or to further,
                                any breach of appropriate laws or regulations, or to deal in any contraband Digital
                                Currencies or proceeds;
                            </li>
                            <li>
                                that you will not trade on the Site or use any Services with anything other than Digital
                                Currencies that have been legally obtained by you and that belong to you;
                            </li>
                            <li>that you will not falsify any account registration details provided to CoinSupply;</li>
                            <li>
                                that you will not falsify or materially omit any information or provide misleading
                                information requested by CoinSupply during, directly or indirectly relating to, or
                                arising from your activities on the Site or use of any Services, including at
                                registration;
                            </li>
                            <li>
                                that any trading or other instructions received or undertaken through your login
                                credentials or from your authorized e-mail address on file with CoinSupply are believed
                                to be valid, binding, and conclusive, and that CoinSupply might act upon those
                                instructions without any liability or accountability attaching to it;
                            </li>
                            <li>
                                that you will fairly and promptly report all income associated with your activity on the
                                Site pursuant to applicable law and pay any and all taxes eligible thereon;
                            </li>
                            <li>
                                that you understand that Digital Currencies are often described in exceedingly technical
                                language that requires a complete understanding of applied cryptography and computer
                                science in order to appreciate inherent risks. Listing of a Digital Currency on
                                CoinSupply’s Site does not indicate approval or disapproval of the underlying technology
                                regarding any Digital Currency and should not be used as a substitute for your own
                                understanding of the risks specific to each Digital Currency. CoinSupply gives you no
                                warranty as to the suitability of the Digital Currencies traded under these Terms of
                                Service and assumes no fiduciary duty in CoinSupply‘s relations with you;
                            </li>
                            <li>
                                you agree that CoinSupply is not responsible for determining whether or which laws may
                                apply to your transactions, including tax law. You are solely responsible for reporting
                                and paying any taxes arising from your use of the Services.
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>No Representations & Warranties by CoinSupply</strong>
                <ul>
                    <li>
                        CoinSupply makes no representations, warranties, or guarantees to you of any kind. The Site and
                        the Services are offered strictly on an as-is, where-is basis and, without limiting the
                        generality of the foregoing, are offered without any representation as to merchantability or
                        fitness for any particular purpose. CoinSupply does not represent or warrant that the Services
                        and information contained therein are accurate, complete, reliable, current or error-free.
                        CoinSupply will make reasonable efforts to ensure that transactions on the platform are
                        processed in timely fashion but makes no representations or warranties with respect to the
                        amount of time needed to process such transactions. Because Digital Currencies transfers on and
                        off the platform are dependent upon many factors outside of CoinSupply’s control including
                        denial or service attacks and the liquidity of the Digital Currencies traded on our platform,
                        among other factors, CoinSupply makes no representations or warranties regarding the success of,
                        or the amount of time needed for, Digital Currencies transactions. You also acknowledge that any
                        information that you store or transfer using the Services may become irretrievably lost or
                        corrupted or temporarily unavailable due to a variety of causes, including software failures,
                        third party protocol changes, internet outages, third party denial or Service attacks, acts of
                        God or unscheduled maintenance. You are encouraged to back up and safeguard your information,
                        including login credentials, at all times.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>No Advice</strong>
                <ul>
                    <li>
                        CoinSupply does not provide any investment advice or merits of any transaction or their tax
                        consequences, trading methods, models, algorithms, or any other arrangements. Any information
                        provided on the Site or received when you are using any of the Services is only for
                        informational purposes and you are solely responsible for any decision you make based on that
                        information.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Limitation of Liability & Release</strong>
                <ul>
                    <li>
                        Important: CoinSupply assumes no liability or accountability for and shall have no liability or
                        accountability for any claim, application, loss, injury, delay, accident, cost, business
                        interruption costs, or any other expenses (including, without limitation, attorneys’ fees or the
                        costs of any claim or suit), nor for any secondary, direct, indirect, general, special,
                        punitive, exemplary, or consequential damages, loss of goodwill or business profits, work
                        stoppage, data loss, computer failure or malfunction, or any and all other commercial losses
                        (collectively, referred to herein as “Losses”) directly or indirectly arising out of or related
                        to:
                        <ul>
                            <li>these Terms of Service;</li>
                            <li>the Site, and your usage of it;</li>
                            <li>the Services, and your usage of any of them;</li>
                            <li>
                                the real or perceived value of Digital Currencies traded on the Site, or the price of
                                any Digital Currency displayed on the Site at any time;
                            </li>
                            <li>
                                any imprecise, misleading, or incomplete statement by CoinSupply or on the Site
                                regarding your account, whether caused by CoinSupply’s negligence or otherwise;
                            </li>
                            <li>
                                any failure, delay, malfunction, disruption, or decision (including any decision by
                                CoinSupply to vary or interfere with your rights) by CoinSupply in operating the Site or
                                providing any Service;
                            </li>
                            <li>
                                any stolen, lost, or unauthorized use of your account information any breach of security
                                or data breach related to your account information, or any criminal or other third-party
                                act affecting CoinSupply or any Associate;
                            </li>
                            <li>
                                any offer, representation, suggestion, statement, or claim made about CoinSupply, the
                                Site, or any Service by any Associate.
                            </li>
                        </ul>
                    </li>
                    <li>
                        You hereby agree to release the Associates from liability for any and all Losses, and you shall
                        indemnify and save and hold the Associates harmless from and against all Losses. The foregoing
                        limitations of liability shall apply whether the alleged liability or Losses are based on
                        contract, negligence, tort, unjust enrichment, strict liability, or any other basis, even if the
                        Associates have been advised of or should have known of the possibility of such losses and
                        damages, and without regard to the success or effectiveness of any other remedies.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>No Waiver</strong>
                <ul>
                    <li>
                        Any failure by CoinSupply to exercise any of its respective rights, powers, or remedies under
                        these Terms of Service, or any delay by CoinSupply in doing so, does not constitute a waiver of
                        any such right, power, or remedy. The single or partial exercise of any right, power, or remedy
                        by CoinSupply does not prevent either from exercising any other rights, powers, or remedies.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Force Majeure</strong>
                <ul>
                    <li>
                        In addition to applicable disclaimers stated above, CoinSupply is not responsible for damages
                        caused by delay or failure to perform undertakings under these Terms of Service when the delay
                        or failure is due to fires; strikes; floods; power outages or failures; acts of God or the
                        state’s enemies; lawful acts of public authorities; any and all market movements, shifts, or
                        volatility; computer, server, or Internet malfunctions; security breaches or cyber attacks;
                        criminal acts; delays or defaults caused by common carriers; acts or omissions of third parties;
                        or, any other delays, defaults, failures or interruptions that cannot reasonably be foreseen or
                        provided against. In the event of force majeure, CoinSupply is excused from any and all
                        performance obligations and these Terms of Service.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Assignment</strong>
                <ul>
                    <li>
                        These Terms of Service, and any of the rights, duties, and obligations contained herein, are not
                        transferrable by you without prior written consent of CoinSupply. These Terms of Service, and
                        any of the rights, duties, and obligations contained herein, are freely assignable by CoinSupply
                        without notice or your consent. Any attempt by you to assign these Terms of Service without
                        written consent is void.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Severability</strong>
                <ul>
                    <li>
                        If any provision of these Terms of Service, as edited from time to time, is determined to be
                        invalid, void, or unenforceable, in whole or in part, by any court of competent jurisdiction,
                        such invalidity, validness, or unenforceability attaches only to such provision and everything
                        else in these Terms of Service continues in full force and effect.
                    </li>
                </ul>
            </li>
            <br />
            <li>
                <strong>Survival</strong>
                <ul>
                    <li>
                        All provisions of these Terms of Service which by their nature extend beyond the expiration or
                        termination of these Terms of Service, including, without limitation, sections relating to
                        suspension or termination, CoinSupply‘s account cancellation, debts owed to CoinSupply, general
                        use of the Site, disputes with CoinSupply, and general provisions, shall survive the termination
                        or expiration of these Terms of Service.
                    </li>
                </ul>
            </li>
        </ul>
    </Content>
)
