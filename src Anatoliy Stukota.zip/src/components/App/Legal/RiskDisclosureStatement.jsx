import React from 'react'
import { Content } from './styled'

export default () => (
    <Content width="60vw">
        <h1>Risk Disclosure Statement</h1>
        <ol>
            <li>
                <b>Rapidly Changing Market:</b> Cryptocurrency market is shifting rapidly, therefore it is impossible to
                predict whether market for one or the other digital assets will have or loose authority. Take it into
                consideration and put funds into Digital Assets carefully.
            </li>
            <li>
                <b>Liquidity:</b> Digital Assets are of different value in the market, therefore the ones having less
                value are more vulnerable. Nobody can guarantee longevity of one asset in the market. CoinSupply cannot
                guarantee and is not responsible for digital cryptocurrency being on the website to have a high market
                in the future.
            </li>
            <li>
                <b>Legality:</b> Since Cryptocurrency market is new there is no clear legality of Assets and trading.
                CoinSupply is not responsible of knowing the legality of each Digital Asset and it fully falls on the
                participant side.
            </li>
        </ol>
    </Content>
)
