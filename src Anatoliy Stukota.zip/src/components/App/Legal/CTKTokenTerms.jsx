import React from 'react'
import { Content } from './styled'
import Maintenance from '../Maintenance/Maintenance'

export default () => (
    <Content padding="10rem 0 0 0">
        <Maintenance underConstruction />
    </Content>
)
