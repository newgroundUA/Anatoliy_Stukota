import React from 'react'
import { Content } from './styled'

export default () => (
    <Content width="60vw">
        <h1>Privacy Policy</h1>
        <p>
            The aim of personal data management regulations (hereafter – Regulations) together with Terms and Conditions
            is to regulate personal data management in Coin Supply AG. The purpose of regulations – is to inform you
            about kinds of personal information we may collect about you, purpose and disclosure of personal information
            to third parties.
        </p>
        <h3>USE AND GATHERING OF YOUR PERSONAL INFORMATION</h3>
        <p>The following are personal information we collect:</p>
        <ol>
            <li>Name</li>
            <li>E-mail address</li>
            <li>IP address, Browser and Operating System information</li>
            <li>Your trades</li>
        </ol>
        <p>CoinSupply will gather and process your personal information to proceed the following:</p>
        <ol>
            <li>To open personal account on the CoinSupply website</li>
            <li>To be able start trading, depositing and withdraw digital assets</li>
            <li>To communicate with you on the trading issues you may have</li>
            <li>To perform analysis on CoinSupply website</li>
            <li>To use it for regulatory purposes which may arise, such as Fraud and Money Laundering Prevention</li>
        </ol>
        <h3>USE OF COOKIES</h3>
        <p>
            Browser feature as cookies are stored in user’s computer and are being used to hold information about the
            user on specific website. CoinSupply gathers this information in order to monitor effectiveness and data of
            the site. It allows us to make qualitative analysis on how website works, where customers might struggle and
            determines overall performance of the website. By using third party service we have better understanding on
            customer behavior, what pages are browsed and general transaction information. Information gathered by third
            party is linked to what CoinSupply gathers generally about you. Please note that third party is restricted
            to use your data other than providing information to us. By using our website you agree that we use cookies
            described above.
        </p>
        <h3>USE OF IP ADDRESSES</h3>
        <p>
            CoinSupply collects information about your IP address, Browser and Operating system. This statistical
            information is used by system administrators to detect patterns and browsing actions.
        </p>
        <h3>DISCLOSURE OF PERSONAL DATA</h3>
        <p>CoinSupply uses personal data as mentioned in this Privacy Policy act or/and permitted by Law.</p>
        <p>
            Your personal information is accessible to our agents, representatives, business contractors, service
            providers for limited purposes mentioned above.
        </p>
        <p>We may use your personal information with law enforcements or other agencies if law requires.</p>
        <p>
            Third Parties can access and have personal information but only as regulated by us and to carry out services
            they are performing to CoinSupply.
        </p>
        <h3>YOUR RIGHTS OF PERSONAL INFORMATION</h3>
        <p>
            You have all rights to access your information on the CoinSupply website, to require updates and corrections
            to it. You can do so by contacting our support team at{' '}
            <a href="mailto:support@coinsupply.com">support@coinsupply.com</a>. Our support team will communicate and
            update your request.
        </p>
        <p>
            You have all rights of requesting information to be deleted and access to your account deactivated. You can
            do so by contacting our support team at <a href="mailto:support@coinsupply.com">support@coinsupply.com</a>.
            This request will have immediate attention and we will delete your personal and account information.
        </p>
        <h3>PHISHING AND EMAIL SCAMS DISCLAIMER</h3>
        <p>
            CoinSupply is not partnered with any agents or representatives who claims to be able to solve issues for
            money on your accounts. CoinSupply provides customer service free of charge and it is only provided on the
            website.
        </p>
        <h3>Contact Us</h3>
        <p>
            If you have any questions, feedback specifically regarding our Privacy Policy, please do not hesitate to
            contact us at <a href="mailto:support@coinsupply.com">support@coinsupply.com</a>.
        </p>
    </Content>
)
