import styled from 'styled-components'

const Buttons = styled.div`
    display: flex;
    justify-content: center;
    margin-top: 3.125rem;
    button {
        margin: 0 0.9375rem;
    }
    a:last-child button {
        padding: 0 2.1875rem;
    }
`

export { Button } from 'common'
export { Buttons }
