import React from 'react'
import { Link } from 'react-router-dom'
import { Wrap, Title, Text, Icon } from 'common/SecondaryLayout'
import Message from 'i18n/Message'
import { Buttons, Button } from './styled'

export default () => (
    <Wrap>
        <Icon name="user-ok" />
        <Title>
            <Message id="congratulations" />
        </Title>
        <Text>
            <Message id="yourAccountHasBeenCreated" />
        </Text>
        <Buttons>
            <Link to="/">
                <Button secondary>
                    <Message id="remindMeLater" />
                </Button>
            </Link>
            <Link to="/register/2fa">
                <Button>
                    <Message id="enable2FA" />
                </Button>
            </Link>
        </Buttons>
    </Wrap>
)
