import React from 'react'
import { Wrap, Title, Text, Icon } from 'common/SecondaryLayout'

export default () => (
    <Wrap>
        <Icon name="mail" />
        <Title>Email Verification</Title>
        <Text>
            To complete the registration process look for an email in your <br /> inbox that provides further
            instructions. If you cannot find the <br /> email, please check your spam folder.
        </Text>
    </Wrap>
)
