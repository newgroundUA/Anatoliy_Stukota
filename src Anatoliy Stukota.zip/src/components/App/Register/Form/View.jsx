import React from 'react'
import { observer, inject } from 'mobx-react'
import { MaterialInput, Button, Checkbox, ButtonWrap, RecaptchaWrap } from 'common'
import Recaptcha from 'react-recaptcha'
import { Link } from 'react-router-dom'
import Message from 'i18n/Message'

export default inject('app')(
    observer(
        ({ form, app }) =>
            app.features.isSignUpActivationEnabled ? (
                <form onSubmit={form.handleSubmit}>
                    <MaterialInput field={form.$('login')} label="Email" />
                    <MaterialInput field={form.$('password')} type="password" label="Create password" />
                    <MaterialInput field={form.$('confirmPassword')} type="password" label="Confirm Password" />
                    <Checkbox
                        field={form.$('agreeTos')}
                        type="checkbox"
                        primary
                        label={
                            <span>
                                <Message id="byCreatingThisAccountYouAgreeToOur" />{' '}
                                <Link to="/">
                                    {' '}
                                    <Message id="userAgreement" />{' '}
                                </Link>{' '}
                                <Message id="and" />
                                <Link to="/">
                                    {' '}
                                    <Message id="privacyPolicy" />{' '}
                                </Link>.
                            </span>
                        }
                    />
                    <RecaptchaWrap>
                        <Recaptcha
                            ref={node => {
                                form.recaptcha = node
                            }}
                            render="explicit"
                            sitekey={app.siteKey}
                            verifyCallback={form.$('recaptchaToken').onChange}
                            onloadCallback={form.$('recaptchaToken').onChange}
                            theme="dark"
                        />
                    </RecaptchaWrap>
                    <ButtonWrap left>
                        <Button fullWidth single type="submit" loading={form.submitting}>
                            <Message id="createMyAccount" />
                        </Button>
                    </ButtonWrap>
                </form>
            ) : (
                <Message id="sorryButSignUpIsTemporaryUnavailable" />
            )
    )
)
