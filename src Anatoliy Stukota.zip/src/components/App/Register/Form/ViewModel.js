import Form from '@utils/Form'
import { validator, passwordStrength, emailStrength } from '@utils/Form/validator'
import { createUser } from '../../../../api/auth'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'login',
                value: ''
            },
            {
                name: 'password',
                type: 'password',
                value: ''
            },
            {
                name: 'confirmPassword',
                type: 'password',
                value: ''
            },
            {
                name: 'recaptchaToken',
                value: ''
            },
            {
                name: 'agreeTos',
                type: 'checkbox'
            }
        ]
    }

    validate = validator([
        {
            name: 'login',
            isRequired: true,
            minLength: 5,
            maxLength: 50,
            test: emailStrength
        },
        {
            name: 'password',
            isRequired: true,
            minLength: 9,
            maxLength: 50,
            test: passwordStrength
        },
        {
            name: 'confirmPassword',
            isRequired: true,
            minLength: 9,
            maxLength: 50,
            test: (value, form) => (value !== form.fields.password.value ? 'passwordsDontMatch' : '')
        },
        {
            name: 'recaptchaToken',
            isRequired: false
        },
        {
            name: 'agreeTos',
            test: value => !value && 'agreesMustBeChecked'
        }
    ])

    onSubmit = form => createUser(form.getValues())

    onSubmitSuccess = () => {
        this.store.router.push('/register/confirm')
        this.store.notifications.notify({
            title: 'success',
            message: 'register.success'
        })
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.recaptcha.reset()
        this.store.notifications.notify({
            title: 'registerFailed',
            message: errorCode
        })
        this.set('error', errorCode)
    }
}
