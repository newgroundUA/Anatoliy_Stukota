import styled from 'styled-components'
import { Link } from 'react-router-dom'
import is from 'styled-is'
import { Button as _Button, ButtonWrap as _ButtonWrap } from 'common'

const QR = styled.div`
    width: 8.625rem;
    height: 8.625rem;
    margin-right: 1.625rem;
    img {
        width: 100%;
    }
`

const Title = styled.h4`
    font-weight: 600;
    font-size: 0.875rem;
    color: #ffffff;
    padding-bottom: 1.25rem;
`

const Block = styled.div`
    padding-bottom: 1.875rem;
`

const CustomLink = styled(Link)`
    margin-right: 0.625rem;
`

const Field = styled.div`
    display: flex;
`
const ActionButton = styled(_Button)`
    margin-left: 0.9375rem;
    flex: none;
    font-size: 1.125rem;
    color: #02e866;
`
const Form = styled.div`
    flex: 1;
    padding-right: 6.125rem;
    position: relative;
    top: -0.375rem;
`
const ButtonWrap = styled(_ButtonWrap)`
    ${is('inline')`display: flex;`};
`
export { Button } from 'common'
export { Block, Field, QR, Title, CustomLink, ActionButton, Form, ButtonWrap }
