import Form from '@utils/Form'
import { validator } from '@utils/Form/validator'
import { integer } from '@utils/Form/normalizers'
import { enableTwoFa } from '../../../../../api/profile'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'authCode',
                normalize: integer
            },
            {
                name: 'signup',
                value: true
            }
        ]
    }

    validate = validator([
        {
            name: 'authCode',
            isRequired: true,
            minLength: 6,
            maxLength: 6
        }
    ])

    handleLater = () => {
        this.store.router.push('/trade')
    }

    onSubmit = form => enableTwoFa(form.getValues())

    onSubmitSuccess = () => {
        this.store.router.push('/register/2fa/success')
        this.store.app.user.set('twoFaEnabled', true)
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'failWhileEnabling2FA',
            message: errorCode
        })
    }
}
