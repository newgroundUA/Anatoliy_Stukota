import React from 'react'
import { observer } from 'mobx-react'
import { Button, Input } from 'common'
import Message from 'i18n/Message'
import { ButtonWrap } from '../styled'

export default observer(({ form, signup }) => (
    <form onSubmit={form.handleSubmit}>
        <Input primary label={<Message id="enter2FACodeFromTheApp" />} field={form.$('authCode')} />
        <ButtonWrap inline={signup}>
            {signup && (
                <Button secondary fullWidth onClick={form.handleLater} type="button">
                    <Message id="remindMeLater" />
                </Button>
            )}
            <Button fullWidth loading={form.submitting}>
                <Message id="enter2FA" />
            </Button>
        </ButtonWrap>
    </form>
))
