import React from 'react'
import { Link } from 'react-router-dom'
import { Input, Flex, Icon, Tooltip } from 'common'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'
import Ios from './icon/ios.svg'
import Google from './icon/google.svg'
import { Title, Block, Field, QR, CustomLink, ActionButton, Form } from './styled'

@inject('app')
export default class index extends React.Component {
    getQRLink = (login, twoFaSecret) =>
        'https://chart.googleapis.com/chart?chs=120x120&chld=M|0&cht=qr&chl=otpauth://totp/' +
        `CoinSupply:${login}?secret=${twoFaSecret}&issuer=CoinSupply`

    copyToClipboard = () => {
        this.input.select()
        document.execCommand('Copy')
    }

    handleDownload = text => () => {
        const link = document.createElement('a')
        link.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }))
        link.download = 'backup-key.txt'
        document.body.appendChild(link)
        link.click()
        link.remove()
    }

    render() {
        const { twoFaSecret } = this.props
        return (
            <div>
                <Block>
                    <Title>
                        <Message id="forSecurityWeHighlyRecommendToEnable2FA" />
                    </Title>
                </Block>
                <Block>
                    <Title>
                        1. <Message id="downloadAndInstallApp" />
                    </Title>
                    <CustomLink to="https://itunes.apple.com/app/google-authenticator/id388497605" target="__blank">
                        <Ios />
                    </CustomLink>
                    <Link
                        to="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2"
                        target="__blank"
                    >
                        <Google />
                    </Link>
                </Block>
                <Block>
                    <Title>
                        2. <Message id="downloadOrCopy2ndBackupKey" />
                    </Title>
                    <Field>
                        <Input
                            value={twoFaSecret}
                            primary
                            innerRef={input => {
                                this.input = input
                            }}
                            readOnly
                        />
                        <Tooltip inline text={<Message id="copy" />}>
                            <ActionButton secondary onClick={this.copyToClipboard}>
                                <Icon name="copy" />
                            </ActionButton>
                        </Tooltip>
                        <Tooltip inline text={<Message id="download" />}>
                            <ActionButton secondary onClick={this.handleDownload(twoFaSecret)}>
                                <Icon name="save" />
                            </ActionButton>
                        </Tooltip>
                    </Field>
                </Block>
                <Block>
                    <Title>
                        3. <Message id="scanQRCode" />
                    </Title>
                    <Flex>
                        <QR>
                            <img src={this.getQRLink(this.props.app.user.login, twoFaSecret)} />
                        </QR>
                        <Form>{this.props.children}</Form>
                    </Flex>
                </Block>
            </div>
        )
    }
}
