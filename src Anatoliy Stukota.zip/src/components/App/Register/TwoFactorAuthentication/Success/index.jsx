import React from 'react'
import { Link } from 'react-router-dom'
import { Button } from 'common'
import { Wrap, Title, Text, ButtonWrap, Icon } from 'common/SecondaryLayout'

export default () => (
    <Wrap>
        <Icon name="secure" />
        <Title>Congratulations!</Title>
        <Text>
            You have successfully enabled two-factor authentication <br />
            on your account.
        </Text>
        <Text>Your account is now secure</Text>
        <ButtonWrap>
            <Link to="/trade">
                <Button fullWidth single>
                    Start using CoinSupply
                </Button>
            </Link>
        </ButtonWrap>
    </Wrap>
)
