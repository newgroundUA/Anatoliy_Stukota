import React from 'react'
import { inject } from 'mobx-react'
import { MainTitle, Content } from 'common/SecondaryLayout'
import Steps from './Steps'
import { FormView, FormViewModel } from './Form'

export default inject('router')(({ router }) => (
    <Content width="33.75rem">
        <MainTitle>Two-Factor Authentication</MainTitle>
        <Steps twoFaSecret={router.location.query.twoFaSecret}>
            <FormView form={new FormViewModel()} signup />
        </Steps>
    </Content>
))
