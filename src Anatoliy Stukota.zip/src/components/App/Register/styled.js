import styled from 'styled-components'
import { get } from '@utils/themeHelpers'

const Content = styled.section`
    width: ${({ width }) => width || '23.25rem'};
`

const Title = styled.h1`
    font-size: 2.375rem;
    color: #ffffff;
    padding-bottom: 2rem;
    font-weight: 500;
`
const Text = styled.p`
    font-size: 1.125rem;
    color: #ffffff;
    padding-bottom: 0.125rem;
    ${get('linkStyle')};
    a {
        padding-left: 0.625rem;
    }
`
const Wrap = styled.div``

export { Content, Text, Title, Wrap }
