import React from 'react'
import { NavLink } from 'react-router-dom'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Form'
import { Content, Title, Text } from './styled'

export default () => (
    <Content>
        <Text>
            <Message id="alreadyHaveAnAccount" />
            <NavLink to="/login">
                <Message id="login" />
            </NavLink>
        </Text>
        <Title>
            <Message id="createYourAccount" />
        </Title>
        <FormView form={new FormViewModel()} />
    </Content>
)
