import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import { Link } from 'react-router-dom'

const Content = styled.section`
    width: 23.25rem;
`

const Forgot = styled(Link)`
    color: ${get('linkColor')};
    font-size: 0.75rem;
`

const Text = styled.p`
    font-size: 1.125rem;
    color: #ffffff;
    padding-bottom: 0.125rem;
    ${get('linkStyle')};
    a {
        padding-left: 0.625rem;
    }
`

export { Content, Text, Forgot }
