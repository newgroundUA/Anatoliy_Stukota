import React from 'react'
import { NavLink } from 'react-router-dom'
import { MainTitle as Title } from 'common/SecondaryLayout'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Form'

import { Content, Text } from './styled'

export default () => (
    <Content>
        <Text>
            <Message id="doNotHaveAnAccountYet" />
            <NavLink to="/register">
                <Message id="signUp" />
            </NavLink>
        </Text>
        <Title>
            <Message id="welcomeBack" />
        </Title>
        <FormView form={new FormViewModel()} />
    </Content>
)
