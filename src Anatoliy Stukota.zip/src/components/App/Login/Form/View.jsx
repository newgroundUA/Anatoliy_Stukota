import React from 'react'
import { observer, inject } from 'mobx-react'
import { MaterialInput, Button, RecaptchaWrap, ButtonWrap } from 'common'
import Recaptcha from 'react-recaptcha'
import Message from 'i18n/Message'
import { Forgot } from './../styled'

export default inject('app')(
    observer(({ form, app }) => (
        <form onSubmit={form.handleSubmit}>
            <MaterialInput field={form.fields.login} placeholder="Your email address" />
            <MaterialInput
                field={form.fields.password}
                placeholder="Your password"
                type="password"
                extra={
                    <Forgot to="/login/forgot">
                        <Message id="forgotPassword" />
                    </Forgot>
                }
            />
            <RecaptchaWrap>
                <Recaptcha
                    ref={node => {
                        form.recaptcha = node
                    }}
                    render="explicit"
                    sitekey={app.siteKey}
                    verifyCallback={form.fields.recaptchaToken.onChange}
                    onloadCallback={form.fields.recaptchaToken.onChange}
                    theme="dark"
                />
            </RecaptchaWrap>
            <ButtonWrap left>
                <Button fullWidth single type="submit" loading={form.submitting}>
                    <Message id="login" />
                </Button>
            </ButtonWrap>
        </form>
    ))
)
