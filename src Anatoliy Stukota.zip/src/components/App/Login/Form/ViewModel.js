import { getEnv } from 'mobx-state-tree'
import Form from '@utils/Form/index'
import { validator, emailStrength } from '@utils/Form/validator'
import { loginUser } from '../../../../api/auth'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'login',
                label: 'Login',
                placeholder: 'Insert Login',
                value: ''
            },
            {
                name: 'password',
                label: 'Password',
                placeholder: 'Insert Password',
                type: 'password',
                value: ''
            },
            {
                name: 'recaptchaToken',
                value: ''
            }
        ]
    }

    validate = validator([
        {
            name: 'login',
            isRequired: true,
            minLength: 5,
            maxLength: 50,
            test: emailStrength
        },
        {
            name: 'password',
            isRequired: true,
            minLength: 9,
            maxLength: 50
        }
    ])

    onSubmit = () => loginUser(this.getValues())

    onSubmitSuccess = ({ userInfo, twoFaConfirmToken }) => {
        if (userInfo.twoFaEnabled) {
            this.store.app.setUser(userInfo)
            this.store.router.push({
                pathname: '/login/2fa',
                search: `?token=${twoFaConfirmToken}`
            })
        } else {
            const { socket } = getEnv(this.store)
            const {
                query: { from }
            } = this.store.router.location
            this.store.app.setUser(userInfo)
            socket.reconnect()
            this.store.router.push(from || '/trade')
        }
    }

    onSubmitFail = e => {
        this.recaptcha.reset()
        if (e.error) {
            this.error = e.error.errorCode
            this.store.notifications.notify({
                title: 'loginFailed',
                message: e.error.errorCode
            })
        }
    }
}
