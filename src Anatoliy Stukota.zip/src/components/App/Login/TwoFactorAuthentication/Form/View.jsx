import React from 'react'
import { MaterialInput, Button, ButtonWrap } from 'common'
import { observer } from 'mobx-react'

export default observer(({ form }) => (
    <form onSubmit={form.handleSubmit}>
        <MaterialInput field={form.$('oneTimeAuthCode')} label="Enter 2FA code from the app" />
        <ButtonWrap left>
            <Button fullWidth single type="submit" loading={form.submitting}>
                Enter
            </Button>
        </ButtonWrap>
    </form>
))
