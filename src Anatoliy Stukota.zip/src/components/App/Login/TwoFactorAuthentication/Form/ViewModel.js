import { getEnv } from 'mobx-state-tree'
import Form from '@utils/Form'
import { validator } from '@utils/Form/validator'
import { confirmTwoFa } from '../../../../../api/auth'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'oneTimeAuthCode'
            }
        ]
    }

    validate = validator([
        {
            name: 'oneTimeAuthCode',
            isRequired: true,
            minLength: 6,
            maxLength: 6
        }
    ])

    onSubmit = () => {
        const { token: twoFaToken } = this.store.router.location.query
        return confirmTwoFa({ ...this.getValues(), twoFaToken })
    }

    onSubmitSuccess = user => {
        const { socket } = getEnv(this.store)
        this.store.app.setUser(user)
        socket.reconnect()

        this.store.router.push('/trade')
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
    }
}
