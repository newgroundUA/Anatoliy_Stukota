import React from 'react'
import { Content, MainTitle, Text, FormWrap } from 'common/SecondaryLayout'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Form'

export default () => (
    <Content width="28.125rem">
        <MainTitle noPadding>
            <Message id="oneMoreStep" />
        </MainTitle>
        <Text>
            <Message id="enter2FATokenFromApp" />
        </Text>
        <FormWrap>
            <FormView form={new FormViewModel()} />
        </FormWrap>
    </Content>
)
