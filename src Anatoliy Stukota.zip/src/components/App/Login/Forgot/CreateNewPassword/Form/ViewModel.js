import { parseQuery } from 'data-fetcher'
import Form from '@utils/Form'
import { passwordStrength, validator } from '@utils/Form/validator'
import { resetPassword } from '../../../../../../api/auth'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'newPassword',
                placeholder: 'Create password',
                type: 'password'
            },
            {
                name: 'newPasswordConfirmation',
                placeholder: 'Confirm password',
                type: 'password'
            },
            {
                name: 'authCode'
            }
        ]
    }

    validate = validator([
        {
            name: 'newPassword',
            isRequired: true,
            minLength: 5,
            maxLength: 50,
            test: passwordStrength
        },
        {
            name: 'newPasswordConfirmation',
            isRequired: true,
            minLength: 5,
            maxLength: 50,
            test: (value, form) => (value !== form.fields.newPassword.value ? 'passwordsDontMatch' : '')
        },
        {
            name: 'authCode',
            test: (value, form) =>
                form.store.router.location.query['2faEnabled'] === 'true' && (!value || value.toString().length !== 6)
                    ? 'enterOneTimeCode'
                    : ''
        }
    ])

    onSubmit = () => {
        const { token } = parseQuery(this.store.router.location.search)
        return resetPassword({ ...this.getValues(), token })
    }

    onSubmitSuccess = () => {
        this.store.router.push('/login/forgot/congrats')
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
    }
}
