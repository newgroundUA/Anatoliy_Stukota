import React from 'react'
import { MaterialInput, Button, ButtonWrap } from 'common'
import { observer } from 'mobx-react'
import Message from 'i18n/Message'

export default observer(({ form, twoFaEnabled }) => (
    <form onSubmit={form.handleSubmit}>
        <MaterialInput field={form.$('newPassword')} type="password" label={<Message id="enterNewPassword" />} />
        <MaterialInput
            field={form.$('newPasswordConfirmation')}
            type="password"
            label={<Message id="confirmNewPassword" />}
        />
        {twoFaEnabled && <MaterialInput field={form.$('authCode')} label={<Message id="enter2FACodeFromTheApp" />} />}
        <ButtonWrap left>
            <Button fullWidth single type="submit" loading={form.submitting}>
                <Message id="saveNewPassword" />
            </Button>
        </ButtonWrap>
    </form>
))
