import React from 'react'
import { parseQuery } from 'data-fetcher'
import { Content, MainTitle } from 'common/SecondaryLayout'
import { FormView, FormViewModel } from './Form'

export default ({ location: { search } }) => {
    const twoFaEnabled = parseQuery(search)['2faEnabled'] === 'true'
    return (
        <Content width="28.125rem">
            <MainTitle noPadding>Create a new password</MainTitle>
            <FormView form={new FormViewModel()} twoFaEnabled={twoFaEnabled} />
        </Content>
    )
}
