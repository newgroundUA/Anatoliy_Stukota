import React from 'react'
import { Wrap, Title, Text, Icon } from 'common/SecondaryLayout'
import Message from 'i18n/Message'

export default () => (
    <Wrap>
        <Icon name="mail" />
        <Title>
            <Message id="checkEmail" />
        </Title>
        <Text>
            <Message id="resetPasswordConfirmationLinkHasBeenSentToYourEmail" /> <br />
            <Message id="pleaseCheckYourEmailToConfirmThePasswordChange" /> <br />
            <Message id="ifYouDontReceiveEmail" />
        </Text>
    </Wrap>
)
