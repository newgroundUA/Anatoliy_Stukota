import Form from '@utils/Form'
import { validator, emailStrength } from '@utils/Form/validator'
import { sendPasswordResetLink } from '../../../../../api/auth'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'email'
            }
        ]
    }

    validate = validator([
        {
            name: 'email',
            isRequired: true,
            test: emailStrength
        }
    ])

    onSubmit = () => sendPasswordResetLink(this.getValues().email)

    onSubmitSuccess = () => {
        this.store.router.push('/login/forgot/check-email')
    }

    onSubmitFail = ({ response: { errorCode } }) => {
        this.invalidate(errorCode)
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
    }
}
