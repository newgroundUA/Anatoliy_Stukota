import React from 'react'
import { MaterialInput, Button, ButtonWrap } from 'common'
import { observer } from 'mobx-react'

export default observer(({ form }) => (
    <form onSubmit={form.handleSubmit}>
        <MaterialInput field={form.$('email')} label="Your email address" />
        <ButtonWrap left>
            <Button fullWidth single type="submit" loading={form.submitting}>
                Submit
            </Button>
        </ButtonWrap>
    </form>
))
