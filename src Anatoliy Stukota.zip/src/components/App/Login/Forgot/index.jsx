import React from 'react'
import { Content, MainTitle, Text, FormWrap } from 'common/SecondaryLayout'
import { FormView, FormViewModel } from './Form'

export default () => (
    <Content width="28.125rem">
        <MainTitle>Reset password</MainTitle>
        <Text>
            To reset your password, enter the email address you use to sign in to CoinSupply. It can be your email
            address, an email address you use with one of the social networks, or any email address associated with your
            account.
        </Text>
        <FormWrap>
            <FormView form={new FormViewModel()} />
        </FormWrap>
    </Content>
)
