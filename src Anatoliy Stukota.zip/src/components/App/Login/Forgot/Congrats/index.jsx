import React from 'react'
import { Button } from 'common'
import { Link } from 'react-router-dom'
import { Wrap, Title, Text, ButtonWrap, Icon } from 'common/SecondaryLayout'

export default () => (
    <Wrap>
        <Icon name="success" />
        <Title>Congratulations!</Title>
        <Text>Your password has been successfully changed</Text>
        <ButtonWrap>
            <Link to="/login">
                <Button fullWidth single>
                    Start Using CoinSupply
                </Button>
            </Link>
        </ButtonWrap>
    </Wrap>
)
