import React from 'react'
import TradeBlock from './TradeBlock'
import Tickers from './Tickers'
import { Aside } from './styled'

export default () => (
    <Aside>
        <Tickers />
        <TradeBlock />
    </Aside>
)
