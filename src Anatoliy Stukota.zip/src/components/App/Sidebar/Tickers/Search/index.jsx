import React from 'react'
import { observer } from 'mobx-react'
import { Input, Icon } from 'common'
import { Wrap, SearchWrap, SearchButton, CloseButton, SearchIcon } from './styled'

@observer
export default class Search extends React.Component {
    state = {
        open: false
    }

    handleOpen = () => {
        this.setState({
            open: true
        })
        this.ref.focus()
    }

    handleClose = () => {
        this.setState({
            open: false
        })
        this.props.model.clearSearchField()
    }

    render() {
        const { model } = this.props
        return (
            <Wrap active={this.state.open}>
                <SearchButton onClick={this.state.open ? this.handleClose : this.handleOpen}>
                    <SearchIcon name="search" />
                </SearchButton>
                <SearchWrap isOpen={this.state.open}>
                    <Input
                        onChange={model.handleSearchFieldChange}
                        value={model.searchField}
                        innerRef={node => {
                            this.ref = node
                        }}
                    />
                    <CloseButton onClick={this.handleClose}>
                        <Icon name="remove" />
                    </CloseButton>
                </SearchWrap>
            </Wrap>
        )
    }
}
