import styled from 'styled-components'
import { Icon as _Icon } from 'common'
import is from 'styled-is'

const SearchIcon = styled(_Icon)`
    font-size: 0.875rem;
`

const Wrap = styled.div`
    background-color: #1f273b;
    display: flex;
    align-items: center;
    overflow: hidden;
    padding-left: 0.3125rem;
    position: absolute;
    right: 0;
    ${is('active')`${SearchIcon} {color: #fff;}`};
    width: ${({ active }) => (active ? '8.375rem' : '1rem')};
    transition: width 0.3s;
`

const SearchWrap = styled.div`
    width: 7.5rem;
    display: flex;
    align-items: center;
    input,
    input:focus {
        background-color: #1f273b;
        height: 1.625rem;
    }
    & > div {
        padding: 0;
    }
`
const SearchButton = styled.div`
    cursor: pointer;
    color: #808f92;
    &:hover {
        ${SearchIcon} {
            color: #fff;
            transition: all 0.3s;
        }
    }
`
const CloseButton = styled.button`
    background-color: transparent;
    width: 1.5rem;
    height: 1.5rem;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
    color: #808f92;
    font-size: 0.625rem;
    &:hover {
        transition: all 0.3s;
        color: #fff;
    }
`

export { SearchWrap, Wrap, SearchButton, CloseButton, SearchIcon }
