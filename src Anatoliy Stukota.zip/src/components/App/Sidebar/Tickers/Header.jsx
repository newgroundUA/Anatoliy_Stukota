import React from 'react'
import { observer } from 'mobx-react'
import { Tabs, Tab, Icon } from 'common'
import Search from './Search'
import { FavoriteIcon, Header as Wrap } from './styled'

@observer
export default class Header extends React.Component {
    handleClick = mode => {
        this.props.model.changeMode(mode)
    }

    render() {
        const { model } = this.props
        return (
            <Wrap>
                <Tabs active={model.mode} actions={<Search model={model} />}>
                    <Tab
                        label={
                            <FavoriteIcon>
                                <Icon name="star" /> Favorited
                            </FavoriteIcon>
                        }
                        value="favorited"
                        onClick={this.handleClick}
                    />
                    <Tab label="BTC" value="BTC" onClick={this.handleClick} />
                    <Tab label="ETH" value="ETH" onClick={this.handleClick} />
                </Tabs>
                {this.props.children}
            </Wrap>
        )
    }
}
