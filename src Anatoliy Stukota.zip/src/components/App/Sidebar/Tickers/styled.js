import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import { isNot } from 'styled-is'
import { Icon } from 'common'

const CurrencyIcon = styled(Icon)`
    font-size: 0.875rem;
    color: #fff;
`

const ScrollWrap = styled.div`
    max-height: calc(100vh - 26.375rem - 3.3125rem - ${get('headerHeight')});
    min-height: 5.3125rem;
    overflow: auto;
    width: 100%;
    border-bottom: 1px solid #444;
`

const PerCentRow = styled.td`
    max-width: 2.375rem;
    width: 2.375rem;
    text-align: right;
    font-weight: 600;
    font-size: 0.75rem;
    color: ${({ plus }) => (plus ? get('green') : get('red'))};
`
const CurrencyIconRow = styled.td`
    vertical-align: middle;
    text-align: center;
    max-width: 1rem;
    width: 1rem;
    padding-left: 0.5rem;
    padding-right: 0.5rem;
`
const Table = styled.table`
    width: 100%;
    border-spacing: 0;
    max-width: 100%;
    background-color: transparent;
    color: #cdd2d6;
    table {
        width: 100%;
        border-spacing: 0;
    }
    .SELL {
        color: ${get('red')};
    }
    .BUY {
        color: ${get('green')};
    }
    tr:hover {
        cursor: pointer;
        td {
            background-color: #1a2130;
        }
    }
    td {
        font-size: 0.75rem;
        height: 2.625rem;
    }
    td:last-child {
        text-align: right;
        padding-right: 1.25rem;
    }

    .active_pair,
    .active_pair:hover {
        cursor: default;
        td:not(${PerCentRow}) {
            color: #fff;
        }
        td {
            background-color: transparent;
            font-weight: bold;
        }
        ${CurrencyIcon} {
            color: #02e866;
        }
    }
`
const Favorite = styled.span`
    cursor: pointer;
    span {
        color: ${({ active }) => (active ? '#02E866' : '#6A7380')};
        font-size: 0.875rem;
    }
    ${isNot('active')`
        &:hover{
            span {
                color: #fff;
            } 
        }
    `};
`
const FavoriteIcon = styled.span`
    span {
        color: ${get('green')};
    }
`

const Header = styled.div`
    margin: 0.625rem 0.7rem 1.25rem;
`
const PairRow = styled.td`
    text-align: left;
    width: 4.125rem;
    max-width: 4.3125rem;
`

const FavoriteRow = styled.td`
    max-width: 0.875rem;
    width: 0.875rem;
    text-align: left;
    padding-left: 0.7rem;
`

export { Wrap } from '../styled'
export {
    Table,
    ScrollWrap,
    Favorite,
    FavoriteIcon,
    Header,
    PairRow,
    CurrencyIconRow,
    FavoriteRow,
    PerCentRow,
    CurrencyIcon
}
