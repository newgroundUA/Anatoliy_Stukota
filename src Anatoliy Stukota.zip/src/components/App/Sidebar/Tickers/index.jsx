import React from 'react'
import { inject } from 'mobx-react'
import Tickers from './Tickers'
import Header from './Header'
import TickersViewModel from './TickersViewModel'

export default inject('app', 'router')(({ app, router }) => {
    const model = new TickersViewModel(app, router)
    return (
        <div>
            <Header model={model} />
            <Tickers model={model} />
        </div>
    )
})
