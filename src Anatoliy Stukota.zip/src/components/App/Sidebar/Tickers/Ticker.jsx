import React from 'react'
import { observer } from 'mobx-react'
import { Icon } from 'common'
import { round } from '@utils'
import { Favorite, PairRow, CurrencyIconRow, FavoriteRow, PerCentRow, CurrencyIcon } from './styled'

@observer
export default class Ticker extends React.Component {
    handleClickPair = e => {
        if (e.target.tagName !== 'TD') return

        const {
            model: { router },
            pair
        } = this.props
        router.push(`/trade/${pair.name}`)
    }

    handleClickFavorite = () => {
        const { model, pair } = this.props
        if (model.favorites.findIndex(item => item === pair.name) !== -1) {
            this.props.model.removeFavourite(this.props.pair.name)
        } else {
            this.props.model.addFavourite(this.props.pair.name)
        }
    }

    render() {
        const { pair, model } = this.props
        const isActive = model.app.currencyPair.name === pair.name

        return (
            <tr onClick={this.handleClickPair} className={`${isActive ? 'active_pair' : ''}`}>
                <FavoriteRow>
                    <Favorite
                        onClick={this.handleClickFavorite}
                        active={model.favorites.findIndex(item => item === pair.name) !== -1}
                    >
                        <Icon name="star" />
                    </Favorite>
                </FavoriteRow>
                <CurrencyIconRow>
                    <CurrencyIcon name={pair.baseCurrency.code.toLowerCase()} />
                </CurrencyIconRow>
                <PairRow>
                    {pair.baseCurrency.code}/{pair.quoteCurrency.code} <br />
                    {round(pair.volume, 0)}
                </PairRow>
                <PerCentRow plus={pair.dailyChange >= 0}>
                    {pair.dailyChange > 0 && '+'}
                    {round(pair.dailyChangePercent, 0)}%
                </PerCentRow>
                <td>{pair.close}</td>
            </tr>
        )
    }
}
