import { observable, action, computed } from 'mobx'

export default class TickersViewModel {
    constructor(app, router) {
        this.router = router
        this.app = app
        this.mode = this.getMode()
        this.favorites = this.getFavorites()
    }

    getFavorites = () => {
        try {
            const data = JSON.parse(window.localStorage.getItem('favorites'))
            return data.some(item => typeof item !== 'string') ? [] : data
        } catch (e) {
            window.localStorage.setItem('favorites', JSON.stringify([]))
            return []
        }
    }

    getMode = () => {
        const defaultValue = 'BTC'
        const value = window.localStorage.getItem('tickersMode')

        if (typeof value !== 'string') return defaultValue
        if (['ETH', 'BTC', 'favorited'].findIndex(item => item === value) === -1) return defaultValue

        return value
    }

    @observable favorites
    @observable searchField = ''

    @observable mode

    @action
    handleSearchFieldChange = e => {
        this.searchField = (e.target.value || '').toLowerCase()
    }

    @action
    clearSearchField = () => {
        this.searchField = ''
    }

    @action
    addFavourite = value => {
        this.favorites.push(value)
        window.localStorage.setItem('favorites', JSON.stringify(this.favorites))
    }

    @action
    removeFavourite = value => {
        this.favorites = this.favorites.filter(item => item !== value)
        window.localStorage.setItem('favorites', JSON.stringify(this.favorites))
    }

    @action
    changeMode = mode => {
        this.mode = mode
        window.localStorage.setItem('tickersMode', mode)
    }

    @computed
    get items() {
        return this.app.currencyPairs.filter(item => {
            if (this.mode === 'favorited' && !this.favorites.find(fav => fav === item.name)) return false
            if (this.mode !== 'favorited' && item.quoteCurrency.code !== this.mode) return false

            if (this.searchField === '') return true

            return (
                item.baseCurrency.code.toLowerCase().indexOf(this.searchField) !== -1 ||
                item.baseCurrency.name.toLowerCase().indexOf(this.searchField) !== -1 ||
                item.quoteCurrency.code.toLowerCase().indexOf(this.searchField) !== -1 ||
                item.quoteCurrency.name.toLowerCase().indexOf(this.searchField) !== -1
            )
        })
    }
}
