import React from 'react'
import { observer } from 'mobx-react'
import NoData from 'common/NoData'
import { Table, ScrollWrap } from './styled'
import Ticker from './Ticker'

export default observer(({ model }) => (
    <ScrollWrap className="scrollbar">
        <div>
            {model.items.length ? (
                <Table>
                    <tbody>{model.items.map(item => <Ticker key={item.name} model={model} pair={item} />)}</tbody>
                </Table>
            ) : (
                <NoData style={{ minHeight: '6.25rem' }}>No Favorited Pair</NoData>
            )}
        </div>
    </ScrollWrap>
))
