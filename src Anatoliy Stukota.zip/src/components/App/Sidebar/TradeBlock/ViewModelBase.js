import Form from '@utils/Form'
import validate from './validate'
import { digit, normalizeAmountByMarket, normalizePriceByMarket, normalizeTotal } from './normalizers'
import { onChangeAmountHook, onChangePriceHook, onChangeTotalHook } from './hooks'

export default class ViewModelBase extends Form {
    constructor() {
        super()
        this.$('price').onChange(this.store.app.currencyPair.close)
    }

    initializePrice = () => {
        this.$('price').onChange(this.store.app.currencyPair.close)
    }

    initFields() {
        return [
            {
                name: 'amount',
                value: '',
                afterChange: onChangeAmountHook,
                normalize: [digit, normalizeAmountByMarket]
            },
            {
                name: 'price',
                value: '',
                afterChange: onChangePriceHook,
                normalize: [digit, normalizePriceByMarket]
            },
            {
                name: 'total',
                value: '',
                afterChange: onChangeTotalHook,
                normalize: [digit, normalizeTotal]
            }
        ]
    }

    validate = validate

    putPartOfAmount = part => () => {
        const { balance } = this.store.app.currencyPair.baseCurrency.account
        const $part = (balance / 100) * part

        const amount = this.$('amount')
        amount.onChange($part)
    }

    onSubmitSuccess = order => {
        if (this.type !== 'market') {
            this.store.app.user.openOrders.pushOrder(order)
        }

        this.store.notifications.notify({
            title: 'order.placed',
            message: 'order.info',
            data: order
        })

        this.$('amount').clear()
        this.$('total').clear()
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('value', errorCode)
        this.store.notifications.notify({
            title: 'error',
            message: errorCode
        })
    }
}
