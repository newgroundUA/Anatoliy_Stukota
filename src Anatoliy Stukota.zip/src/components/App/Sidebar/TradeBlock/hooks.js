import { format } from '@utils'
import { normalizeAmountByMarket } from './normalizers'

const onChangeAmountHook = (e, form) => {
    const amount = form.$('amount').value

    const total = form.$('total')
    const price = form.$('price').value

    if (price && amount) {
        total.set('value', format(price * amount).value)
    } else {
        total.set('value', '')
    }
}

const onChangePriceHook = (e, form) => {
    const price = Number(form.$('price').value)

    const total = form.$('total')
    const amount = Number(form.$('amount').value)

    if (price && amount) {
        total.set('value', format(price * amount).value)
    } else {
        total.set('value', '')
    }
}

const onChangeTotalHook = (e, form) => {
    const total = Number(form.$('total').value)
    const price = Number(form.$('price').value)

    if (total && price) {
        form.$('amount').set('value', normalizeAmountByMarket((total / price).toFixed(8), form.$('amount')))
    }
}

export { onChangeAmountHook, onChangePriceHook, onChangeTotalHook }
