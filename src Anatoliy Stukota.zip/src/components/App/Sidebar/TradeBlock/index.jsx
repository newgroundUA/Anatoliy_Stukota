import React from 'react'
import { Tabs, Tab } from 'common'
import { Wrap } from '../styled'
import Limit from './Limit'
import Market from './Market'

export default () => (
    <Wrap>
        <Tabs>
            <Tab label="Limit">
                <Limit />
            </Tab>
            <Tab label="Market">
                <Market />
            </Tab>
            <Tab label="Stop">
                <div style={{ textAlign: 'center', padding: '10px' }}>Coming soon...</div>
            </Tab>
        </Tabs>
    </Wrap>
)
