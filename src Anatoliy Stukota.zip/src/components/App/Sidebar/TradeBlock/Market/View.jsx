import React from 'react'
import { observer } from 'mobx-react'
import { Input, Button } from 'common'
import { emitter } from '@utils'
import Fee from '../Fee'
import { Buttons, Wrap, ButtonAmount } from '../styled'

@observer
export default class View extends React.Component {
    componentDidMount = () => {
        this.subscribes.push(emitter.on('@trade/initializePrice', this.props.form.initializePrice))
    }

    componentWillUnmount = () => {
        this.subscribes.forEach(item => item())
    }

    subscribes = []

    render() {
        const {
            currencyPair: { baseCurrency, quoteCurrency },
            features: { isOrderPlacingEnabled }
        } = this.props.form.store.app

        return (
            <Wrap>
                <Input
                    label="Amount"
                    field={this.props.form.$('amount')}
                    addon={baseCurrency.code}
                    extraTop={
                        <div>
                            <ButtonAmount onClick={this.props.form.putPartOfAmount(25)}>25%</ButtonAmount>
                            <ButtonAmount onClick={this.props.form.putPartOfAmount(50)}>50%</ButtonAmount>
                            <ButtonAmount onClick={this.props.form.putPartOfAmount(75)}>75%</ButtonAmount>
                            <ButtonAmount onClick={this.props.form.putPartOfAmount(100)}>100%</ButtonAmount>
                        </div>
                    }
                />
                <Input label="Price" field={this.props.form.$('price')} addon={quoteCurrency.code} disabled />
                <Input
                    label="Total"
                    field={this.props.form.$('total')}
                    addon={quoteCurrency.code}
                    disabled
                    extraTop={<Fee form={this.props.form} />}
                />

                {
                    <Buttons>
                        <Button
                            onClick={isOrderPlacingEnabled ? this.props.form.handleBuy : undefined}
                            disabled={!isOrderPlacingEnabled}
                            fullWidth
                        >
                            Buy
                        </Button>
                        <Button
                            onClick={isOrderPlacingEnabled ? this.props.form.handleSell : undefined}
                            disabled={!isOrderPlacingEnabled}
                            fullWidth
                            red
                        >
                            Sell
                        </Button>
                    </Buttons>
                }
            </Wrap>
        )
    }
}
