import { validator } from '@utils/Form'
import { placeOrder } from '../../../../../api/orders'
import ViewModelBase from '../ViewModelBase'
import { isValidScale } from '../validators'

export default class ViewModel extends ViewModelBase {
    type = 'market'
    validate = validator([
        {
            name: 'amount',
            isRequired: true,
            test: (value, form) => {
                const { minTotalBaseCurrency, amountScale } = form.store.app.currencyPair

                if (value < minTotalBaseCurrency)
                    return {
                        value: 'minAmountIs',
                        data: { minTotalBaseCurrency }
                    }

                return isValidScale(value, amountScale)
            }
        },
        {
            name: 'price',
            isRequired: false
        },
        {
            name: 'total',
            isRequired: false
        }
    ])

    handleBuy = e => {
        this.onSubmit = () => {
            const { amount, price } = this.getValues()
            const { currencyPair } = this.store.app
            return placeOrder({
                type: 'market',
                side: 'BUY',
                amount,
                price,
                currencyPair: currencyPair.name
            })
        }
        this.handleSubmit(e)
    }

    handleSell = e => {
        this.onSubmit = () => {
            const { amount, price } = this.getValues()
            const { currencyPair } = this.store.app
            return placeOrder({
                type: 'market',
                side: 'SELL',
                amount,
                price,
                currencyPair: currencyPair.name
            })
        }
        this.handleSubmit(e)
    }
}
