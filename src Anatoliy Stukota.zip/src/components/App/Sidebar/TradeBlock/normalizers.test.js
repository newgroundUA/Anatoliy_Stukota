import { roundByScale } from './normalizers'

const scale = 3

test('Normalize value "0" -> "0"', () => {
    const input = '0'
    const output = '0'

    const result = roundByScale(input, scale)

    expect(result).toBe(output)
})

test('Normalize value "0." -> "0."', () => {
    const input = '0.'
    const output = '0.'

    const result = roundByScale(input, scale)

    expect(result).toBe(output)
})

test('Normalize value "0.10002" -> 0.1', () => {
    const input = '0.10002'
    const output = 0.1

    const result = roundByScale(input, scale)

    expect(result).toBe(output)
})

test('Normalize value "." -> "."', () => {
    const input = '.'
    const output = '.'

    const result = roundByScale(input, scale)

    expect(result).toBe(output)
})
