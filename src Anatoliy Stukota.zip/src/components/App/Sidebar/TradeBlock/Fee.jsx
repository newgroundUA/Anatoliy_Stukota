import React from 'react'
import { observer, inject } from 'mobx-react'
import { Text } from './styled'

export default inject('app')(
    observer(({ form, app }) => {
        const amount = Number(form.$('amount').value)
        const price = Number(form.$('price').value)

        return (
            <Text>
                Fee:
                <span> {amount && price ? app.fees.getFee(amount, price).toFixed(8) : '0.00000000'}</span>
            </Text>
        )
    })
)
