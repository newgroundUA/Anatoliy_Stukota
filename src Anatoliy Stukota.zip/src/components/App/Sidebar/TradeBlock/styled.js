import styled from 'styled-components'

const Buttons = styled.div`
    display: flex;
    justify-content: space-between;
    padding-top: 0.9375rem;
    button:first-child {
        margin-left: 0;
    }
    button:last-child {
        margin-left: 0.375rem;
    }
`

const Text = styled.span`
    font-size: 0.75rem;
    color: #808f92;
    letter-spacing: 0;
`
const Wrap = styled.div`
    padding-top: 0.75rem;
`
const ButtonAmount = styled.button`
    font-size: 0.75rem;
    color: #808f92;
    background-color: transparent;
    padding: 0 0.1875rem;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
    &:hover {
        color: #ffffff;
        transition: all 0.3s;
    }
`

export { Buttons, Text, Wrap, ButtonAmount }
