import React from 'react'
import View from './View'
import ViewModel from './ViewModel'

export default () => <View form={new ViewModel()} />
