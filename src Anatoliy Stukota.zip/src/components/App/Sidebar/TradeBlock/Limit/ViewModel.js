import { placeOrder } from '../../../../../api/orders'
import ViewModelBase from '../ViewModelBase'

export default class ViewModel extends ViewModelBase {
    handleBuy = e => {
        this.onSubmit = () => {
            const { amount, price } = this.getValues()
            const { currencyPair } = this.store.app
            return placeOrder({
                type: 'limit',
                side: 'BUY',
                amount,
                price,
                currencyPair: currencyPair.name
            })
        }
        this.handleSubmit(e)
    }

    handleSell = e => {
        this.onSubmit = () => {
            const { amount, price } = this.getValues()
            const { currencyPair } = this.store.app
            return placeOrder({
                type: 'limit',
                side: 'SELL',
                amount,
                price,
                currencyPair: currencyPair.name
            })
        }
        this.handleSubmit(e)
    }
}
