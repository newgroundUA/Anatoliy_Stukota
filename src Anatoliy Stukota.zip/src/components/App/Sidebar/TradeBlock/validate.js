import { validator } from '@utils/Form'
import { isValidScale } from './validators'

export default validator([
    {
        name: 'amount',
        isRequired: true,
        test: (value, form) => isValidScale(value, form.store.app.currencyPair.amountScale)
    },
    {
        name: 'price',
        isRequired: true,
        test: (value, form) => {
            const { minPrice, maxPrice, priceScale } = form.store.app.currencyPair

            if (value < minPrice)
                return {
                    value: 'minPriceIs',
                    data: { minPrice }
                }
            if (value > maxPrice)
                return {
                    value: 'maxPriceIs',
                    data: { maxPrice }
                }

            return isValidScale(value, priceScale)
        }
    },
    {
        name: 'total',
        isRequired: true,
        test: (value, form) => {
            const { minTotalQuoteCurrency, maxTotalQuoteCurrency } = form.store.app.currencyPair

            if (value < minTotalQuoteCurrency)
                return {
                    value: 'minTotalIs',
                    data: { minTotalQuoteCurrency }
                }
            if (value > maxTotalQuoteCurrency)
                return {
                    value: 'maxTotalIs',
                    data: { maxTotalQuoteCurrency }
                }

            return ''
        }
    }
])
