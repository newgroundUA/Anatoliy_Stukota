const isValidScale = (value, scale) => {
    const decimal = String(value).split('.')[1] || ''
    return (
        decimal.length > scale && {
            value: 'maxScaleIs',
            data: { scale }
        }
    )
}

export { isValidScale }
