const digit = (nextValue, { value }) =>
    /^\d*\.?\d*$/.test(nextValue) || !nextValue ? String(nextValue) : String(value)

const roundByScale = (value, scale) => {
    if (value === '' || Number(value) === 0 || value === '.' || value.substr(value.length - 1) === '.') return value

    let result = ''

    const [int, decimal] = Number(value)
        .toFixed(scale)
        .split('.')
    result += int
    if (typeof decimal === 'string') {
        result += `.${decimal.slice(0, scale)}`
    }

    return Number(result)
}

const normalizeAmountByMarket = (value, field) => roundByScale(value, field.form.store.app.currencyPair.amountScale)

const normalizePriceByMarket = (value, field) => roundByScale(value, field.form.store.app.currencyPair.priceScale)

const normalizeTotal = value => roundByScale(value, 8)

export { digit, normalizeAmountByMarket, normalizePriceByMarket, normalizeTotal, roundByScale }
