import styled from 'styled-components'

const Aside = styled.aside`
    width: 100%;
    overflow: hidden;
    box-sizing: border-box;
`
const Wrap = styled.div`
    padding: 0.625rem 0.7rem;
`

export { Aside, Wrap }
