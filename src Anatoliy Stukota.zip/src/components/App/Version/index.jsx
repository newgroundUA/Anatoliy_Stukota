import React from 'react'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'
import { Link } from 'react-router-dom'
import { Button } from 'common'
import { Content, Text, VersionWrap } from './styled'

export default inject('app')(({ app: { version } }) => (
    <VersionWrap>
        <Text>
            <Message id="currentCoinsupplyVersion" /> {version}
        </Text>
        <Content>
            <Link to="/">
                <Button single>
                    <Message id="homePage" />
                </Button>
            </Link>
        </Content>
    </VersionWrap>
))
