import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import { Link } from 'react-router-dom'

const Content = styled.section`
    width: 80%;
    margin: 0 auto;
    padding: 5% 2%;
    h1 {
        margin-bottom: 1.5rem;
    }
`

const Forgot = styled(Link)`
    color: ${get('linkColor')};
    font-size: 0.75rem;
`

const Text = styled.p`
    font-size: 1.125rem;
    color: #ffffff;
    padding-bottom: 0.125rem;
    ${get('linkStyle')};
    a {
        padding-left: 0.625rem;
    }
`

const VersionWrap = styled.div`
    width: 50%;
    text-align: center;
    margin: 10rem auto;
`

export { Content, Text, Forgot, VersionWrap }
