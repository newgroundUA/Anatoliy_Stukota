import styled from 'styled-components'
import { get } from '@utils/themeHelpers'

const Content = styled.main`
    display: flex;
    justify-content: space-between;
    align-items: stretch;
    background-color: #1f273b;
    min-height: ${get('mainHeight')};
    box-sizing: border-box;
`

const Main = styled.main`
    display: block;
    flex: auto;
`

export { Main, Content }
