import React from 'react'
import { Observer, inject } from 'mobx-react'
import { Helmet } from 'react-helmet'
import { renderRoutes } from 'react-router-config'
import Header from '../Header'
import Footer from '../Footer'
import { Content } from './styled'

export default inject('app')(({ route, app }) => (
    <React.Fragment>
        <Header />
        <Observer>
            {() => (
                <Helmet>
                    <title>
                        {`${app.currencyPair.close} ${app.currencyPair.baseCurrency.code}/${
                            app.currencyPair.quoteCurrency.code
                        }`}
                    </title>
                </Helmet>
            )}
        </Observer>
        <Content>{renderRoutes(route.routes)}</Content>
        <Footer />
    </React.Fragment>
))
