import React from 'react'
import { renderRoutes } from 'react-router-config'
import Collapsible from 'common/Collapsible'
import Sidebar from '../Sidebar'
import { Main } from '../Layout/styled'

export default ({ route }) => (
    <React.Fragment>
        <Collapsible name="sidebar" toolbar="right" maxSize="17.1875rem">
            <Sidebar />
        </Collapsible>
        <Main>{renderRoutes(route.routes)}</Main>
    </React.Fragment>
)
