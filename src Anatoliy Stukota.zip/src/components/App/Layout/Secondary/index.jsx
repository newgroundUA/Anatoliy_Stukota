import React from 'react'
import { renderRoutes } from 'react-router-config'
import Particles from 'common/Particles'
import Logo from 'assets/coinsupply.svg'

import { Wrap, Content, LinkLogo, Footer } from './styled'

export default ({ route = {}, children }) => (
    <Wrap>
        <Particles />
        <LinkLogo href="/">
            <Logo />
        </LinkLogo>
        <Content>{renderRoutes(route.routes) || children}</Content>
        <Footer>Copyright © Coin Supply AG {new Date().getFullYear()}. All rights reserved</Footer>
    </Wrap>
)
