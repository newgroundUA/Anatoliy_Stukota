import styled from 'styled-components'

const Wrap = styled.div`
    width: 100%;
    min-height: 100vh;
    background-color: #1a1d24;
    background-image: linear-gradient(225deg, #001625 0%, #1f273b 100%);
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    canvas {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 0;
    }
`
const LinkLogo = styled.a`
    padding: 0.9375rem;
    display: inline-block;
    align-self: flex-start;
    position: relative;
    width: 8.5rem;
    height: 3.0625rem;
    & > * {
        width: 100%;
        height: 100%;
    }
`
const Content = styled.div`
    position: relative;
`

const Footer = styled.p`
    font-size: 0.875rem;
    color: #6a7380;
    padding: 1.25rem 0.3125rem 0.625rem;
    position: relative;
`

export { Wrap, Content, LinkLogo, Footer }
