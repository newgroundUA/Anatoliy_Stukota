import React from 'react'
import { Content, MainTitle, Text, Icon } from 'common/SecondaryLayout'

export default () => (
    <Content center>
        <Icon name="frozen" />
        <MainTitle>Your account has been frozen due to unauthorized activity</MainTitle>
        <Text>
            Your account has been frozen upon your request. Please contact our support team for further instructions.
        </Text>
        <Text>
            <a href="https://support.coinsupply.com/hc/en-us" target="_blank" rel="noopener noreferrer">
                Contact support
            </a>
        </Text>
    </Content>
)
