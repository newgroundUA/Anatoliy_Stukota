import React from 'react'
import { Link } from 'react-router-dom'
import { Button } from 'common'
import { Wrap, Icon, Text, Title, ButtonWrap } from 'common/SecondaryLayout'

export default () => (
    <Wrap>
        <Icon name="transaction" />
        <Title>Your XRP transaction has been successfully confirmed.</Title>
        <Text>132,3455.4325 XRP has been send to jkhsgksi85ty7o2hasf356</Text>
        <ButtonWrap>
            <Link to="/">
                <Button single>Go to trade page</Button>
            </Link>
        </ButtonWrap>
    </Wrap>
)
