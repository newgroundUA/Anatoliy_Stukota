import styled from 'styled-components'

const MyKeysWrap = styled.div`
    margin-bottom: 30px;
    cursor: default;
`

const Content = styled.div`
    max-width: ${({ full }) => (full ? '75rem' : '41.875rem')};
    padding-top: 1.5625rem;
    h1 {
        font-weight: 600;
        font-size: 1.875rem;
        color: #ffffff;
        letter-spacing: 0;
        margin-bottom: 1.875rem;
    }
    h2 {
        font-weight: 600;
        font-size: 1.125rem;
        color: #ffffff;
        padding-bottom: 0.875rem;
    }
`

export { MyKeysWrap, Content }
