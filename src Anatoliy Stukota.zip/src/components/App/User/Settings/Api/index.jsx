import React from 'react'
import { observer, inject } from 'mobx-react'
import { NoData } from 'common'
import { Table } from 'common/Table/styled'
import Message from 'i18n/Message'
import Item from './Item'
import { Content, MyKeysWrap } from './styled'
import { CellName, CellKey, CellActions } from './Item/styled'
import { FormView, FormViewModel } from './Form'

export default inject('app')(
    observer(({ app: { user: { apiKeys: { keys }, twoFaEnabled } } }) => (
        <Content full>
            <h1>
                <Message id="api.access" />
            </h1>
            <MyKeysWrap>
                <h2>
                    <Message id="api.myKeys" />
                </h2>
                {keys.length ? (
                    <Table main biggest>
                        <thead>
                            <tr>
                                {/* <CellDateTime>Date/Time</CellDateTime> */}
                                <CellName>
                                    <Message id="name" />
                                </CellName>
                                <CellKey>
                                    <Message id="key" />
                                </CellKey>
                                {/* <CellSecret>Secret</CellSecret> */}
                                <CellActions colSpan="2">
                                    <span>
                                        <Message id="actions" />
                                    </span>
                                </CellActions>
                            </tr>
                        </thead>
                        {keys.map(item => <Item key={item.id} item={item} twoFaEnabled={twoFaEnabled} />)}
                    </Table>
                ) : (
                    <NoData>
                        <Message id="noKeysHereYet" />
                    </NoData>
                )}
            </MyKeysWrap>
            <FormView form={new FormViewModel()} twoFaEnabled={twoFaEnabled} />
            <a href="https://api.coinsupply.com/docs/alpha" target="_blank" rel="noopener noreferrer">
                Check our API documentation
            </a>
        </Content>
    ))
)
