import Form, { validator } from '@utils/Form'
import { integer } from '@utils/Form/normalizers'
import { createApiKey } from '../../../../../../api/profile'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'keyName',
                value: ''
            },
            {
                name: 'authCode',
                value: '',
                normalize: integer
            }
        ]
    }

    validate = validator([
        {
            name: 'keyName',
            isRequired: false,
            minLength: 5,
            maxLength: 50
        },
        {
            name: 'authCode',
            test: (value, form) =>
                form.store.app.user.twoFaEnabled === true && (!value || value.toString().length !== 6)
                    ? 'enterOneTimeCode'
                    : ''
        }
    ])

    onSubmit = () => {
        const { keyName, authCode } = this.getValues()
        const validatedKeyName = keyName || 'Unnamed'
        const body = {
            keyName: validatedKeyName,
            authCode
        }
        return createApiKey(body)
    }

    onSubmitSuccess = () => {
        this.store.notifications.notify({
            title: 'success',
            message: 'checkEmailToConfirm'
        })
        this.clear()
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
    }
}
