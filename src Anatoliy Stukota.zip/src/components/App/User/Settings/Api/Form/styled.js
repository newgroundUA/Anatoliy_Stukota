import styled from 'styled-components'

const Form = styled.form`
    display: flex;
    margin-bottom: 2rem;
`

const Field = styled.div`
    flex: auto;
    padding-right: 1%;
`

const Actions = styled.div`
    width: 16.875rem;
    padding-left: 1.25rem;
    margin-top: 1.65rem;
`

const KeysPermissionContainer = styled.div`
    margin-bottom: 30px;
    > div {
        width: 33%;
    }
`

export { Text, Field, Actions, KeysPermissionContainer, Form }
