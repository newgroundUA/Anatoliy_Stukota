import React from 'react'
import { observer } from 'mobx-react'
import { Input, Button } from 'common'
import Message from 'i18n/Message'
import { Field, Actions, Form } from './styled'

export default observer(({ form, twoFaEnabled }) => (
    <Form onSubmit={form.handleSubmit}>
        <Field>
            <Input field={form.$('keyName')} label={<Message id="apiKeyName" />} />
        </Field>

        {twoFaEnabled && (
            <Field>
                <Input field={form.$('authCode')} label={<Message id="enter2FAToken" />} />
            </Field>
        )}

        <Actions>
            <Button fullWidth loading={form.submitting}>
                <Message id="createKey" />
            </Button>
        </Actions>
    </Form>
))
