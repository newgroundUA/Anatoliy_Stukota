export { default as FormViewDelete } from './View'
export { default as FormViewModelDelete } from './ViewModel'
