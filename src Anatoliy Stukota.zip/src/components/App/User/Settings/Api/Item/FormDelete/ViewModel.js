import Form, { validator } from '@utils/Form'

export default class ViewModel extends Form {
    constructor(props) {
        super(props)
        this.item = props
    }

    initFields() {
        return [
            {
                name: 'authCode',
                value: ''
            }
        ]
    }

    validate = validator([
        {
            name: 'authCode',
            test: (value, form) =>
                form.store.app.user.twoFaEnabled === true && (!value || value.toString().length !== 6)
                    ? 'enterOneTimeCode'
                    : ''
        }
    ])

    onSubmit = () => this.item.deactivate(this.getValues())

    onSubmitSuccess = () => {
        this.store.notifications.notify({
            title: 'success',
            message: 'keyDeleted'
        })
        this.clear()
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
    }
}
