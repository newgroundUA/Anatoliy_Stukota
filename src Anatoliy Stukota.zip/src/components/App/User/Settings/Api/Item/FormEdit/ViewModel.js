import Form, { isDottedIPv4 } from '@utils/Form'
import { validator } from '@utils/Form/validator'
import { integer } from '@utils/Form/normalizers'

export default class ViewModel extends Form {
    constructor(props) {
        super(props)
        this.item = props.item
    }

    initFields() {
        return [
            {
                name: 'restrictToIps',
                type: 'checkbox'
            },
            {
                name: 'tradingEnabled',
                type: 'checkbox'
            },
            {
                name: 'withdrawalEnabled',
                type: 'checkbox'
            },
            {
                name: 'authCode',
                value: '',
                normalize: integer
            },
            {
                name: 'id'
            },
            {
                name: 'ipAddresses'
            }
        ]
    }

    validate = validator([
        {
            name: 'authCode',
            test: (value, form) =>
                form.store.app.user.twoFaEnabled === true && (!value || value.toString().length !== 6)
                    ? 'enterOneTimeCode'
                    : ''
        },
        {
            name: 'ipAddresses',
            test: value => {
                if (!value) return ''
                if (value.indexOf(',', 7)) {
                    const splitted = value.split(',')
                    for (let i = 0; i < splitted.length; i++) {
                        if (!isDottedIPv4(splitted[i])) {
                            return 'pleaseEnterValidIPAddress'
                        }
                    }
                    return ''
                }
                return isDottedIPv4(value) ? '' : 'pleaseEnterValidIPAddress'
            }
        },
        {
            name: 'withdrawalEnabled',
            test: (value, form) =>
                value ? (form.$('restrictToIps').value ? '' : 'enableWithdrawalsOptionMustApplyTheIPFilter') : ''
        }
    ])

    onSubmit = () => this.item.changePermissions(this.getValues())

    onSubmitSuccess = () => {
        this.store.notifications.notify({
            title: 'success',
            message: 'keysPermissionsHasBeenSuccessfulyChanged'
        })
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
    }
}
