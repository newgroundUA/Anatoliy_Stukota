import React from 'react'
import { observer } from 'mobx-react'
import { Tooltip } from 'common'
import Message from 'i18n/Message'
import { Close, Row, CellName, CellKey, CellActions, Edit, Tbody } from './styled'
import { FormViewEdit, FormViewModelEdit } from './FormEdit'
import { FormViewDelete, FormViewModelDelete } from './FormDelete'
// import SecretStatus from './SecretStatus'
// import DateTime from './common'

@observer
export default class Item extends React.Component {
    state = {
        active: false,
        FAFieldActive: false
    }

    openPermissions = () => {
        this.setState({
            active: !this.state.active,
            FAFieldActive: false
        })
    }

    open2FA = () => {
        this.setState({
            active: false,
            FAFieldActive: !this.state.FAFieldActive
        })
    }

    render() {
        const { item, twoFaEnabled } = this.props
        const { active, FAFieldActive } = this.state

        return (
            <Tbody active={active}>
                <tr>
                    {/* <CellDateTime">
                        {item.expiresAt ? <DateTime time={item.expiresAt} /> : 'No expiration date'}
                    </CellDateTime> */}
                    <CellName>{item.name}</CellName>
                    <CellKey>{item.key}</CellKey>
                    {/* <CellSecret>
                        <SecretStatus value={item.secret} />
                    </CellSecret> */}
                    <CellActions>
                        <span>
                            <Tooltip inline text={<Message id="edit" />}>
                                <Edit name="deposit" onClick={this.openPermissions} />
                            </Tooltip>
                        </span>
                        <span>
                            <Tooltip inline text={<Message id="delete" />}>
                                <Close name="close" onClick={twoFaEnabled ? this.open2FA : () => item.deactivate()} />
                            </Tooltip>
                        </span>
                    </CellActions>
                </tr>

                {active && (
                    <Row>
                        <td colSpan="5">
                            <FormViewEdit
                                form={
                                    new FormViewModelEdit({
                                        initValues: {
                                            id: item.id,
                                            ipAddresses: item.ipAddresses || '',
                                            restrictToIps: item.restrictToIps,
                                            tradingEnabled: item.tradingEnabled,
                                            withdrawalEnabled: item.withdrawalEnabled
                                        },
                                        item
                                    })
                                }
                                twoFaEnabled={twoFaEnabled}
                            />
                        </td>
                    </Row>
                )}

                {FAFieldActive && (
                    <Row>
                        <td colSpan="5">
                            <FormViewDelete form={new FormViewModelDelete(item)} />
                        </td>
                    </Row>
                )}
            </Tbody>
        )
    }
}
