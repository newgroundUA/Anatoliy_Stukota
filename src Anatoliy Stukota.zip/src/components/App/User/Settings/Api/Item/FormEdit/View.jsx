import React from 'react'
import { observer } from 'mobx-react'
import { Checkbox, Button, Input } from 'common'
import { KeysPermissionWrap, Form } from '../styled'

@observer
export default class View extends React.Component {
    render() {
        const { twoFaEnabled, form } = this.props
        return (
            <Form onSubmit={form.handleSubmit}>
                <KeysPermissionWrap>
                    <Checkbox field={form.$('restrictToIps')} label="Restrict access to trusted IPs only" inline />
                    <Checkbox field={form.$('tradingEnabled')} label="Enable Trading" inline />
                    {/* <Checkbox field={form.$('withdrawalEnabled')} label="Enabel Withdrawals" inline /> */}
                    <Button type="submit" single>
                        Save
                    </Button>
                </KeysPermissionWrap>
                {twoFaEnabled && <Input field={form.$('authCode')} label="Enter 2FAToken" />}
                {form.$('restrictToIps').value && (
                    <React.Fragment>
                        <Input field={form.$('ipAddresses')} label="Trusted IPs:" placeholder="0.0.0.0" />
                        <span>If entering multiple IPs, separate using commas</span>
                    </React.Fragment>
                )}
            </Form>
        )
    }
}
