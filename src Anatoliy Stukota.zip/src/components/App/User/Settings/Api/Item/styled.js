import styled from 'styled-components'
import is from 'styled-is'
import { Icon } from 'common'

const Close = styled(Icon)`
    color: #808f92;
    cursor: pointer;
    transition: all 0.3s;
    &:hover {
        color: #fff;
        transition: all 0.3s;
    }
`

const Edit = styled(Icon)`
    cursor: pointer;
    &:hover {
        color: #fff;
        transition: all 0.3s;
    }
`

const Row = styled.tr`
    span {
        font-size: 0.625rem;
        color: #808f92;
    }
`

const KeysPermissionWrap = styled.div`
    display: flex;
    align-items: flex-start;
    > div {
        display: inline-block;
        width: 30%;
    }
`

const Form = styled.form`
    padding: 0.5rem;
`

const CellName = styled.td`
    width: 15%;
    text-align: left;
`

const CellKey = styled.td`
    width: 20%;
    text-align: left !important;
`

const CellSecret = styled.td`
    width: 10%;
    text-align: left;
    text-transform: capitalize;
`

const CellDateTime = styled.td`
    width: 20%;
`

const CellActions = styled.td`
    width: 5%;
    span {
        margin-right: 0.5rem;
    }
`

const Tbody = styled.tbody`
    ${is('active')`
        background-color: #1b2335;
    `};
`

export { Close, Row, KeysPermissionWrap, Form, CellName, CellKey, CellSecret, CellDateTime, CellActions, Edit, Tbody }
