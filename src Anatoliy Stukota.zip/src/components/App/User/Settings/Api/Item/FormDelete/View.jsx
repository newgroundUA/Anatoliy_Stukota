import React from 'react'
import { observer } from 'mobx-react'
import { Input, Button } from 'common'
import Message from 'i18n/Message'
import { Field, Actions, Form } from './styled'

export default observer(({ form }) => (
    <Form onSubmit={form.handleSubmit}>
        <Field>
            <Input field={form.$('authCode')} label={<Message id="enter2FA" />} />
        </Field>

        <Actions>
            <Button fullWidth loading={form.submitting}>
                <Message id="deleteKey" />
            </Button>
        </Actions>
    </Form>
))
