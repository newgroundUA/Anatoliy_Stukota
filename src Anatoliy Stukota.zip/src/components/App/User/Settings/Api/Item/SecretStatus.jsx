import React from 'react'
import { Icon } from 'common'

const SecretStatus = value => (
    <React.Fragment>
        <Icon name="wallet" style={{ marginRight: '5px', color: '#02E866' }} />
        {value.value}
    </React.Fragment>
)

export default SecretStatus
