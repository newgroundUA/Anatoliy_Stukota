import styled from 'styled-components'

const Form = styled.form`
    padding: 0.5rem;
    display: flex;
    margin-bottom: 2rem;
`

const Field = styled.div`
    flex: auto;
    padding-right: 0.5rem;
`

const Actions = styled.div`
    width: 16.875rem;
    padding-left: 1.25rem;
    margin-top: 1.65rem;
`

export { Field, Actions, Form }
