import React from 'react'
import { Content } from '../../styled'

export default () => <Content extraSmall>Logs</Content>
