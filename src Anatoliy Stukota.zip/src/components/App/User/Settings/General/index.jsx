import React from 'react'
import { Flex } from 'common'
import { inject } from 'mobx-react'
import { Content } from '../../styled'
import { Col, InputName, Button, Text, Info, Status, Block, Line, Level, ProgressBar } from './styled'
import Icon from './icon/level.svg'
import IconArrow from './icon/arrow.svg'

export default inject('app')(({ app: { user } }) => {
    const { login } = user

    return (
        <Content full>
            <Col big>
                <h1>Fees and Limits</h1>
                <Block>
                    <Line>
                        <Text>Est. Total account value</Text>
                    </Line>
                    <Line>
                        <Info>
                            234.14323598 BTC <span>/ 252434.14 USD</span>
                        </Info>
                    </Line>
                    <Line>
                        <Button>Activity Log</Button>
                    </Line>
                </Block>

                <Block>
                    <Line>
                        <Text>Est. Total account value</Text>
                    </Line>
                    <Line>
                        <Info>
                            234.14323598 BTC <span>/ 252434.14 USD</span>
                        </Info>
                    </Line>
                    <Line level>
                        <Flex between>
                            <Flex center>
                                <Info> 0.08%</Info>
                                <Level silver>
                                    <Icon />Silver Level
                                </Level>
                            </Flex>
                            <Flex center>
                                <IconArrow />
                                <Level silver>
                                    <Icon />Silver Level
                                </Level>
                                <Info>0.08%</Info>
                            </Flex>
                        </Flex>
                        <ProgressBar width="50" />
                        <Flex between>
                            <Text>Current fee level </Text>
                            <Text>$0.29384 left</Text>
                        </Flex>
                    </Line>
                </Block>
            </Col>

            <Col small>
                <h1>Account overview</h1>
                <Block>
                    <Line>
                        <InputName value={`${login}`} />
                        <Button>Change</Button>
                    </Line>
                    <Line>
                        <Text>
                            Verification status:<Status>Verified</Status>
                        </Text>
                    </Line>
                </Block>

                <Block security>
                    <Text>Security Status</Text> <br />
                    <Info>Basic protection</Info> <br />
                    <Button>Activate 2FA for Full Protection</Button>
                </Block>
                <Line>
                    <Text>Last login</Text>
                </Line>
                <Line>
                    <Text>IP 37.17.31.92, Location Belarus, Time stamp 13.08</Text>
                </Line>
                <Line>
                    <Button>Activity Log</Button>
                </Line>
            </Col>
        </Content>
    )
})
