import styled from 'styled-components'
import is from 'styled-is'

const Col = styled.div`
    ${is('small')`
    width: 22.5rem;
    padding-right: 9.375rem;
`} ${is('big')`
    float: right;
    width: 36.625rem;
`};
`

const InputName = styled.input`
    font-size: 1.125rem;
    color: #ffffff;
    font-family: inherit;
    background-color: transparent;
    border: none;
    padding-right: 1.125rem;
`

const Button = styled.button`
    font-size: 0.875rem;
    color: #4a90e2;
    background-color: transparent;
    font-family: inherit;
    border: none;
    cursor: pointer;
    padding: 0;
`

const Text = styled.span`
    font-size: 0.875rem;
    color: #808f92;
`

const Info = styled.span`
    font-size: 1.125rem;
    color: #ffffff;
`

const Status = styled.span`
    color: #00bd52;
    padding-left: 0.4375rem;
`

const Line = styled.div`
    padding-bottom: 0.625rem;
    ${is('level')`
        padding-top: 1.125rem;
        padding-bottom: 1.5625rem;
    `};
`

const Block = styled.div`
    padding-bottom: 3.125rem;
`

const Level = styled.div`
    margin: 0 1.25rem;
    ${is('silver')`
    
    `} svg {
        vertical-align: bottom;
        padding-right: 0.4375rem;
    }
`

const ProgressBar = styled.div`
    margin-top: 0.8125rem;
    margin-bottom: 0.875rem;
    height: 0.375rem;
    content: '';
    display: block;
    background-color: #6a7380;
    position: relative;
    &:before {
        position: absolute;
        top: 0;
        left: 0;
        display: block;
        content: '';
        height: 0.375rem;
        width: ${({ width }) => width}%;
        background-image: linear-gradient(90deg, #2a3344 0, #02e866 100%);
    }
`

export { Col, InputName, Button, Text, Info, Status, Block, Line, Level, ProgressBar }
