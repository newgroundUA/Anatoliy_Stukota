import React from 'react'
import { renderRoutes } from 'react-router-config'
import { Tab, Tabs } from 'common/Tabs'
import { inject } from 'mobx-react'
import styled from 'styled-components'

const Wrap = styled.div`
    padding-left: 4.375rem;
    padding-top: 0.625rem;
`

@inject('router')
export default class index extends React.Component {
    handleClick = e => {
        this.props.router.push(e)
    }

    render() {
        const {
            route,
            location: { pathname }
        } = this.props
        return (
            <Wrap>
                <Tabs active={pathname}>
                    {/* <Tab label="General" onClick={this.handleClick} value="/user/settings/general" /> */}
                    <Tab label="Profile and security" onClick={this.handleClick} value="/user/settings/profile" />
                    <Tab label="API Access" onClick={this.handleClick} value="/user/settings/api" />
                    {/* <Tab label="Activity log" onClick={this.handleClick} value="/user/settings/activity-log" /> */}
                </Tabs>
                {renderRoutes(route.routes)}
            </Wrap>
        )
    }
}
