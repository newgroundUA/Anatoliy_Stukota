import React from 'react'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Form'
import ModalSuccess from './ModalSuccess'
import { Wrap } from '../styled'

export default inject('app')(({ app: { user: { twoFaEnabled } } }) => (
    <Wrap>
        <h2>
            <Message id="changePassword" />
        </h2>
        <FormView form={new FormViewModel()} twoFaEnabled={twoFaEnabled} />
        <ModalSuccess />
    </Wrap>
))
