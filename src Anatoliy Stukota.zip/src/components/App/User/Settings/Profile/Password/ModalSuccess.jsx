import React from 'react'
import { inject, observer } from 'mobx-react'
import { Icon } from 'common/SecondaryLayout'
import { Wrap, Button } from 'common/Modal'
import { ButtonWrap } from 'common'
import Modal from 'react-modal'
import Message from 'i18n/Message'

export default inject('modals')(
    observer(({ modals }) => {
        const { opened, close } = modals.get('passwordSuccess')

        return (
            <Modal isOpen={opened} onRequestClose={close}>
                <Wrap>
                    <Icon name="mail" />
                    <h2>
                        <Message id="checkEmail" />
                    </h2>
                    <p>
                        <Message id="WeHaveSendYouAnEmail" /> <br />
                        <Message id="pleaseFollowTheLinkToConfirm" />
                    </p>
                    <ButtonWrap>
                        <Button single onClick={close}>
                            Ok
                        </Button>
                    </ButtonWrap>
                </Wrap>
            </Modal>
        )
    })
)
