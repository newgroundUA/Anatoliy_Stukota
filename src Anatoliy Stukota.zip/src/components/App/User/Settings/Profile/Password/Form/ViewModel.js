import Form from '@utils/Form/index'
import { validator, passwordStrength } from '@utils/Form/validator'
import { changePassword } from '../../../../../../../api/profile'

export default class ChangePassword extends Form {
    initFields() {
        return [
            {
                name: 'oldPassword',
                label: 'Current Password',
                type: 'password',
                value: ''
            },
            {
                name: 'newPassword',
                label: 'New Password',
                type: 'password',
                value: ''
            },
            {
                name: 'newPasswordConfirm',
                label: 'Repeat New Password',
                type: 'password',
                value: ''
            },
            {
                name: 'authCode',
                label: 'Enter 2FA code from the app',
                value: ''
            }
        ]
    }

    validate = validator([
        {
            name: 'oldPassword',
            isRequired: true,
            minLength: 9,
            maxLength: 50
        },
        {
            name: 'newPassword',
            isRequired: true,
            minLength: 9,
            maxLength: 50,
            test: passwordStrength
        },
        {
            name: 'newPasswordConfirm',
            isRequired: true,
            minLength: 9,
            maxLength: 50,
            test: (value, form) => (value !== form.fields.newPassword.value ? 'passwordsDontMatch' : '')
        },
        {
            name: 'authCode',
            test: (value, form) =>
                form.store.app.user.twoFaEnabled === true && (!value || value.toString().length !== 6)
                    ? 'enterOneTimeCode'
                    : ''
        }
    ])

    onSubmit = () => changePassword(this.getValues())

    onSubmitSuccess = () => {
        this.store.modals.get('passwordSuccess').open()
        this.clear()
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
        this.set('error', errorCode)
    }
}
