import React from 'react'
import { observer } from 'mobx-react'
import { Input, ButtonWrap } from 'common'
import Message from 'i18n/Message'
import { Button, Error } from '../../styled'

export default observer(({ form, twoFaEnabled }) => (
    <form onSubmit={form.handleSubmit}>
        <Input primary label={<Message id="currentPassword" />} field={form.$('oldPassword')} />
        <Input primary label={<Message id="newPassword" />} field={form.$('newPassword')} />
        <Input primary label={<Message id="repeatNewPassword" />} field={form.$('newPasswordConfirm')} />
        {twoFaEnabled && <Input primary label={<Message id="enter2FACodeFromTheApp" />} field={form.$('authCode')} />}
        {form.error && (
            <Error>
                <Message id={form.error} />
            </Error>
        )}
        <ButtonWrap left>
            <Button fullWidth type="submit" loading={form.submitting}>
                <Message id="changePassword" />
            </Button>
        </ButtonWrap>
    </form>
))
