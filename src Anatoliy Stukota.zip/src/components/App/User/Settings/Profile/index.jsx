import React from 'react'
import Message from 'i18n/Message'
import Password from './Password'
import Email from './Email'
import TwoFactorAuthentication from './TwoFactorAuthentication'
import { Content } from '../../styled'

export default () => (
    <Content full>
        <h1>
            <Message id="profileSettings" />
        </h1>
        <Password />
        <Email />
        <TwoFactorAuthentication />
    </Content>
)
