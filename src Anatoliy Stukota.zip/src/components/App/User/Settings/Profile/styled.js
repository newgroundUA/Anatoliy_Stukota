import styled from 'styled-components'
import { Button as _Button } from 'common'
import is from 'styled-is'

const Wrap = styled.div`
    width: 25rem;
    margin-right: 9.6875rem;
    display: inline-block;
    margin-bottom: 6.25rem;
    vertical-align: top;
    ${is('twoFA')`
        width: 32.875rem;
        margin-right: 0;
    `};
`

const Button = styled(_Button)`
    max-width: 70%;
`

const Error = styled.span`
    color: #ff4a68;
`

const Text = styled.p`
    padding-bottom: 1em;
`

const Status = styled.p`
    font-size: 0.875rem;
    color: #808f92;
    margin-bottom: 1rem;

    span {
        display: inline-block;
        color: ${({ active }) => (active ? '#02e866' : '#ff4a68')};
        padding-left: 0.5rem;
    }
`

export { Wrap, Button, Text, Status, Error }
