import React from 'react'
import { inject, observer } from 'mobx-react'
import { FormView } from '../../../../../Register/TwoFactorAuthentication/Form'
import Steps from '../../../../../Register/TwoFactorAuthentication/Steps'
import FormViewModel from './Form/ViewModel'
import ModalSuccessEnable from './ModalSuccessEnable'

export default inject('app')(
    observer(({ app: { twoFaSecret } }) => (
        <React.Fragment>
            <Steps twoFaSecret={twoFaSecret}>
                <FormView form={new FormViewModel()} twoFaSecret={twoFaSecret} />
            </Steps>
            <ModalSuccessEnable />
        </React.Fragment>
    ))
)
