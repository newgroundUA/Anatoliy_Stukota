import React from 'react'
import { Input, Button, ButtonWrap } from 'common'
import { observer } from 'mobx-react'
import Message from 'i18n/Message'

export default observer(({ form }) => (
    <form onSubmit={form.handleSubmit}>
        <Input label={<Message id="enter2FAToken" />} field={form.$('authCode')} />
        <ButtonWrap left>
            <Button fullWidth loading={form.submitting}>
                <Message id="disable" />
            </Button>
        </ButtonWrap>
    </form>
))
