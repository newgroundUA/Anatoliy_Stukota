import Form from '@utils/Form/index'
import { validator } from '@utils/Form/validator'
import { disableTwoFa } from '../../../../../../../../api/profile'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'authCode',
                type: 'text'
            }
        ]
    }

    validate = validator([
        {
            name: 'authCode',
            isRequired: true,
            minLength: 6,
            maxLength: 6
        }
    ])

    onSubmit = () => disableTwoFa(this.getValues())

    onSubmitSuccess = () => {
        this.store.modals.get('2faDisableConfirm').open()
        this.clear()
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.store.notifications.notify({
            title: 'fail',
            message: errorCode
        })
        this.set('error', errorCode)
    }
}
