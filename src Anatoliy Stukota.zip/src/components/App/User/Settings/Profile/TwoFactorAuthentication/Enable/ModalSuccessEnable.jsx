import React from 'react'
import Modal from 'react-modal'
import { inject, observer } from 'mobx-react'
import { ButtonWrap } from 'common'
import { Wrap, Button } from 'common/Modal'
import { Icon } from 'common/SecondaryLayout'
import Message from 'i18n/Message'

export default inject('modals')(
    observer(({ modals }) => {
        const { opened, close } = modals.get('2faEnableConfirm')
        return (
            <Modal isOpen={opened} onRequestClose={close}>
                <Wrap>
                    <Icon name="mail" />
                    <h2>
                        <Message id="checkEmail" />
                    </h2>
                    <p>
                        <Message id="toConfirmEnablingOfTwoFactorAuthentication" /> <br />
                        <Message id="pleaseCheckYourEmailAndFollowTheLinkWeSentYou" />
                    </p>
                    <ButtonWrap>
                        <Button single onClick={close}>
                            Ok
                        </Button>
                    </ButtonWrap>
                </Wrap>
            </Modal>
        )
    })
)
