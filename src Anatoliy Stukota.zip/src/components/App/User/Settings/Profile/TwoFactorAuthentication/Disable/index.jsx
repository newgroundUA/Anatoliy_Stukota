import React from 'react'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Form'
import ModalSuccessDisable from './ModalSuccessDisable'
import { Text, Form } from './styled'

export default () => (
    <React.Fragment>
        <Text>
            <Message id="yourAccountIsSecure" />
        </Text>
        <Text>
            <Message id="twoFactorAuthentificationIsEnabled" /> <br />
            <Message id="toDisableItPleaseEnterCurrent2FAToken" />
        </Text>
        <Text>
            <Message id="weHighlyDONOTRecommendToDisable2FA" />
        </Text>
        <Form>
            <FormView form={new FormViewModel()} />
        </Form>
        <ModalSuccessDisable />
    </React.Fragment>
)
