import styled from 'styled-components'

const Text = styled.p`
    padding-bottom: 1em;
`
const Form = styled.div`
    max-width: 25rem;
    button {
        max-width: 70%;
    }
`
export { Text, Form }
