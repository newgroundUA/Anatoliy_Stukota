import React from 'react'
import Modal from 'react-modal'
import { inject, observer } from 'mobx-react'
import { Icon } from 'common/SecondaryLayout'
import { Wrap, Button } from 'common/Modal'
import { ButtonWrap } from 'common'
import Message from 'i18n/Message'

export default inject('modals')(
    observer(({ modals }) => {
        const { opened, close } = modals.get('2faDisableConfirm')
        return (
            <Modal isOpen={opened} onRequestClose={close}>
                <Wrap>
                    <Icon name="mail" />
                    <h2>
                        <Message id="checkEmail" />
                    </h2>
                    <p>
                        <Message id="toConfirmDisablingOfTwoFactorAuthentication" /> <br />
                        <Message id="pleaseCheckYourEmailAndFollowTheLinkWeSentYou" />
                    </p>
                    <ButtonWrap>
                        <Button single onClick={close}>
                            Ok
                        </Button>
                    </ButtonWrap>
                </Wrap>
            </Modal>
        )
    })
)
