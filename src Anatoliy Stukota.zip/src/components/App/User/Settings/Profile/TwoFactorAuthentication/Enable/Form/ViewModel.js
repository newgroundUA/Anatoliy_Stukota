import Form from '@utils/Form/index'
import { validator } from '@utils/Form/validator'
import { integer } from '@utils/Form/normalizers'
import { enableTwoFa } from '../../../../../../../../api/profile'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'authCode',
                normalize: integer,
                value: ''
            },
            {
                name: 'signup',
                value: false
            }
        ]
    }

    validate = validator([
        {
            name: 'authCode',
            isRequired: true,
            minLength: 6,
            maxLength: 6
        }
    ])

    onSubmit = () => enableTwoFa(this.getValues())

    onSubmitSuccess = () => {
        this.store.modals.get('2faEnableConfirm').open()
        this.clear()
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.set('error', errorCode)
        this.store.notifications.notify({
            title: 'failWhileEnabling2FA',
            message: errorCode
        })
    }
}
