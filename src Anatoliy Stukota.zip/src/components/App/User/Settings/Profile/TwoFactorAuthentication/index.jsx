import React from 'react'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'
import Disable from './Disable'
import Enable from './Enable'
import { Wrap, Status } from '../styled'

@inject('app')
export default class TwoFactorAuthentication extends React.Component {
    componentDidMount = () => {
        if (window.location.hash === '#2fa') window.scrollTo(0, this.ref.getBoundingClientRect().top)
    }

    render() {
        const {
            app: {
                user: { twoFaEnabled }
            }
        } = this.props

        return (
            <Wrap twoFA>
                <h2
                    ref={node => {
                        this.ref = node
                    }}
                >
                    <Message id="twoFactorAuthentication" />
                </h2>
                <Status active={twoFaEnabled}>
                    <Message id="status" />:
                    <span>{twoFaEnabled ? 'Active' : 'Inactive'}</span>
                </Status>
                {twoFaEnabled ? <Disable /> : <Enable />}
            </Wrap>
        )
    }
}
