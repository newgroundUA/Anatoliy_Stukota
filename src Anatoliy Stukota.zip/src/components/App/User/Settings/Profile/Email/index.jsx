import React from 'react'
import { inject } from 'mobx-react'
import { Input, ButtonWrap } from 'common'
import Message from 'i18n/Message'
import { Wrap, Button } from '../styled'

export default inject('app')(({ app: { user: { login } } }) => (
    <Wrap>
        <h2>
            <Message id="requestEmailChange" />
        </h2>
        <Input primary value={login} disabled label={<Message id="email" />} />
        <ButtonWrap left>
            <Button fullWidth disabled>
                <Message id="requestEmailChange" />
            </Button>
        </ButtonWrap>
    </Wrap>
))
