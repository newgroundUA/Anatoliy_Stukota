import React from 'react'
import { renderRoutes } from 'react-router-config'
import { Tab, Tabs } from 'common/Tabs'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'
import { Wrap } from './styled'

@inject('router', 'app')
export default class index extends React.Component {
    handleClick = e => {
        this.props.router.push(e)
    }

    render() {
        const {
            route,
            location: { pathname }
        } = this.props
        return (
            <Wrap>
                <Tabs active={pathname}>
                    <Tab
                        label={<Message id="balancesDepositsWithdrawals" />}
                        onClick={this.handleClick}
                        value="/user/funds/balances"
                    />
                    <Tab
                        label={<Message id="orderHistory" />}
                        onClick={this.handleClick}
                        value="/user/funds/order-history"
                    />
                    <Tab
                        label={<Message id="myOpenOrders" />}
                        onClick={this.handleClick}
                        value="/user/funds/open-orders"
                    />
                    <Tab
                        label={<Message id="myTransactionsHistory" />}
                        onClick={this.handleClick}
                        value="/user/funds/transaction-history"
                    />
                    <Tab
                        label={<Message id="feesAndLimits" />}
                        onClick={this.handleClick}
                        value="/user/funds/fees-limits"
                    />
                </Tabs>
                {renderRoutes(route.routes)}
            </Wrap>
        )
    }
}
