import styled from 'styled-components'
import { Icon } from 'common'

const StyledIcon = styled(Icon)`
    cursor: pointer;
`

export { StyledIcon }
