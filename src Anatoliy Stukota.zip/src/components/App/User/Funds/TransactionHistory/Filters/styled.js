import styled from 'styled-components'

const Field = styled.div`
    max-width: 10.625rem;
    width: 100%;
    display: block;
`
const Fields = styled.div`
    display: flex;
    width: 43.75rem;
    justify-content: space-between;
    float: right;
    margin-top: 0.3125rem;
    &:after {
        display: table;
        content: '';
        clear: both;
    }
`

export { Field, Fields }
