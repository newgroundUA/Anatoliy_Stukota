import Form from '@utils/Form'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'currency',
                value: null
            },
            {
                name: 'type',
                value: null
            },
            {
                name: 'fromMs',
                value: undefined
            },
            {
                name: 'beforeMs',
                value: undefined
            }
        ]
    }

    onChange = () => {
        this.store.app.user.transactionHistory.fetch(this.getValues())
    }
}
