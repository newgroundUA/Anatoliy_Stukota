import React from 'react'
import { inject } from 'mobx-react'
import { Select, DayPickerRange } from 'common/FormElements'
import Message from 'i18n/Message'
import { Field, Fields } from './styled'

export default inject('app')(({ app: { currencies }, form }) => {
    const $currencies = [
        {
            value: null,
            children: 'All'
        }
    ].concat(
        currencies.map(item => ({
            value: item.code,
            children: item.code
        }))
    )

    const $types = [
        {
            children: 'All',
            value: null
        },
        {
            children: 'Deposit',
            value: 'Deposit'
        },
        {
            children: 'Withdrawal',
            value: 'Withdrawal'
        }
    ]

    return (
        <form onSubmit={form.onSubmit}>
            <Fields>
                <Field>
                    <Select data={$currencies} field={form.$('currency')} placeholder={<Message id="currency" />} />
                </Field>
                <Field>
                    <Select data={$types} field={form.$('type')} placeholder={<Message id="type" />} />
                </Field>
                <DayPickerRange dateFrom={form.$('fromMs')} dateTo={form.$('beforeMs')} />
            </Fields>
        </form>
    )
})
