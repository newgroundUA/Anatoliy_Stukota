import React from 'react'
import { StyledIcon } from './styled'

export default ({ data }) =>
    data.status === 'PENDING' && data.type === 'Withdrawal' && <StyledIcon name="close" onClick={data.handleCancel} />
