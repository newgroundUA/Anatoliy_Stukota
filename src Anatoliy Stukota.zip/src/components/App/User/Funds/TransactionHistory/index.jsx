import React from 'react'
import { inject } from 'mobx-react'
import { emitter } from '@utils'
import Message from 'i18n/Message'
import { FormViewModel, FormView } from './Filters'
import Items from './Items'
import { Content } from '../styled'

@inject('app')
export default class Transactions extends React.Component {
    constructor(props) {
        super(props)
        this.filters = new FormViewModel()
        this.removeListener = emitter.on('@transactionHistory/clearFilters', () => {
            this.filters.clear()
        })
    }

    componentWillUnmount = () => {
        this.removeListener()
    }

    render() {
        const { transactionHistory } = this.props.app.user
        return (
            <Content full>
                <h1>
                    <Message id="myTransactionsHistory" />
                </h1>
                <FormView form={this.filters} />
                <Items transactionHistory={transactionHistory} />
            </Content>
        )
    }
}
