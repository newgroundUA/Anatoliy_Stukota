import React from 'react'
import { observer } from 'mobx-react'
import { Table, Paginate, DateTime } from 'common'
import Message from 'i18n/Message'
import Actions from './Actions'

const columns = [
    {
        title: <Message id="transactionID" />,
        data: '$id',
        style: { width: '9%' }
    },
    {
        title: <Message id="date" />,
        data: 'createdAt',
        style: { width: '20%' },
        render: value => <DateTime time={value} />
    },
    {
        title: <Message id="type" />,
        data: 'type'
    },
    {
        title: <Message id="currency" />,
        data: 'currency'
    },

    {
        title: <Message id="amount" />,
        data: 'amount'
    },
    {
        title: <Message id="status" />,
        data: 'status'
    },
    {
        title: <Message id="actions" />,
        key: 'actions',
        render: (value, item) => <Actions data={item} />
    }
]

export default observer(({ transactionHistory }) => (
    <React.Fragment>
        <Table
            main
            biggest
            data={transactionHistory.items}
            columns={columns}
            loading={transactionHistory.isLoading}
            rowKey="$id"
        />
        {transactionHistory.countPages > 1 && (
            <Paginate
                pageCount={transactionHistory.countPages}
                onPageChange={transactionHistory.changePage}
                forcePage={transactionHistory.page}
            />
        )}
    </React.Fragment>
))
