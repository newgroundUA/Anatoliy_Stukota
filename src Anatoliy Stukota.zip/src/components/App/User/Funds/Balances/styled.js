import styled from 'styled-components'

const ProgressWrap = styled.div`
    width: 31.25rem;
    padding-top: 2.5rem;
    padding-bottom: 0.625rem;
`
const Text = styled.div`
    font-size: 0.875rem;
    color: #808f92;
    a {
        color: #4a90e2;
    }
`

export { ProgressWrap, Text }
