import React from 'react'
import { Link } from 'react-router-dom'
import { inject, observer } from 'mobx-react'
import { Input, Icon } from 'common'
import Message from 'i18n/Message'
import { Field, ActionButton, Tips, Warning } from './styled'

@inject('app')
@observer
export default class Deposit extends React.Component {
    componentDidMount = () => {
        const { item } = this.props

        if (item.wallet.walletAddress === '') {
            item.wallet.refresh()
        }
    }

    copyToClipboard = () => {
        this.input.select()
        document.execCommand('Copy')
    }

    render() {
        const { item } = this.props
        const { walletAddress: address } = item.wallet
        return (
            <React.Fragment>
                {address === null && (
                    <Warning>
                        <Message id="noteTheWalletIsNowCreating" />
                    </Warning>
                )}

                <Field>
                    <Input
                        style={{ maxWidth: '43.75rem' }}
                        value={address || ''}
                        label={<Message id="yourCurrencyDepositAddress" data={{ currency: item.currency.name }} />}
                        innerRef={node => {
                            this.input = node
                        }}
                        readOnly
                    />
                    <ActionButton secondary onClick={this.copyToClipboard}>
                        <Icon name="copy" />
                    </ActionButton>
                    <ActionButton isLoading={item.wallet.isLoading} secondary refresh onClick={item.wallet.refresh}>
                        <Icon name="refresh" />
                    </ActionButton>
                </Field>
                <Tips>
                    <Message id="afterMakingADepositYouCanTrackIt" />{' '}
                    <Link to="/user/funds/transaction-history">
                        <Message id="myTransactionsHistory" />
                    </Link>{' '}
                    <Message id="tab" />
                </Tips>
            </React.Fragment>
        )
    }
}
