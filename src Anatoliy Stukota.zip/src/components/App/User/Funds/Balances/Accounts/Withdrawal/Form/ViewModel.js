import Form, { validator } from '@utils/Form'
import { number, integer } from '@utils/Form/normalizers'
import { withdrawal } from '../../../../../../../../api/funds'

export default class ViewModel extends Form {
    constructor(currency) {
        super()
        this.currency = currency
    }

    initFields() {
        return [
            {
                name: 'amount',
                value: '',
                normalize: number
            },
            {
                name: 'authCode',
                value: '',
                normalize: integer
            },
            {
                name: 'destination',
                value: ''
            }
        ]
    }

    validate = validator([
        {
            name: 'amount',
            isRequired: true,
            test: value => {
                if (this.currency && value > this.currency.withdrawalMaxAmount)
                    return `Maximum withdrawal amount is ${this.currency.withdrawalMaxAmount}`

                if (value > this.currency.account.balance) return 'withdrawalAmountCanNotBeMoreThanYouHave'

                if (value < this.currency.withdrawalMinAmount)
                    return `Minimum withdrawal amount is ${this.currency.withdrawalMinAmount}`

                return ''
            }
        },
        {
            name: 'destination',
            isRequired: true
        },
        {
            name: 'authCode',
            test: (value, form) =>
                form.store.app.user.twoFaEnabled === true && (!value || value.toString().length !== 6)
                    ? 'enterOneTimeCode'
                    : ''
        }
    ])

    onSubmit = () =>
        withdrawal({
            ...this.getValues(),
            currency: this.currency.code
        })

    onSubmitSuccess = () => {
        this.store.notifications.notify({
            title: 'withdrawal',
            message: 'success'
        })
    }

    onSubmitFail = ({ error: { errorCode } }) => {
        this.store.notifications.notify({
            title: 'withdrawal',
            message: `Fail ${errorCode}`
        })
    }
}
