import React from 'react'
import { observer, inject } from 'mobx-react'
import { Icon, Tabs } from 'common'
import Message from 'i18n/Message'
import Deposit from './Deposit'
import Withdrawal from './Withdrawal'
import { Line, HideLine, Tab } from './styled'

@inject('app')
@observer
export default class Item extends React.Component {
    state = {
        active: null
    }

    handleClickDeposit = () => {
        this.setState({
            active: this.state.active === 'deposit' ? null : 'deposit'
        })
    }

    handleClickWithdrawal = () => {
        this.setState({
            active: this.state.active === 'withdrawal' ? null : 'withdrawal'
        })
    }

    render() {
        const {
            item,
            app: {
                features: { isDepositsEnabled, isWithdrawalsEnabled }
            }
        } = this.props
        return (
            <Line active={this.state.active}>
                <tr>
                    <td>{item.currency.code}</td>
                    <td>{item.currency.name}</td>
                    <td>{item.balance}</td>
                    <td>{item.ordersBalance}</td>
                    <td>
                        <Tabs border={false} active={this.state.active}>
                            {isDepositsEnabled &&
                                item.currency.isDepositEnabled && (
                                    <Tab
                                        onClick={this.handleClickDeposit}
                                        label={
                                            <React.Fragment>
                                                <Icon name="deposit" /> <Message id="deposit" />
                                            </React.Fragment>
                                        }
                                        value="deposit"
                                    />
                                )}

                            {isWithdrawalsEnabled &&
                                item.currency.isWithdrawalEnabled && (
                                    <Tab
                                        onClick={this.handleClickWithdrawal}
                                        label={
                                            <React.Fragment>
                                                <Icon name="withdraw" /> <Message id="withdrawal" />
                                            </React.Fragment>
                                        }
                                        value="withdrawal"
                                    />
                                )}
                        </Tabs>
                    </td>
                </tr>
                {this.state.active && (
                    <tr>
                        <HideLine colSpan="5">
                            {this.state.active === 'deposit' && <Deposit item={item} />}
                            {this.state.active === 'withdrawal' && <Withdrawal item={item} />}
                        </HideLine>
                    </tr>
                )}
            </Line>
        )
    }
}
