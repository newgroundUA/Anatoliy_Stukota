import React from 'react'
import { inject, observer } from 'mobx-react'
import { Link } from 'react-router-dom'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Form'
import { Text } from './styled'

export default inject('app')(
    observer(props => {
        const {
            app: {
                user: { twoFaEnabled }
            },
            item
        } = props
        return (
            <React.Fragment>
                <Text>
                    <Message id="youHave" />{' '}
                    <b>
                        {item.balance} {item.currency.name}
                    </b>{' '}
                    <Message id="availableForWithdrawal" />
                    <b>
                        {' '}
                        {item.ordersBalance} {item.currency.name}{' '}
                    </b>
                    <Message id="isHold" />{' '}
                    <Link to="/user/funds/open-orders">
                        <Message id="onOrders" />
                    </Link>
                </Text>
                <FormView form={new FormViewModel(item.currency)} twoFaEnabled={twoFaEnabled} />
            </React.Fragment>
        )
    })
)
