import React from 'react'
import { observer } from 'mobx-react'
import { Input, Checkbox, Icon } from 'common'
import Message from 'i18n/Message'
import { InputSearch, FilterWrap as Wrap } from './styled'

@observer
export default class Filters extends React.Component {
    render() {
        const { model } = this.props
        return (
            <Wrap>
                <InputSearch>
                    <Icon name="search" />
                    <Input value={model.searchField} onChange={model.handleChangeSearchField} />
                </InputSearch>
                <Checkbox
                    checked={model.hideEmptyAccounts}
                    onChange={model.handleHideEmptyAccountsCheck}
                    label={<Message id="hide0Balances" />}
                    inline
                />
            </Wrap>
        )
    }
}
