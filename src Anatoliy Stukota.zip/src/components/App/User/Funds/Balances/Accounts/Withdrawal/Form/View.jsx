import React from 'react'
import { observer } from 'mobx-react'
import { Input, Button } from 'common'
import Message from 'i18n/Message'
import Fee from './Fee'
import { Form, Field, Actions } from '../styled'

export default observer(({ form, twoFaEnabled }) => (
    <Form onSubmit={form.handleSubmit}>
        <Field>
            <Input field={form.$('destination')} label={<Message id="address" />} />
        </Field>
        <Field>
            <Input field={form.$('amount')} label={<Message id="amount" />} />
        </Field>

        {twoFaEnabled && (
            <Field>
                <Input field={form.$('authCode')} label={<Message id="FAToken" />} />
            </Field>
        )}

        <Actions>
            <Fee currency={form.currency} />
            <Button fullWidth loading={form.submitting}>
                <Message id="withdrawal" />
            </Button>
        </Actions>
    </Form>
))
