import React from 'react'
import { inject, observer } from 'mobx-react'
import Message from 'i18n/Message'
import { Fee } from '../styled'

export default inject('app')(
    observer(({ currency }) => (
        <Fee>
            <Message id="transactionFee" /> {currency.withdrawalTrxFee}
        </Fee>
    ))
)
