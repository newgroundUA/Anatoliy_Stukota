import { Table as _Table } from 'common/Table/styled'
import { Tab as _Tab } from 'common'
import styled from 'styled-components'
import is from 'styled-is'

const Table = _Table.extend`
    td:nth-child(2),th:nth-child(2){
        text-align: left;
    }
`

const InputSearch = styled.div`
    position: relative;
    margin: 0;
    div {
        padding: 0;
    }
    input,
    input:focus {
        background-color: transparent;
        height: 2.375rem;
        text-indent: 1.875rem;
    }
    [class^='icon-'] {
        position: absolute;
        bottom: 0.75rem;
        font-size: 0.875rem;
        color: #808f92;
    }
`

const FilterWrap = styled.div`
    display: flex;
    justify-content: space-between;
    width: 100%;
    border-bottom: 1px solid #2f3847;
    margin-bottom: 1.375rem;
    margin-top: 2.5rem;
`

const Line = styled.tbody`
    transition: 0.3s;
    ${is('active')`
        transition: .3s;
        background-color: #1B2335;
    `};
`

const Tab = styled(_Tab)`
    a {
        color: #4a90e2;
        font-size: 0.75rem;
        user-select: none;
        span {
            color: #808f92;
            font-size: 1.3125rem;
            vertical-align: middle;
        }
        ${is('active')`
        span {
            color: ${({ value }) => (value === 'deposit' ? '#02E866' : value === 'withdrawal' ? '#E84352' : '#fff')}; 
        }       
    `};
        &:hover {
            cursor: pointer;
        }
    }
`

const HideLine = styled.td`
    padding: 1.25rem !important;
`
export { Content } from '../../styled'
export { Table, InputSearch, FilterWrap, Line, HideLine, Tab }
