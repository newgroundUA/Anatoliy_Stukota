import React from 'react'
import { observer } from 'mobx-react'
import Message from 'i18n/Message'
import { Table } from './styled'
import Item from './Item'

export default observer(({ model }) => (
    <Table main biggest>
        <thead>
            <tr>
                <th>
                    <Message id="coin" />
                </th>
                <th>
                    <Message id="name" />
                </th>
                <th>
                    <Message id="totalBalance" />
                </th>
                <th>
                    <Message id="onOrders" />
                </th>
                <th colSpan="2">
                    <Message id="actions" />
                </th>
            </tr>
        </thead>
        {model.items.map(item => <Item key={item} item={item} />)}
    </Table>
))
