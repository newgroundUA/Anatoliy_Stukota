import styled from 'styled-components'
import { get } from '@utils/themeHelpers'

const Text = styled.p`
    font-size: 0.875rem;
    color: #808f92;
    ${get('linkStyle')};
`
const Form = styled.form`
    display: flex;
    width: 100%;
    padding-top: 0.9375rem;
`

const Field = styled.div`
    flex: auto;
    padding-right: 1%;
`

const Actions = styled.div`
    width: 16.875rem;
    padding-left: 1.25rem;
`

const Fee = styled.p`
    font-size: 0.75rem;
    color: #808f92;
    padding-bottom: 0.1875rem;
`

export { Text, Form, Field, Actions, Fee }
