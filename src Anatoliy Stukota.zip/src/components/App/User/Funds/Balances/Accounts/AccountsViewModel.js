import { observable, action, computed } from 'mobx'

export default class AccountsViewModel {
    constructor(accounts) {
        this.accounts = accounts
    }

    items

    @observable searchField = ''

    @action
    handleChangeSearchField = e => {
        this.searchField = e.target.value
    }

    @observable hideEmptyAccounts = false

    @action
    handleHideEmptyAccountsCheck = () => {
        this.hideEmptyAccounts = !this.hideEmptyAccounts
    }

    @computed
    get items() {
        return this.accounts
            .filter(item => {
                const {
                    currency: { code, name },
                    balance
                } = item

                if (this.hideEmptyAccounts && balance === 0) return false

                return (
                    code.toLowerCase().indexOf(this.searchField.toLowerCase()) !== -1 ||
                    name.toLowerCase().indexOf(this.searchField.toLowerCase()) !== -1
                )
            })
            .sort((a, b) => a.currency.order - b.currency.order)
    }
}
