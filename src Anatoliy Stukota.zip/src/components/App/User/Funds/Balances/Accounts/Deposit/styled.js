import styled from 'styled-components'
import { Button as _Button } from 'common'
import is from 'styled-is'
import { get } from '@utils/themeHelpers'

const Field = styled.div`
    display: flex;
    align-items: center;
`
const ActionButton = styled(_Button)`
    margin-left: 0.9375rem;
    padding-top: 0.25rem;
    flex: none;
    font-size: 1.125rem;
    color: #02e866;
    ${is('refresh')`font-size: 1.25rem;`};
    span {
        vertical-align: sub;
        ${is('isLoading')`
        &:before {
            animation: Loading 1s infinite linear forwards;
            display: inline-block;
        }
        `};
    }
    @keyframes Loading {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(360deg);
        }
    }
`

const Tips = styled.p`
    font-size: 0.625rem;
    color: #808f92;
    ${get('linkStyle')};
`

const Warning = styled.div`
    padding: 10px 10px;
    background: #dec304;
    border-radius: 2px;
    color: black;
    font-size: 0.825rem;
    margin-bottom: 10px;
`

export { Field, ActionButton, Tips, Warning }
