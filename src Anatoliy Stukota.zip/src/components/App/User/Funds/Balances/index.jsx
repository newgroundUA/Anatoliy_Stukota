import React from 'react'
import { inject } from 'mobx-react'
// import { Progress } from 'common'
import Message from 'i18n/Message'
import { Table, AccountsViewModel, Filters } from './Accounts'
import { Content } from '../../styled'
// import { ProgressWrap, Text } from './styled'

export default inject('app')(({ app: { user } }) => {
    const model = new AccountsViewModel(user.accounts)

    return (
        <Content full>
            <h1>
                <Message id="balancesDepositsWithdrawals" />
            </h1>
            {/* <h2>Estimated value of holdings: $553.41 USD/0.067619 BTC</h2>
            <ProgressWrap>
                <Progress currentSize="30" />
            </ProgressWrap>
            <Text>
                $20,000.00 remaining of $25,000.00 USD <a href="#">daily limit</a>
            </Text> */}
            <Filters model={model} />
            <Table model={model} />
        </Content>
    )
})
