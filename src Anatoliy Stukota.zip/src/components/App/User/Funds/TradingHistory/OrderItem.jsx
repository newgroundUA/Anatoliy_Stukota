import React from 'react'
import { DateTime, FormattedNumber } from 'common'
import Message from 'i18n/Message'
import Detail from './OrderItemDetail'
import { Table, Tbody, DetailButton } from './styled'

export default class OrderItem extends React.Component {
    state = {
        active: false
    }

    toggleDetailed = () => {
        this.setState({
            active: !this.state.active
        })
    }

    render() {
        const {
            id,
            currencyPair: { baseCurrency, quoteCurrency, amountScale, priceScale },
            type,
            side,
            baseCurrencyAmount,
            effectivePrice,
            feeAmount,
            baseCurrencyFulfilledAmount,
            status,
            updatedAt,
            trades
        } = this.props.order
        const { active } = this.state

        return (
            <Tbody active={active}>
                <tr>
                    <td>{id}</td>
                    <td>
                        {baseCurrency.code}/{quoteCurrency.code}
                    </td>
                    <td>
                        <span className={side}>
                            {type} {side}
                        </span>
                    </td>
                    <td>
                        <FormattedNumber value={baseCurrencyAmount} scale={amountScale} />
                    </td>
                    <td>
                        <FormattedNumber value={effectivePrice} scale={priceScale} />
                    </td>
                    <td>
                        <FormattedNumber value={Math.abs(feeAmount)} />
                    </td>
                    <td>
                        <FormattedNumber value={baseCurrencyFulfilledAmount} scale={amountScale} />
                    </td>
                    <td>{status}</td>
                    <td>
                        <DateTime time={updatedAt} />
                    </td>
                    <td style={{ width: '6%' }}>
                        {trades.length > 0 && (
                            <DetailButton onClick={this.toggleDetailed}>
                                {active ? <Message id="hide" /> : <Message id="detail" />}
                            </DetailButton>
                        )}
                    </td>
                </tr>

                {active && (
                    <tr>
                        <td colSpan="10">
                            <Table>
                                <thead>
                                    <tr>
                                        <td>
                                            <Message id="tradeId" />
                                        </td>
                                        <td>
                                            <Message id="pair" />
                                        </td>
                                        <td>
                                            <Message id="orderID" />
                                        </td>
                                        <td>
                                            <Message id="price" />
                                        </td>
                                        <td>
                                            <Message id="fee" />
                                        </td>
                                        <td>
                                            <Message id="filled" />
                                        </td>
                                        <td style={{ width: '20%' }}>
                                            <Message id="dateTime" />
                                        </td>
                                    </tr>
                                </thead>

                                <Detail trades={trades} />
                            </Table>
                        </td>
                    </tr>
                )}
            </Tbody>
        )
    }
}
