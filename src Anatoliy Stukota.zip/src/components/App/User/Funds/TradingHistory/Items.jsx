import React from 'react'
import { observer } from 'mobx-react'
import { Paginate } from 'common'
import { Table } from 'common/Table/styled'
import Message from 'i18n/Message'
import OrderItem from './OrderItem'

export default observer(({ myTradeHistory }) => (
    <React.Fragment>
        <Table main biggest>
            <thead>
                <tr>
                    <td>
                        <Message id="orderID" />
                    </td>
                    <td>
                        <Message id="pair" />
                    </td>
                    <td>
                        <Message id="type" />
                    </td>
                    <td>
                        <Message id="amount" />
                    </td>
                    <td>
                        <Message id="price" />
                    </td>
                    <td fee>
                        <Message id="fee" />
                    </td>
                    <td>
                        <Message id="amountMatched" />
                    </td>
                    <td>
                        <Message id="status" />
                    </td>
                    <td>
                        <Message id="dateTime" />
                    </td>
                    <td />
                </tr>
            </thead>

            {myTradeHistory.items.map(order => <OrderItem order={order} />)}
        </Table>

        {myTradeHistory.countPages > 1 && (
            <Paginate
                pageCount={myTradeHistory.countPages}
                onPageChange={myTradeHistory.changePage}
                forcePage={myTradeHistory.page}
            />
        )}
    </React.Fragment>
))
