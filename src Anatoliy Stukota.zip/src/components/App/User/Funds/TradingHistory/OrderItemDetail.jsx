import React from 'react'
import { DateTime, FormattedNumber } from 'common'

export default ({ trades }) => (
    <tbody>
        {trades.map(trade => {
            const {
                id,
                currencyPair: { baseCurrency, quoteCurrency, priceScale },
                makerOrderId,
                price,
                amount,
                makerFee,
                createdAtMs
            } = trade

            return (
                <tr key={id}>
                    <td>{id}</td>
                    <td>
                        {baseCurrency.code}/{quoteCurrency.code}
                    </td>
                    <td>{makerOrderId}</td>
                    <td>
                        <FormattedNumber value={price} scale={priceScale} />
                    </td>
                    <td>
                        <FormattedNumber value={Math.abs(makerFee)} />
                    </td>
                    <td>
                        <FormattedNumber value={amount} />
                    </td>
                    <td>
                        <DateTime time={createdAtMs} />
                    </td>
                </tr>
            )
        })}
    </tbody>
)
