import React from 'react'
import { inject } from 'mobx-react'
import { emitter } from '@utils'
import Message from 'i18n/Message'
import { FormView, FormViewModel } from './Filters'
import Items from './Items'
import { Content } from '../styled'

@inject('app')
export default class Orders extends React.Component {
    constructor(props) {
        super(props)
        this.filters = new FormViewModel()
        this.removeListener = emitter.on('@ordersHistory/clearFilters', () => this.filters.clear())
    }

    componentDidMount = () => {
        this.props.app.user.myTradeHistory.subscribe()
    }

    componentWillUnmount = () => {
        this.removeListener()
        this.props.app.user.myTradeHistory.unsubscribe()
    }

    render() {
        const { myTradeHistory } = this.props.app.user
        return (
            <Content full>
                <h1>
                    <Message id="orderHistory" />
                </h1>
                <FormView form={this.filters} />
                <Items myTradeHistory={myTradeHistory} />
            </Content>
        )
    }
}
