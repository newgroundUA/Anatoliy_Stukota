import React from 'react'
import { inject } from 'mobx-react'
import { Select, DayPickerRange } from 'common/FormElements'
import { Field, Fields } from './styled'

export default inject('app')(({ app: { currencyPairs }, form }) => {
    const $pairs = [
        {
            value: null,
            children: 'All'
        }
    ].concat(
        currencyPairs.map(item => ({
            value: item.name,
            children: `${item.baseCurrency.code}/${item.quoteCurrency.code}`
        }))
    )

    const sides = [
        {
            value: null,
            children: 'All'
        },
        {
            value: 'BUY',
            children: 'BUY'
        },
        {
            value: 'SELL',
            children: 'SELL'
        }
    ]
    return (
        <form onSubmit={form.onSubmit}>
            <Fields>
                <Field>
                    <Select data={$pairs} field={form.$('pair')} placeholder="Pair" />
                </Field>
                <Field>
                    <Select data={sides} field={form.$('side')} placeholder="Transaction Type" />
                </Field>
                <DayPickerRange dateFrom={form.$('updatedFrom')} dateTo={form.$('updatedTo')} />
            </Fields>
        </form>
    )
})
