import Form from '@utils/Form'

export default class ViewModel extends Form {
    initFields() {
        return [
            {
                name: 'pair',
                value: null
            },
            {
                name: 'side',
                value: null
            },
            {
                name: 'updatedFrom',
                value: undefined
            },
            {
                name: 'updatedTo',
                value: undefined
            }
        ]
    }

    onChange = () => {
        this.store.app.user.myTradeHistory.changeFilters(this.getValues())
    }
}
