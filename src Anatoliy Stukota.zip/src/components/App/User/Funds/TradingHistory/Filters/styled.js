import styled from 'styled-components'

const Field = styled.div`
    max-width: 10.625rem;
    width: 100%;
    display: block;
    margin-right: 10px;
`
const Fields = styled.div`
    display: flex;
    width: 43.75rem;
    justify-content: space-between;
    float: right;
    margin-top: 0.3125rem;
`

export { Field, Fields }
