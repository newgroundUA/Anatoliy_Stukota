import styled from 'styled-components'
import is from 'styled-is'
import { Table as _Table } from 'common/Table/styled'

const Table = styled(_Table)`
    padding: 1rem 3rem;
    tbody {
        tr:last-child {
            td {
                border-bottom: none;
            }
        }
    }
`
const Tbody = styled.tbody`
    ${is('active')`
        transition: .3s;
        background-color: #1B2335;
    `};
`

const DetailButton = styled.span`
    color: #4a90e2;
    cursor: pointer;
`

export { Table, Tbody, DetailButton }
