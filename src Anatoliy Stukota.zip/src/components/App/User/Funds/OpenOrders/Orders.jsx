import React from 'react'
import { observer } from 'mobx-react'
import { Table, DateTime, Icon, FormattedNumber } from 'common'
import styled from 'styled-components'
import Message from 'i18n/Message'

const Close = styled(Icon)`
    color: #808f92;
    cursor: pointer;
    transition: all 0.3s;
    &:hover {
        color: #fff;
        transition: all 0.3s;
    }
`

const columns = [
    {
        title: <Message id="order" />,
        data: 'id',
        style: { width: '8%' }
    },
    {
        title: <Message id="dateTime" />,
        data: 'createdAt',
        style: { width: '15%', textAlign: 'left' },
        render: value => <DateTime time={value} />
    },

    {
        title: <Message id="pair" />,
        data: 'currencyPair',
        style: { width: '9%', textAlign: 'left' },
        render: ({ baseCurrency, quoteCurrency }) => (
            <span>
                {baseCurrency.code}/{quoteCurrency.code}
            </span>
        )
    },
    {
        title: <Message id="type" />,
        data: 'side',
        style: { width: '3%', textAlign: 'left' },
        render: value => <span className={value}>{value}</span>
    },
    {
        title: <Message id="amount" />,
        data: 'baseCurrencyAmount',
        style: { width: '11%', textAlign: 'right' },
        render: (value, data) => `${value} ${data.currencyPair.baseCurrency.code}`
    },
    {
        title: <Message id="price" />,
        data: 'price',
        style: { width: '7%', textAlign: 'right' },
        render: (value, item) => <FormattedNumber value={value} scale={item.currencyPair.priceScale} />
    },
    {
        title: <Message id="total" />,
        key: 'quoteCurrencyAmount',
        style: { width: '9%' },
        render: (value, item) => <FormattedNumber value={item.baseCurrencyAmount * item.price} />
    },
    {
        title: <Message id="amountLeft" />,
        data: 'baseCurrencyRemainingAmount',
        style: { width: '9%', textAlign: 'right' }
    },

    {
        key: 'progress',
        style: { width: '23%', padding: '0 0.625rem' },
        title: ' ',
        render: ({ side, baseCurrencyAmount, baseCurrencyFulfilledAmount }) => {
            const remaining = Math.round((baseCurrencyFulfilledAmount * 100) / baseCurrencyAmount)
            return (
                <span className="amount">
                    <span className={`big progress ${side}`}>
                        <span style={{ width: `${remaining}%` }} />
                    </span>
                </span>
            )
        }
    },
    {
        title: <Message id="progress" />,
        key: 'remaining',
        render: ({ baseCurrencyAmount, baseCurrencyFulfilledAmount }) =>
            `${Math.round((baseCurrencyFulfilledAmount * 100) / baseCurrencyAmount)}%`,
        style: { width: '4%', textAlign: 'left' }
    },

    {
        title: ' ',
        data: 'cancel',
        style: { width: '1rem', maxWidth: '1rem' },
        render: cancel => <Close name="close" onClick={cancel} />
    }
]

export default observer(({ openOrders }) => (
    <Table main biggest openOrders data={openOrders.items} loading={openOrders.isLoading} columns={columns} />
))
