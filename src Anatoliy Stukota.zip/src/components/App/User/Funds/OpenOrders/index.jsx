import React from 'react'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'
import Orders from './Orders'
import { Content } from '../styled'

@inject('app')
export default class OpenOrders extends React.Component {
    componentDidMount = () => {
        this.props.app.user.openOrders.fetch({})
        this.props.app.user.openOrders.subscribe()
    }

    componentWillUnmount = () => {
        this.props.app.user.openOrders.unsubscribe()
    }

    render() {
        const { openOrders } = this.props.app.user
        return (
            <Content full>
                <h1>
                    <Message id="myOpenOrders" />
                </h1>
                <Orders openOrders={openOrders} />
            </Content>
        )
    }
}
