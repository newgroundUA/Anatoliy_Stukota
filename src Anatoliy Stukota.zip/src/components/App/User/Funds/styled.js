import styled from 'styled-components'
import { Content as _Content } from '../styled'

const Wrap = styled.div`
    padding-left: 4.375rem;
    padding-top: 0.625rem;
    padding-right: 1.25rem;
`

const Content = _Content.extend`
    h1 {
        float: left;
    }
`

export { Wrap, Content }
