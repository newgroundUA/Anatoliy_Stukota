import React from 'react'
import { Table } from 'common'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'

const columns = [
    {
        title: <Message id="transferMethod" />,
        data: 'children'
    },
    {
        title: <Message id="fee" />,
        data: 'val'
    }
]

export default inject('app')(({ app: { fees } }) => {
    const data = [
        {
            key: 'maker',
            children: <Message id="maker" />,
            val: `${Math.abs(fees.maker) * 100}%`
        },
        {
            key: 'taker',
            children: <Message id="taker" />,
            val: `${Math.abs(fees.taker) * 100}%`
        }
    ]
    return (
        <React.Fragment>
            <Table main biggest caption={<Message id="tradeFees" />} data={data} columns={columns} />
        </React.Fragment>
    )
})
