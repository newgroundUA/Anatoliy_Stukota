import React from 'react'
import Message from 'i18n/Message'
import {
    Flex,
    Content,
    Col
    // Vol
} from './styled'
import Trade from './Trade'
import Withdrawal from './Withdrawal'

export default () => (
    <Content>
        <h1>
            <Message id="feesAndLimits" />
        </h1>
        {/* <Vol>
            Your 30-day Volume
            <p>0.00000000 BTC</p>
        </Vol> */}
        <Flex between>
            <Col>
                <Withdrawal />
            </Col>
            <Col>
                <Trade />
            </Col>
        </Flex>
    </Content>
)
