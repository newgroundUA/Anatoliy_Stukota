import styled from 'styled-components'

const Col = styled.div`
    width: 48%;
`
const Vol = styled.div`
    background-color: #1c1f2c;
    padding: 1.0625rem 0 0.9375rem;
    text-align: center;
    margin-bottom: 2.5rem;
    font-size: 0.875rem;
    color: #808f92;
    font-weight: 600;
    p {
        font-size: 2.25rem;
        color: #ffffff;
    }
`

export { Flex } from 'common'
export { Content } from '../../styled'
export { Col, Vol }
