import React from 'react'
import { Table } from 'common'
import { inject } from 'mobx-react'
import Message from 'i18n/Message'

const columns = [
    {
        title: <Message id="transferMethod" />,
        key: 'code',
        render: (value, item) => item.code
    },
    {
        title: <Message id="fee" />,
        data: 'withdrawalTrxFee'
    }
]

export default inject('app')(({ app: { currencies } }) => (
    <React.Fragment>
        <Table
            main
            biggest
            caption={<Message id="withdrawalFees" />}
            data={currencies.filter(item => item.isWithdrawalEnabled)}
            columns={columns}
            rowKey="code"
        />
    </React.Fragment>
))
