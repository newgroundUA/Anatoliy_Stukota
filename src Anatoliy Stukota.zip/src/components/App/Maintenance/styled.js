import styled from 'styled-components'
import { get } from '@utils/themeHelpers'

const Wrap = styled.div`
    width: 100%;
    min-height: 100vh;
    background-color: #1a1d24;
    canvas {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        margin: auto;
        width: 100%;
        height: 100%;
    }
`

const Content = styled.div`
    text-align: center;
    width: 50rem;
    max-width: 100%;
    height: 31.25rem;
    max-height: 100%;
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    align-items: center;
`
const Title = styled.div`
    font-size: 2.5rem;
    font-weight: 600;
    color: #ffffff;
`
const Text = styled.p`
    font-weight: 600;
    font-size: 0.875rem;
    color: #ffffff;
    line-height: 2.75rem;
    ${get('linkStyle')};
`
const IconWrap = styled.div`
    width: 14.4375rem;
    height: 10.125rem;
    svg {
        width: 100%;
        height: 100%;
    }
`
export { Wrap, Content, Title, Text, IconWrap }
