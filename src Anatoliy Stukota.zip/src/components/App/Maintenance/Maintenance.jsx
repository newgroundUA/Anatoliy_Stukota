import React from 'react'
import Message from 'i18n/Message'
import withSupport from 'common/WithSupport'
import Icon from './maintenance.svg'

import { Content, Title, Text, IconWrap } from './styled'

export default withSupport(false)(({ underConstruction }) => (
    <Content>
        <IconWrap>
            <Icon />
        </IconWrap>
        <Title>
            {underConstruction ? (
                <Message id="thisPageIsUnderAMaintenance" />
            ) : (
                <Message id="ourPlatformIsUnderAMaintenance" />
            )}
        </Title>
        <h2>
            <Message id="weApologizeForTheInconveniences" />
        </h2>
        {underConstruction && (
            <h2>
                <Message id="checkBackLater" />
            </h2>
        )}
        <Text>
            <Message id="pleaseContactAsAt" /> <a href="mailto:support@coinsupply.com ">support@coinsupply.com</a>{' '}
            <Message id="inCaseOfAnyQuestions" />
        </Text>
    </Content>
))
