import React from 'react'
import ReactDOM from 'react-dom'
import { ThemeProvider } from 'styled-components'
import Maintenance from './Maintenance'
import Style from '../../../globalStyle'
import theme from '../../../themes'
import Layout from '../Layout/Secondary'

ReactDOM.render(
    <ThemeProvider theme={theme}>
        <Style>
            <Layout>
                <Maintenance />
            </Layout>
        </Style>
    </ThemeProvider>,
    document.getElementById('react-root')
)
