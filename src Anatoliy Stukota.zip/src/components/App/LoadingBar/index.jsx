import React from 'react'
import { inject } from 'mobx-react'
import { autorun } from 'mobx'
import { Loader } from './styled'

@inject('router')
export default class LoadingBar extends React.PureComponent {
    state = {
        show: false,
        isLoading: false,
        isLoaded: false
    }

    componentDidMount = () => {
        autorun(() => this.animate(this.props.router.state))
    }

    animate = state => {
        if (!this.state.isLoading && state === 'loading') {
            this.setState(
                {
                    show: true
                },
                () => {
                    this.timeoutToLoading = setTimeout(() => {
                        this.setState({
                            isLoading: true,
                            isLoaded: false
                        })
                    }, 50)
                }
            )
        }
        if (this.state.isLoading && state !== 'loading') {
            this.setState(
                {
                    isLoading: false,
                    isLoaded: true
                },
                () => {
                    setTimeout(() => {
                        this.setState({
                            isLoaded: false,
                            show: false
                        })
                    }, 400)
                }
            )
        }

        if (this.state.show && this.state.isLoading === false) {
            clearTimeout(this.timeoutToLoading)
            this.setState({
                show: false,
                isLoading: false,
                isLoaded: false
            })
        }
    }

    render() {
        const { isLoaded, isLoading, show } = this.state
        return (
            show && (
                <Loader
                    style={{ width: !isLoading && !isLoaded ? '0%' : isLoading && !isLoaded ? '70%' : '100%' }}
                    loaded={this.state.isLoaded}
                />
            )
        )
    }
}
