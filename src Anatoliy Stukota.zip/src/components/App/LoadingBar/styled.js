import styled from 'styled-components'

const Loader = styled.div`
    position: fixed;
    display: inline-block;
    top: 0;
    left: 0;
    z-index: 100;
    height: 0.1875rem;
    width: 0%;
    background: red;
    transition: all 0.5s;
    ${({ loaded }) =>
        loaded &&
        `
        transition: 0.3s;
    `};
`

export { Loader }
