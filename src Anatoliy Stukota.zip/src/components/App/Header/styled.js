import styled from 'styled-components'
import { Link } from 'react-router-dom'
import is from 'styled-is'
import { get } from '@utils/themeHelpers'
import { Button as _Button, Icon as _Icon } from 'common'

const Wrap = styled.section`
    background-color: #1a2130;
    min-width: 100%;
    height: ${get('headerHeight')};
    box-shadow: 0 1px 0 0 #444;
    position: relative;
    z-index: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 1rem;
    box-sizing: border-box;
`

const IconLink = styled(Link)`
    margin-right: 1.5625rem;
    font-size: 0.75rem;
    height: 100%;
    width: 8.5rem;
    & > * {
        width: 100%;
        height: 100%;
    }
`

const Title = styled.p`
    font-size: 0.75rem;
    color: #808f92;
    padding-bottom: 0.125rem;
`
const Item = styled.div`
    padding-left: 1.625rem;
    padding-right: 0.5625rem;
    @media (max-width: 1279px) {
        padding-left: 1.25rem;
        padding-right: 0.4rem;
    }
`
const List = styled.div`
    display: flex;
    align-items: center;
`

const Val = styled.p`
    font-size: 1rem;
    color: ${({ plus, change }) => (!plus && change ? get('red') : change ? get('green') : '#FFFFFF')};
    @media (max-width: 1279px) {
        font-size: 0.75rem;
    }
`
const Button = styled(_Button)`
    padding: 0 2.125rem;
    line-height: 1.6875rem;
    height: 1.875rem;
    display: inline-block;
    margin: 0 0.625rem;
    ${is('secondary')`
       color: #06B758;
        background: transparent;
        border: 1px solid transparent;
        &:hover{
            border-color: #02E866;
        }        
    `};
    ${is('disabled')`
        &:hover{
            border-color: transparent;
        }        
    `};
`
const Icon = styled(_Icon)`
    font-size: 1.375rem;
    color: #0d9954;
    ${is('wallet')`font-size: 1.25rem;`};
`
export { Wrap, IconLink, Button, Title, Item, List, Val, Icon }
