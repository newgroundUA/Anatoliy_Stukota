import React from 'react'
import { inject, observer } from 'mobx-react'
import { FormattedNumber } from 'common'
import { round } from '@utils'
import Message from 'i18n/Message'
import { Item, Title, Val } from '../styled'

export default inject('app')(
    observer(({ app: { currencyPair } }) => (
        <React.Fragment>
            <Item>
                <Title>
                    <Message id="lastPrice" />
                </Title>
                <Val>
                    <FormattedNumber value={currencyPair.close} scale={currencyPair.quoteCurrency.priceScale} />
                </Val>
            </Item>
            <Item>
                <Title>
                    (<FormattedNumber value={currencyPair.dailyChange} scale={currencyPair.quoteCurrency.priceScale} />)
                </Title>
                <Val change plus={currencyPair.dailyChange >= 0}>
                    {round(currencyPair.dailyChangePercent, 2)}%
                </Val>
            </Item>
            <Item>
                <Title>
                    <Message id="low" />
                </Title>
                <Val>
                    <FormattedNumber value={currencyPair.lowest} scale={currencyPair.quoteCurrency.priceScale} />
                </Val>
            </Item>
            <Item>
                <Title>
                    <Message id="high" />
                </Title>
                <Val>
                    <FormattedNumber value={currencyPair.highest} scale={currencyPair.quoteCurrency.priceScale} />
                </Val>
            </Item>
            <Item>
                <Title>
                    <Message id="volume" />
                </Title>
                <Val>
                    <FormattedNumber value={currencyPair.volume} scale={currencyPair.quoteCurrency.amountScale} />
                </Val>
            </Item>
        </React.Fragment>
    ))
)
