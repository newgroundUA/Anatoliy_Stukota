import React from 'react'
import { observer } from 'mobx-react'
import { Table, ScrollWrap } from './styled'
import Item from './Item'

export default observer(({ model }) => (
    <ScrollWrap className="scrollbar">
        <div>
            <Table>
                <tbody>{model.items.map(item => <Item key={item.code} model={model} pair={item} />)}</tbody>
            </Table>
        </div>
    </ScrollWrap>
))
