import React from 'react'
import { observer } from 'mobx-react'
import { round } from '@utils'
import { CurrencyIcon, PerCentRow, PairRow, CurrencyIconRow } from './styled'

@observer
export default class Ticker extends React.Component {
    handleClickPair = e => {
        if (e.target.tagName !== 'TD') return

        const {
            pair,
            model: { router }
        } = this.props
        router.push(`/trade/${pair.name}`)
    }

    render() {
        const {
            pair,
            model: { app }
        } = this.props

        const isActive = app.currencyPair.name === pair.name
        return (
            <tr onClick={this.handleClickPair} className={`${isActive ? 'active_pair' : ''}`}>
                <CurrencyIconRow>
                    <CurrencyIcon name={pair.baseCurrency.code.toLowerCase()} />
                </CurrencyIconRow>
                <PairRow>
                    {pair.baseCurrency.code}/{pair.quoteCurrency.code}
                </PairRow>
                <td>{round(pair.volume, 2)}</td>
                <PerCentRow plus={pair.dailyChange >= 0}>
                    {pair.dailyChange > 0 && '+'}
                    {round(pair.dailyChangePercent, 0)}%
                </PerCentRow>
                <td>{pair.close}</td>
            </tr>
        )
    }
}
