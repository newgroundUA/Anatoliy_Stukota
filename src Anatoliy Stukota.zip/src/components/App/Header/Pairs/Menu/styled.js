import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import { Icon } from 'common'

const ScrollWrap = styled.div`
    max-height: calc(100vh - ${get('headerHeight')});
    height: 18.8125rem;
    overflow: auto;
    width: 100%;
`

const Table = styled.table`
    width: 100%;
    max-width: 100%;
    overflow: hidden;
    border-spacing: 0;
    .SELL {
        color: ${get('red')};
    }
    .BUY {
        color: ${get('green')};
    }
    tr:hover {
        cursor: pointer;
        td {
            background-color: #1a2130;
        }
    }
    td {
        font-size: 0.75rem;
        color: #cdd2d6;
        height: 2.625rem;
        padding: 0.25rem;
    }
    td:last-child {
        text-align: right;
        padding-right: 1.25rem;
    }
    td:first-child {
        text-align: left;
        padding-left: 1.25rem;
    }
    .active_pair,
    .active_pair:hover {
        cursor: default;
        td {
            color: #fff;
            background-color: transparent;
            font-weight: bold;
        }
        [class^='icon-'] {
            color: #02e866;
        }
    }
    td:nth-child(2) {
        text-align: left;
    }
`

const PairRow = styled.td`
    text-align: left;
    padding-left: 0.3125rem;
`
const CurrencyIconRow = styled.td`
    vertical-align: middle;
    text-align: center;
`
const Wrap = styled.div`
    width: 23rem;
`
const CurrencyIcon = styled(Icon)`
    font-size: 0.875rem;
    color: #fff;
`
const PerCentRow = styled.td`
    font-weight: 600;
    font-size: 0.75rem;
    text-align: right;
    td& {
        color: ${({ plus }) => (plus ? get('green') : get('red'))};
    }
`

export { PerCentRow, Table, ScrollWrap, PairRow, CurrencyIconRow, Wrap, CurrencyIcon }
