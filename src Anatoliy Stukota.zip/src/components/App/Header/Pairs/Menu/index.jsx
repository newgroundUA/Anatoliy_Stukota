import React from 'react'
import { inject } from 'mobx-react'
import Menu from './Menu'
import MenuViewModel from './MenuViewModel'
import Search from './Search'
import { Wrap } from './styled'

export default inject('router', 'app')(({ app, router }) => {
    const model = new MenuViewModel(app, router)
    return (
        <Wrap>
            <Search model={model} />
            <Menu model={model} />
        </Wrap>
    )
})
