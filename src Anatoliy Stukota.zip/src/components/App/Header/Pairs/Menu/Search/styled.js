import styled from 'styled-components'

const Wrap = styled.div`
    position: relative;
    padding: 0 1.25rem;
    margin-bottom: 0.625rem;
    input,
    input:focus {
        background-color: transparent;
        border-bottom: 1px solid #2f3847;
        height: 2.375rem;
        text-indent: 1.875rem;
    }

    [class^='icon-'] {
        position: absolute;
        top: 0.8125rem;
        left: 1.25rem;
        color: #808f92;
    }
`

export { Wrap }
