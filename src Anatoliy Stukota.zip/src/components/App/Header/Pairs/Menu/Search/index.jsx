import React from 'react'
import { observer } from 'mobx-react'
import { Input, Icon } from 'common'
import { Wrap } from './styled'

export default observer(({ model }) => (
    <Wrap>
        <Input value={model.searchField} onChange={model.handleSearchFieldChange} />
        <Icon name="search" />
    </Wrap>
))
