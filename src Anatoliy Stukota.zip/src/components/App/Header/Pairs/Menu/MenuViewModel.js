import { observable, action, computed } from 'mobx'

export default class MenuViewModel {
    constructor(app, router) {
        this.router = router
        this.app = app
    }

    @observable searchField = ''

    @action
    handleSearchFieldChange = e => {
        this.searchField = (e.target.value || '').toLowerCase()
    }

    @computed
    get items() {
        return this.app.currencyPairs.filter(item => {
            if (this.searchField === '') return true

            return (
                item.baseCurrency.code.toLowerCase().indexOf(this.searchField) !== -1 ||
                item.baseCurrency.name.toLowerCase().indexOf(this.searchField) !== -1
            )
        })
    }
}
