import styled from 'styled-components'

const Wrap = styled.div`
    //padding-right: 1.125rem;
    //  padding-left: 1.1875rem;
    //  border-left: 1px solid #2F3847;
    //  border-right: 1px solid #2F3847;
`

const Base = styled.a`
    font-size: 1.25rem;
    color: #ffffff;
    position: relative;
    padding-right: 1.5625rem;
    &:after {
        width: 0.3125rem;
        height: 0.3125rem;
        border-left: 0.125rem solid #fff;
        border-top: 0.125rem solid #fff;
        transform: rotate(-135deg);
        display: block;
        content: '';
        position: absolute;
        right: 0.625rem;
        top: 0.625rem;
    }
`

export { Title } from '../styled'
export { Base, Wrap }
