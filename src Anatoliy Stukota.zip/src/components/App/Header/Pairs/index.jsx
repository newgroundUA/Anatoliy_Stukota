import React from 'react'
import { inject, observer } from 'mobx-react'
import Message from 'i18n/Message'
import DropDown from '../DropDown'
import Menu from './Menu'
import { Wrap, Base, Title } from './styled'

@inject('app')
@observer
export default class index extends React.Component {
    render() {
        const {
            app: {
                currencyPair: { baseCurrency, quoteCurrency }
            }
        } = this.props
        return (
            <DropDown right menu={<Menu />}>
                <Wrap>
                    <Title>
                        <Message id="selectPair" />
                    </Title>
                    <Base>
                        {baseCurrency.code}/{quoteCurrency.code}
                    </Base>
                </Wrap>
            </DropDown>
        )
    }
}
