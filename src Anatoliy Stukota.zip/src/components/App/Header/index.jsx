import React from 'react'
import { inject, observer } from 'mobx-react'
import { withRouter } from 'react-router'
import Logo from 'assets/coinsupply.svg'
import Navigation from './Navigation'
import Pairs from './Pairs'
import PairInfo from './PairInfo'

import { Wrap, List, IconLink } from './styled'

export default withRouter(
    inject('app')(
        observer(({ app }) => (
            <Wrap>
                <List>
                    <IconLink to="/">
                        <Logo />
                    </IconLink>
                    <Pairs />
                    <PairInfo />
                </List>
                <Navigation app={app} />
            </Wrap>
        ))
    )
)
