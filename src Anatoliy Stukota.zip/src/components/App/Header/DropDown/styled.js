import styled from 'styled-components'
import { get } from '@utils/themeHelpers'
import is from 'styled-is'

const Wrap = styled.div`
    display: inline-block;
    position: relative;
    transition: 0.3s;
    &:hover {
        background-color: #171924;
        transition: 0.3s;
    }
`

const Title = styled.div`
    height: ${get('headerHeight')};
    display: flex;
    align-items: center;
    padding: 0 1.375rem;
    cursor: pointer;
    &:before {
        width: 1px;
        height: 2.25rem;
        background-color: #2f3847;
        display: block;
        content: '';
        position: absolute;
        left: 1px;
    }
    @media (min-width: 1280px) {
        [class^='icon-'] {
            padding-right: 0.625rem;
        }
    }
    @media (max-width: 1279px) {
        font-size: 0;
    }
    ${is('right')`
    &:after {
        width: 1px;
        height: 2.25rem;
        background-color: #2f3847;
        display: block;
        content: '';
        position: absolute;
        right: 1px;
    }
    `};

    ${Wrap}:hover & {
        &:before,
        &:after {
            opacity: 0;
        }
    }
`

const Block = styled.div`
    background-color: #171924;
    position: absolute;
    top: ${get('headerHeight')};
    min-width: 100%;
    z-index: 10;
    max-height: 0;
    overflow: hidden;
    opacity: 0;
    transition: all 0.4s;
    li {
        list-style-type: none;
    }
    a,
    button {
        padding: 1.1875rem 1.75rem;
        box-sizing: border-box;
        display: block;
        width: 100%;
        font-size: inherit;
        color: #cdd2d6;
        background-color: transparent;
        border: none;
        cursor: pointer;
        white-space: nowrap;
        text-align: left;
        &:hover {
            background-color: #1a2130;
            color: #02e866;
        }
    }
    button {
        color: #a5394a;
        &:hover {
            color: #fff;
        }
    }
    ${Wrap}:hover & {
        max-height: 62.4375rem;
        transition: all 0.4s;
        opacity: 1;
    }

    ${({ right }) => (right ? 'left: 0;' : 'right: 0;')};
`

export { Title, Block, Wrap }
