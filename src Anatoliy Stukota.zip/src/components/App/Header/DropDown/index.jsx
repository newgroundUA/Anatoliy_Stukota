import React from 'react'
import { Title, Block, Wrap } from './styled'

export default props => (
    <Wrap>
        <Title right={props.right}>{props.children}</Title>
        <Block right={props.right}>{props.menu}</Block>
    </Wrap>
)
