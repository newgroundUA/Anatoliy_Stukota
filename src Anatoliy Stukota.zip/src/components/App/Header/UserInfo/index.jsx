import React from 'react'
import { observer } from 'mobx-react'
import { Icon } from '../styled'
import { Wrap, Item } from './styled'
@observer
export default class index extends React.Component {
    componentDidMount = () => {
        this.props.app.user.subscribe()
    }

    componentWillUnmount = () => {
        this.props.app.user.unsubscribe()
    }

    render() {
        const {
            app: {
                currencyPair: { baseCurrency, quoteCurrency }
            }
        } = this.props
        return (
            <Wrap>
                <Icon name="wallet" wallet />
                <Item>
                    {baseCurrency.account.balance} {baseCurrency.code}
                </Item>
                <Item>
                    {quoteCurrency.account.balance} {quoteCurrency.code}
                </Item>
            </Wrap>
        )
    }
}
