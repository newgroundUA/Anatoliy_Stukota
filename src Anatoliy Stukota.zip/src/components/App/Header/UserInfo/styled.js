import styled from 'styled-components'

const Wrap = styled.div`
    display: flex;
    cursor: pointer;
    align-items: center;
    [class^='icon-'] {
        padding-right: 0.3125rem;
    }
`

const Item = styled.div`
    padding-left: 1.5rem;
    font-size: 1rem;
    color: #ffffff;
    @media (max-width: 1279px) {
        font-size: 0.75rem;
        padding-left: 1rem;
    }
`

export { Wrap, Item }
