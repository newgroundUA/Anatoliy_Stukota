import React from 'react'
import { NavLink, withRouter } from 'react-router-dom'
import { observer } from 'mobx-react'
import Message from 'i18n/Message'
import { Button, Icon } from '../styled'
import DropDown from '../DropDown'
import UserInfo from '../UserInfo'

export default withRouter(
    observer(
        ({ app }) =>
            app.isAuthenticated ? (
                <div>
                    <DropDown
                        menu={
                            <ul>
                                <li>
                                    <NavLink to="/user/funds/balances">
                                        <Message id="balancesDepositsWithdrawals" />
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/user/funds/order-history">
                                        <Message id="orderHistory" />
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/user/funds/open-orders">
                                        <Message id="myOpenOrders" />
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/user/funds/transaction-history">
                                        <Message id="myTransactionsHistory" />
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/user/funds/fees-limits">
                                        <Message id="feesAndLimits" />
                                    </NavLink>
                                </li>
                            </ul>
                        }
                    >
                        <UserInfo app={app} />
                    </DropDown>
                    <DropDown
                        menu={
                            <ul>
                                <li>
                                    <a
                                        href="https://support.coinsupply.com/hc/en-us"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                    >
                                        <Message id="helpCenter" />
                                    </a>
                                </li>
                                <li>
                                    <a
                                        href="https://support.coinsupply.com/hc/en-us/categories/360000436872-FAQ"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                    >
                                        FAQ
                                    </a>
                                </li>
                                <li>
                                    <a
                                        href="https://support.coinsupply.com/hc/en-us/requests/new"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                    >
                                        <Message id="submitRequest" />
                                    </a>
                                </li>
                            </ul>
                        }
                    >
                        <Icon name="question" />
                        <Message id="helpCenter" />
                    </DropDown>
                    <DropDown
                        menu={
                            <ul>
                                {/* <li>
                                    <NavLink to="/user/settings/general">General</NavLink>
                                </li> */}
                                <li>
                                    <NavLink to="/user/settings/profile">
                                        <Message id="profileAndSecurity" />
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/user/settings/api">
                                        <Message id="api.access.navLink" />
                                    </NavLink>
                                </li>
                                {/* <li>
                                    <NavLink to="/user/settings/activity-log">Activity Log</NavLink>
                                </li> */}
                                <li>
                                    <button type="button" onClick={app.logout}>
                                        <Message id="logout" />
                                    </button>
                                </li>
                            </ul>
                        }
                    >
                        <Icon name="user" />
                        <Message id="profile" />
                    </DropDown>
                </div>
            ) : (
                <div>
                    <a href="https://api.coinsupply.com/docs/alpha" target="_blank" rel="noopener noreferrer">
                        <Button>API</Button>
                    </a>
                    {
                        <NavLink to="/register">
                            <Button secondary disabled={!app.features.isSignUpActivationEnabled}>
                                <Message id="register" />
                            </Button>
                        </NavLink>
                    }
                    <NavLink to="/login">
                        <Button>
                            <Message id="signIn" />
                        </Button>
                    </NavLink>
                </div>
            )
    )
)
