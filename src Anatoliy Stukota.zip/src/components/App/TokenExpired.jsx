import React from 'react'
import { Content, MainTitle } from 'common/SecondaryLayout'

export default () => (
    <Content center width="28.125rem">
        <MainTitle>Token has expired</MainTitle>
    </Content>
)
