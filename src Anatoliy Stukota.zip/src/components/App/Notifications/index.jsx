import React from 'react'
import { inject, observer } from 'mobx-react'
import styled from 'styled-components'
import Message from 'i18n/Message'

const Notification = styled.div`
    position: relative;
    right: 0;
    min-width: 15.625rem;
    // max-height: 3.125rem;
    margin-bottom: 1.25rem;
    background: #232323;
    border-radius: 5px;
    padding: 0.625rem 1.25rem;
    transition: all 0.3s ease;
    p {
        padding-bottom: 0.25rem;
        font-size: 1rem;
    }
    span {
        font-size: 0.875rem;
    }
    cursor: pointer;
`

const Wrapper = styled.div`
    display: flex;
    position: fixed;
    right: 0;
    top: 3.75rem;
    // bottom: 0;
    z-index: 1000;
    width: 18.75rem;
    flex-wrap: wrap;
    justify-content: flex-end;
    margin-right: 1.5rem;

    .slide-left {
        animation-name: slide-left;
        animation-duration: 0.6s;
        animation-timing-function: ease-in-out;
        visibility: visible !important;
    }

    .slide-top {
        animation-name: slide-top;
        animation-duration: 0.3s;
        animation-timing-function: ease-in-out;
        animation-direction: normal;

        visibility: visible !important;
    }

    @keyframes slide-left {
        0% {
            transform: translateX(120%);
        }
        100% {
            transform: translateX(0%);
        }
    }

    @keyframes slide-top {
        0% {
            top: 0;
        }
        100% {
            top: -6.25rem;
        }
    }
`

@inject('notifications')
@observer
export default class index extends React.Component {
    render() {
        return (
            <Wrapper>
                {this.props.notifications.items.map(item => (
                    <Notification
                        className={`slide-left ${item.hided ? 'slide-top' : ''}`}
                        key={item.id}
                        onClick={() => this.props.notifications.hide(item.id)}
                    >
                        <p>{item.title && <Message id={item.title} data={item.data} />}</p>
                        <span>{item.message && <Message id={item.message} data={item.data} />}</span>
                    </Notification>
                ))}
            </Wrapper>
        )
    }
}
