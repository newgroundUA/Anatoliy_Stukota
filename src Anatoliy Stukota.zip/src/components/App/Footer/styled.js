import styled from 'styled-components'
import { Link } from 'react-router-dom'
import { get } from '@utils/themeHelpers'

const Wrap = styled.footer`
    background-color: #1a2130;
    min-width: 100%;
    height: ${get('footerHeight')};
    box-shadow: 0 1px 0 0 #444;
    display: flex;
    align-items: center;
    padding-left: 1rem;
    font-size: 0.75rem;
    a {
        color: #fff;
        margin-right: 1rem;
        &:hover {
            color: #02e866;
        }
        &.active {
            color: #02e866;
        }
    }
`

const IconLink = styled(Link)`
    margin-right: 1.5625rem;
    width: 8.5rem;
    & > * {
        width: 100%;
        height: 100%;
    }
`

const Copyright = styled.div`
    margin-right: 1rem;
    color: #6a7380;
`

export { Wrap, IconLink, Copyright }
