import React from 'react'
import { withRouter } from 'react-router'
import Logo from 'assets/coinsupply.svg'
import Navigation from './Navigation'

import { Wrap, IconLink, Copyright } from './styled'

export default withRouter(() => (
    <Wrap>
        <IconLink to="/">
            <Logo />
        </IconLink>
        <Copyright>
            Copyright © Coin Supply AG,<br /> Switzeland, {new Date().getFullYear()}
        </Copyright>
        <Navigation />
    </Wrap>
))
