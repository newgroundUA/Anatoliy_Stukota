import React from 'react'
import { NavLink } from 'react-router-dom'
import Message from 'i18n/Message'

export default () => (
    <React.Fragment>
        <NavLink to="/legal/terms-of-service">
            <Message id="termsOfService" />
        </NavLink>
        <NavLink to="/legal/privacy-policy">
            <Message id="privacyPolicy" />
        </NavLink>
        <NavLink to="/legal/anti-spam-policy">
            <Message id="antiSpamPolicy" />
        </NavLink>
        <NavLink to="/legal/risk-disclosure-statement">
            <Message id="riskDisclosureStatement" />
        </NavLink>
        <NavLink to="/legal/trademark-notices">
            <Message id="trademarkNotices" />
        </NavLink>
        <NavLink to="/legal/ctk-token-terms">
            <Message id="ctkTokenTerms" />
        </NavLink>
    </React.Fragment>
)
