import React from 'react'
import PropTypes from 'prop-types'
import debounce from 'debounce'
import { round } from '@utils'

export default class Chart extends React.Component {
    static propTypes = {
        width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        data: PropTypes.array, // eslint-disable-line
        strokeColor: PropTypes.string,
        fillColor: PropTypes.string,
        reverse: PropTypes.bool,
        xAxis: PropTypes.bool,
        margin: PropTypes.shape({
            top: PropTypes.number,
            left: PropTypes.number
        })
    }

    static defaultProps = {
        data: [],
        xAxis: false,
        margin: {
            top: 0,
            left: 0
        }
    }

    state = {
        initialed: false,
        points: null,
        chartData: null,
        areaChartData: null,
        point: null
    }

    componentDidMount = () => {
        this.setState({ ...this.calculateChart(), initialed: true })
        window.addEventListener('resize', this.handleResize)
    }

    componentWillReceiveProps = nextProps => {
        this.setState(this.calculateChart(nextProps))
    }

    componentWillUnmount = () => {
        window.removeEventListener('resize', this.handleResize)
    }

    handleResize = debounce(() => {
        this.setState(this.calculateChart())
    }, 400)

    calculateChart = (props = this.props) => {
        let chartData = ''
        let areaChartData = ''
        const points = []

        const { data } = props
        const { width: $width, height: $height } = this.svg.getBoundingClientRect()

        const height = $height - this.props.margin.top

        const width = $width - this.props.margin.left

        if (!data.length) return { chartData, areaChartData, points }

        const xValues = data.map(item => item.amount)
        const yValues = data.map(item => item.price)

        const minX = Math.min(...xValues)
        const maxX = Math.max(...xValues)
        const minY = Math.min(...yValues)
        const maxY = Math.max(...yValues)

        data.forEach((item, index, array) => {
            const { reverse, margin } = this.props
            let x1 = index
                ? width - (width / 100) * this.calcValue(minX, maxX, array[index - 1].amount)
                : reverse
                    ? width
                    : 0
            let y1 = index
                ? height - (height / 100) * this.calcValue(minY, maxY, array[index - 1].price)
                : reverse
                    ? height
                    : 0

            let x2 = width - (width / 100) * this.calcValue(minX, maxX, item.amount)
            let y2 = height - (height / 100) * this.calcValue(minY, maxY, item.price)

            // chartData += ''
            areaChartData += ''

            // console.log(width / 100 * this.calcValue(minX, maxY, item.sum))
            // console.log(height / 100 * this.calcValue(minX, maxY, item.price))
            // let x1 = index ? width / 100 * this.calcValue(minX, maxX, array[index - 1].sum) : 0
            // let y1 = index ? height / 100 * this.calcValue(minY, maxY, array[index - 1].price) : 0

            // let x2 = width / 100 * this.calcValue(minX, maxX, item.sum)
            // let y2 = height / 100 * this.calcValue(minY, maxY, item.price)
            //
            // if (!isIncreasing) {
            //     y1 = height - y1
            //     y2 = height - y2
            // }
            //
            y1 += margin.top
            y2 += margin.top
            //
            x1 += margin.left
            x2 += margin.left

            if (index === 0) {
                chartData += `M${x1} 0`
                areaChartData += `M${width + margin.left}, ${y1}`
            } else {
                chartData += `L${x1} ${y1} ${x2} ${y2}`
                areaChartData += `L${x1} ${y1} ${x2} ${y2}`
            }
            //
            points.push({
                x1,
                x2,
                y1,
                y2,
                price: item.price
            })
        })

        return {
            points,
            chartData,
            areaChartData,
            width,
            height,
            minX,
            minY,
            maxX,
            maxY
        }
    }

    calcValue = (min, max, value) => {
        const a = value - min
        const b = max - min

        return (100 * a) / b
    }

    findMarkerData = ({ y }) => {
        const index = this.state.points.findIndex(({ y1, y2 }) => y1 <= y && y <= y2)
        if (index !== -1) {
            const { x1, x2, y1, y2, price } = this.state.points[index]
            this.setState({
                point: Math.abs(y1 - y) > Math.abs(y2 - y) ? { y: y2, x: x2, price } : { y: y1, x: x1, price }
            })
        }
    }

    handleMouseMove = ({ clientX, clientY }) => {
        const { left, top } = this.svg.getBoundingClientRect()
        if (!this.state.initialed) return
        this.findMarkerData({ x: clientX - left, y: clientY - top })
    }

    handleMouseLeave = () => {
        this.setState({
            point: null
        })
    }

    calculateAxisValue = (min, max, percent) => {
        const diff = max - min

        return (diff / 100) * percent + min
    }

    render() {
        const { strokeColor, fillColor, width, height } = this.props
        const { chartData, areaChartData } = this.state
        return (
            <div style={{ width, height, position: 'relative' }}>
                {this.state.point && (
                    <div
                        style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            transform: `translateY(${this.state.point.y}px)`,
                            background: 'black',
                            padding: '5px 10px',
                            transition: '0.3s'
                        }}
                    >
                        {this.state.point.price}
                    </div>
                )}
                <svg
                    height="100%"
                    width="100%"
                    ref={node => {
                        this.svg = node
                    }}
                    onMouseMove={this.handleMouseMove}
                    onMouseLeave={this.handleMouseLeave}
                >
                    {this.state.initialed && (
                        <g>
                            <path d={chartData} stroke={strokeColor} fill="none" style={{ transition: '0.3s' }} />
                            <path d={areaChartData} stroke="none" fill={fillColor} style={{ transition: '0.3s' }} />
                        </g>
                    )}

                    {this.state.initialed &&
                        new Array(4).fill(0).map((item, index) => (
                            <g>
                                <line
                                    x1={this.props.margin.left + (this.state.width / 4) * index}
                                    x2={this.props.margin.left + (this.state.width / 4) * index + 1}
                                    y1={this.props.margin.top}
                                    y2={this.state.height + this.props.margin.top}
                                    stroke="#d3d3d31f"
                                    strokeDasharray="2, 2"
                                />
                                {this.props.xAxis && (
                                    <text
                                        x={this.props.margin.left + (this.state.width / 4) * (3 - index)}
                                        y="10"
                                        fill="#6A7380"
                                        fontSize="12px"
                                        textAnchor="middle"
                                    >
                                        {round(
                                            this.calculateAxisValue(
                                                this.state.minX,
                                                this.state.maxX,
                                                (100 / 4) * (index + 1)
                                            )
                                        )}
                                    </text>
                                )}
                            </g>
                        ))}

                    {this.state.point && (
                        <g>
                            <line
                                stroke="#58636d"
                                strokeDasharray="2, 2"
                                x1={this.props.margin.left}
                                y1={this.state.point.y}
                                x2={this.state.point.x}
                                y2={this.state.point.y}
                            />
                            <circle
                                cx={this.state.point.x}
                                cy={this.state.point.y}
                                r="4"
                                stroke={strokeColor}
                                strokeWidth="1"
                                fill="black"
                            />
                        </g>
                    )}
                </svg>
            </div>
        )
    }
}
