const path = (path = '', data) => {
    if (path === '') return ''
    const $path = path.split('.')
    let result
    $path.forEach((item, index) => {
        if (index === 0 || result[item]) {
            result = !index ? data[item] : result[item]
        } else {
            result = ''
        }
    })

    return result
}

export { path }
