import React from 'react'
import PropTypes from 'prop-types'

export default class Message extends React.Component {
    static propTypes = {
        id: PropTypes.string.isRequired,
        data: PropTypes.object
    }

    static contextTypes = {
        locale: PropTypes.object.isRequired
    }

    render() {
        const { id, data } = this.props
        const localizedMessage = this.context.locale[id]

        if (typeof localizedMessage === 'function') {
            return localizedMessage(data)
        }

        return this.context.locale[id] || id
    }
}
