import React from 'react'
import PropTypes from 'prop-types'

export default class I18nProvider extends React.Component {
    static propTypes = {
        locale: PropTypes.object.isRequired,
        children: PropTypes.element.isRequired
    }

    static childContextTypes = {
        locale: PropTypes.object.isRequired
    }

    getChildContext() {
        return {
            locale: this.props.locale
        }
    }

    render() {
        return React.Children.only(this.props.children)
    }
}
