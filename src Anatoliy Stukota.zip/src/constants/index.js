// router

export const ROUTER_INIT = '@@router/init'
export const ROUTER_LOCATION_CHANGE = '@@router/locationChange'
export const APP_CURRENCY_PAIR_CHANGED = '@@app/currencyPairChanged'

// sockets

export const ws = {
    request: {
        subscribe: {
            OrderBookTop: '.OrderBookTopSubscribeRequest',
            TradeHistoryTop: '.TradeHistoryTopSubscribeRequest',
            ServerTime: '.ServerTimeSubscribeRequest',
            Summary24h: '.Summary24hSubscribeRequest',
            MarketDepth: '.MarketDepthSubscribeRequest',
            UserBalance: '.UserBalanceSubscribeRequest',
            MyActiveOrdersChanges: '.MyActiveOrdersChangesSubscribeRequest',
            MyTradeHistoryChanges: '.MyTradeHistoryChangedSubscribeRequest'
        },
        unsubscribe: {
            OrderBookTop: '.OrderBookTopUnsubscribeRequest',
            TradeHistoryTop: '.TradeHistoryTopUnsubscribeRequest',
            ServerTime: '.ServerTimeUnsubscribeRequest',
            Summary24h: '.Summary24hUnsubscribeRequest',
            MarketDepth: '.MarketDepthUnsubscribeRequest',
            UserBalance: '.UserBalanceUnsubscribeRequest',
            MyActiveOrdersChanges: '.MyActiveOrdersChangesUnsubscribeRequest',
            MyTradeHistoryChanges: '.MyTradeHistoryChangedUnsubscribeRequest'
        }
    },
    response: {
        subscribe: {
            OrderBookTop: '.OrderBookTopSubscribeResponse',
            TradeHistoryTop: '.TradeHistoryTopSubscribeResponse',
            ServerTime: '.ServerTimeSubscribeResponse',
            Summary24h: '.Summary24hSubscribeResponse',
            MarketDepth: '.MarketDepthSubscribeResponse',
            UserBalance: '.UserBalanceSubscribeResponse'
        },
        unsubscribe: {
            OrderBookTop: '.OrderBookTopUnsubscribeResponse',
            TradeHistoryTop: '.TradeHistoryTopUnsubscribeResponse',
            ServerTime: '.ServerTimeUnsubscribeResponse',
            Summary24h: '.Summary24hUnsubscribeResponse',
            MarketDepth: '.MarketDepthUnsubscribeResponse',
            UserBalance: '.UserBalanceUnsubscribeResponse',
            MyActiveOrdersChanges: '.MyActiveOrdersChangesUnsubscribeResponse'
        },
        OrderBookState: '.OrderBookStateResponse',
        OrderBookTop: '.OrderBookTopResponse',
        TradeHistoryState: '.TradeHistoryStateResponse',
        LatestTrades: '.LatestTradesResponse',
        ServerTime: '.ServerTimeResponse',
        Summary24h: '.Summary24hResponse',
        MarketDepth: '.MarketDepthResponse',
        UserBalances: '.UserBalancesResponse',
        MyActiveOrdersChanges: '.MyActiveOrdersChangesResponse',
        MyTradeHistoryChanged: '.MyTradeHistoryChangedResponse'
    }
}
