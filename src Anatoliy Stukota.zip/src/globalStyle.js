import { injectGlobal, withTheme } from 'styled-components'
import Font from 'assets/fonts/icomoon.woff'

const reset = `
html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, 
big, cite, code, del, dfn, em, font, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, 
center, dl, dt, dd, ol, ul, li, form, label, caption, table, tbody, tfoot, thead, tr, th, td {
    margin: 0;
    padding: 0;
    border: 0;
}

img {
    border: 0;
    vertical-align: middle;
}

blockquote, q {
    quotes: none;
}

blockquote:before, blockquote:after, q:before, q:after {
    content: "";
}

a:focus {
    outline: 0;
    text-decoration: none;
}

article, aside, details, figcaption, figure, footer, header, main, nav, section, summary {
    display: block;
}

button:focus {
    outline: none;
}

`
const icons = `

[class^="icon-"]{
  font-family: 'icomoon' !important;
  speak: none;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.icon-rep:before {
  content: "\\e91e";
}
.icon-omg:before {
  content: "\\e91f";
}
.icon-ctk:before {
  content: "\\e920";
}
.icon-user-ok:before {
  content: "\\e91d";
  color: #02e866;
}
.icon-transaction:before {
  content: "\\e91b";
}
.icon-frozen:before {
  content: "\\e91c";
}
.icon-check:before {
  content: "\\e900";
}
.icon-down:before {
  content: "\\e901";
}
.icon-eye:before {
  content: "\\e902";
}
.icon-pagination:before {
  content: "\\e903";
}
.icon-btc:before {
  content: "\\e904";
}
.icon-bch:before {
  content: "\\e904";
}
.icon-ckt:before {
  content: "\\e905";
}
.icon-copy:before {
  content: "\\e906";
}
.icon-deposit:before {
  content: "\\e907";
}
.icon-eth:before {
  content: "\\e908";
}
.icon-eye_open:before {
  content: "\\e909";
}
.icon-level:before {
  content: "\\e90a";
}
.icon-ltc:before {
  content: "\\e90b";
}
.icon-mail:before {
  content: "\\e90c";
}
.icon-question:before {
  content: "\\e90d";
}
.icon-save:before {
  content: "\\e90e";
}
.icon-search:before {
  content: "\\e90f";
}
.icon-secure:before {
  content: "\\e910";
}
.icon-star:before {
  content: "\\e911";
}
.icon-success:before {
  content: "\\e912";
}
.icon-wallet:before {
  content: "\\e913";
}
.icon-withdraw:before {
  content: "\\e914";
}
.icon-xrp:before {
  content: "\\e915";
}
.icon-arrow:before {
  content: "\\e916";
}
.icon-close:before {
  content: "\\e917";
}
.icon-refresh:before {
  content: "\\e918";
}
.icon-user:before {
  content: "\\e919";
}
.icon-remove:before {
  content: "\\e91a";
}
`
export default withTheme(({ theme, children }) => {
    // eslint-disable-next-line no-unused-expressions
    injectGlobal`
@import url('https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700');
@font-face {
    font-family: 'icomoon';
    src:  url(${Font});
    font-weight: normal;
    font-style: normal;
}

${reset}
${icons}

a {
    text-decoration: none;
    color: ${theme.linkColor}; 
}
html{
    background-color: #1f273b;
}
html, body {
    margin: 0;
    padding: 0;
    min-width: 1024px;
}

body {
    font-family: 'Open Sans', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #fff;
}

.content {
    width: 75rem;
    margin: 0 auto;
    position: relative;
}
@media(max-width: 1650px){
  html{
    font-size: 14px;
  }
}
@media(max-width: 1455px){
  html{
    font-size: 12px;
  }
}

.flex {
    display: flex;
}

.flex.between {
    justify-content: space-between;
}


@keyframes OpenBlock{
  from{
    max-height: 0;
  }
  to{
    max-height: 200px;
  }
}

.ReactModal__Body--open {
    overflow: hidden;
}

.ReactModalPortal .ReactModal__Overlay {
    position: fixed;
    top: -16rem;
    right: 0;
    left: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0;
    background: rgba(16, 18, 25, 0);
    transition: all .3s ease;
}

.ReactModalPortal .ReactModal__Overlay--after-open {
    top: 0;
    opacity: 1;
    transition: all .3s ease;
    background: rgba(16, 18, 25, 0.8);
}

.ReactModalPortal .ReactModal__Overlay--before-close {
    opacity: 0;
    top: -16rem;
}
.scrollbar::-webkit-scrollbar-track{
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
  background-color: transparent;
  border-radius: 10px;
}
.scrollbar::-webkit-scrollbar{
  width: .375rem;
  background-color: transparent;
}
.scrollbar::-webkit-scrollbar-thumb{
  background-color: #808F92;
  border-radius: .625rem;
}
.scrollbar{
  overflow: auto;
  display: block;
}

@-webkit-keyframes autofill {
    to {
        color: #fff;
        background: transparent;
    }
}

input:-webkit-autofill {
    -webkit-animation-name: autofill;
    -webkit-animation-fill-mode: both;
}

`
    return children
})
