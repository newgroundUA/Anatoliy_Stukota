import React from 'react'
import ReactDOM from 'react-dom'
import { AppContainer } from 'react-hot-loader'
import { defaults } from 'data-fetcher'
import Modal from 'react-modal'
import createHistory from 'history/createBrowserHistory'
import Socket from './socket'
import App from './App'
import { Store } from './stores'
import getConfig from '../config'
import '../assets/style.sass'

const history = createHistory()
const socket = new Socket()
const store = Store.create({}, { history, socket })

const getStore = () => store

Modal.setAppElement('body')
Modal.defaultStyles = {
    overlay: null,
    content: null
}

Modal.defaultProps.closeTimeoutMS = 300
Modal.defaultProps.shouldFocusAfterRender = false

const { APP_API_BASE_URL } = getConfig()

let DevTools

if (process.env.NODE_ENV !== 'production') {
    require('mst-middlewares').connectReduxDevtools(require('remotedev'), store)
    DevTools = require('mobx-react-devtools').default
}

defaults.baseUrl = APP_API_BASE_URL
defaults.onFail = store.app.handleFail

const render = App => {
    App({ history, store }).then(result => {
        ReactDOM.render(
            <AppContainer>
                <React.Fragment>
                    {DevTools && <DevTools position={{ bottom: 0, right: 20 }} />}
                    {result}
                </React.Fragment>
            </AppContainer>,
            document.getElementById('react-root')
        )
    })
}

render(App)

if (module.hot) module.hot.accept('./App', () => render(App))

export { getStore, socket }
