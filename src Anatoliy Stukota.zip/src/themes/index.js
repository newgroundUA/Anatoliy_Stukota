const base = {
    linkColor: '#4A90E2',
    mainHeight: 'calc(100vh - 8rem)',
    headerHeight: '4rem',
    footerHeight: '4rem'
}

export default {
    ...base,
    green: '#02E866',
    red: '#FF4A68',
    linkStyle: 'a{color: #4A90E2;}a:hover{text-decoration: underline;}',
    datePicker: {
        bg: '#232d45',
        inputColor: '#9ba0ac',
        weekdayColor: '#7F8791',
        dayColor: '#fff',
        todayColor: '#06B758',
        hoverBg: '#06B758'
    },
    tradeView: {
        bg: '#1F273B',
        green: '#02E866',
        greenMain: '#49B07C',
        red: '#FF4A68',
        textColor: '#6A7380',
        loadingBg: '#6A7380',
        toolbarBg: '#1F273B',
        gridColor: 'rgba(69, 69, 69, 0.33)',
        volumeColor: 'rgba(85,174,166,0.2)'
    },
    materialInput: {
        textColor: '#fff',
        labelColor: '#808f92',
        errorColor: '#DB5C5C',
        borderColor: '#2f3847',
        borderColorActive: '#fff'
    }
}
