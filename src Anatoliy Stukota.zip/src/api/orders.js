import { fetcher } from 'data-fetcher'

const placeOrder = ({ type, ...body }) =>
    fetcher(type === 'market' ? '/orders/market' : '/orders', {
        method: 'POST',
        body
    })

const getActiveOrders = query => fetcher('/orders/active', { query })

const cancelOrder = id =>
    fetcher(`/orders/${id}/cancel`, {
        method: 'POST'
    })

const getOrders = query =>
    fetcher('/orders', {
        query: {
            page: 0,
            pageSize: 10,
            ...query
        }
    })

export { getActiveOrders, cancelOrder, placeOrder, getOrders }
