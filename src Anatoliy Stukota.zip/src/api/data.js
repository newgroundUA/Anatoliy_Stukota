import { fetcher } from 'data-fetcher'

const getSiteKey = () => fetcher('/data/captcha')

const getFees = () => fetcher('/data/fees')

const getLimits = () => fetcher('/data/limits')

const getPairs = () => fetcher('/data/pairs')

const getWithdrawalFees = () => fetcher('/data/withdrawals/fees')

const getCurrencies = () => fetcher('/data/currencies')

const getFeatures = () => fetcher('/data/features')

const getSiteVersion = () => fetcher('/data/version')

export { getSiteKey, getFees, getLimits, getPairs, getWithdrawalFees, getCurrencies, getFeatures, getSiteVersion }
