import { fetcher } from 'data-fetcher'

const loginUser = body =>
    fetcher('/auth/loginUser', {
        body,
        method: 'POST'
    })

const confirmTwoFa = body =>
    fetcher('/auth/loginUser/confirmTwoFa', {
        body,
        method: 'POST'
    })

const createUser = body =>
    fetcher('/auth/createUser', {
        body,
        method: 'POST'
    })

const sendPasswordResetLink = body =>
    fetcher('/auth/sendPasswordResetLink', {
        method: 'POST',
        body
    })

const resetPassword = body =>
    fetcher('/auth/resetPassword', {
        method: 'POST',
        body
    })

export { sendPasswordResetLink, resetPassword, loginUser, createUser, confirmTwoFa }
