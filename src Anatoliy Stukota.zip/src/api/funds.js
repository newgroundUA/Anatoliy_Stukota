import { fetcher } from 'data-fetcher'

const getTransactions = query =>
    fetcher('/funds/my/trxs', {
        query: {
            page: 0,
            pageSize: 10,
            ...query
        }
    })

const withdrawal = body =>
    fetcher('/funds/withdrawals', {
        method: 'POST',
        body
    })

const cancelWithdrawal = id =>
    fetcher(`/funds/withdrawals/cancel/${id}`, {
        method: 'POST'
    })

export { getTransactions, withdrawal, cancelWithdrawal }
