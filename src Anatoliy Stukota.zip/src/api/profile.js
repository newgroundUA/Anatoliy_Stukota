import { fetcher } from 'data-fetcher'

const getSharedSecret = async () => {
    const { sharedSecret } = await fetcher('/profile/generateTwoFaSecret', {
        method: 'POST'
    })
    return sharedSecret
}

const enableTwoFa = ({ authCode, signup }) =>
    fetcher('/profile/enable2FA', {
        method: 'POST',
        body: {
            authCode,
            signup
        }
    })

const disableTwoFa = body =>
    fetcher('/profile/disable2FA', {
        method: 'POST',
        body
    })

const changePassword = body =>
    fetcher('/profile/changePassword', {
        method: 'POST',
        body
    })

const getWallets = () => fetcher('/profile/wallet/list')

const createWallet = currency =>
    fetcher(`/profile/createAddress/${currency}`, {
        method: 'POST'
    })

const getApiKeys = () => fetcher('/profile/api-keys')

const createApiKey = body =>
    fetcher('/profile/api-keys', {
        method: 'POST',
        body
    })

const deactivateApiKey = (id, authCode) =>
    fetcher(`/profile/api-keys/${id}`, {
        method: 'DELETE',
        body: {
            authCode
        }
    })

const changeApiKeyPermissions = body =>
    fetcher(`/profile/api-keys/${body.id}`, {
        method: 'PUT',
        body
    })

export {
    getSharedSecret,
    enableTwoFa,
    changePassword,
    disableTwoFa,
    getWallets,
    createWallet,
    getApiKeys,
    createApiKey,
    deactivateApiKey,
    changeApiKeyPermissions
}
