import React from 'react'
import { Router } from 'react-router-dom'
import { renderRoutes } from 'react-router-config'
import { Provider } from 'mobx-react'
import { ThemeProvider } from 'styled-components'
import { ROUTER_LOCATION_CHANGE, ROUTER_INIT } from 'constants'
import I18nProvider from 'i18n/Provider'
import theme from './themes'
import routes from './routes'
import { getResolver } from './resolver'
import Style from './globalStyle'
import en from './locales/en'

const App = async ({ history, store }) => {
    const resolver = getResolver({ history, store, routes })
    resolver.routes = routes
    try {
        await resolver.init(history.location)
        history.listen(store.router[ROUTER_LOCATION_CHANGE])
        store.router[ROUTER_INIT](history.location)
    } catch (e) {
        console.error('something went wrong', e)
    }

    return (
        <Provider {...store}>
            <I18nProvider locale={en}>
                <ThemeProvider theme={theme}>
                    <Style>
                        <Router history={history}>{renderRoutes(routes)}</Router>
                    </Style>
                </ThemeProvider>
            </I18nProvider>
        </Provider>
    )
}

export { App as default }
