import SockJS from 'sockjs-client'
import cookie from 'flexible-cookie'
import { emitter } from '../utils'

class Socket {
    constructor() {
        this.queue = new Map()
        this.subscriptions = new Map()
        this.ws = null
        this.connected = false
        this.losted = false
        this.reconnection = false
        this.$id = 0
    }

    getId = () => ++this.$id

    connect = () => {
        const { isAuthenticated } = this.store.app
        this.ws = new SockJS(`/ws${isAuthenticated ? `?Auth=${cookie.get('Auth')}` : ''}`)
        this.ws.onopen = this.onOpen
        this.ws.onclose = this.onClose
        this.ws.onerror = this.onError
        this.ws.onmessage = this.onMessage
    }

    disconnect = () => {
        this.connected = false
        this.ws.close()
        this.ws = null
    }

    reconnect = () => {
        this.disconnect()
        this.reconnection = true
        this.connect()
    }

    onOpen = () => {
        this.connected = true
        this.store.app.set('sockets', true)

        this.store.notifications.notify({ title: 'webSockets', message: 'connectionHasBeenEstablished' })

        if (this.losted || this.reconnection) {
            this.losted = false
            this.reconnection = false
            this.subscriptions.forEach(item => {
                this.send(item.type, item.args)
            })
        }

        if (this.queue.size) {
            this.queue.forEach(item => {
                this.send(item.type, item.args)
            })

            this.queue.clear()
        }
    }

    onClose = () => {
        this.store.app.set('sockets', false)
        if (this.connected) {
            // only for lost connection
            this.losted = true
            this.connected = false
            this.store.notifications.notify({
                title: 'webSockets',
                message: 'connectionHasBeenLostReconnecting'
            })
            setTimeout(this.connect, 5000)
        } else {
            this.store.notifications.notify({
                title: 'webSockets',
                message: 'disconnected'
            })
        }
    }

    onError = e => {
        console.error(e)
    }

    onMessage = ({ data }) => {
        const { type, ...payload } = JSON.parse(data)
        emitter.emit(type, payload)
    }

    send = (type, args) => {
        const id = this.getId()
        if (this.connected === true) {
            this.ws.send(JSON.stringify({ type, ...args }))
        } else {
            this.queue.set(id, { type, args })
        }

        return {
            id,
            type,
            args
        }
    }
}

export default Socket
